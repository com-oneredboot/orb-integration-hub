# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Natural language schema generation via AI
- Automated schema migration generation
- Advanced MCP watch mode integration
- Enhanced AI-powered schema analysis
- Lambda resolver generation for AppSync

## [0.10.3] - 2026-01-07

### Fixed
- **Python generator ignores default values in schema attributes** (#43): Optional fields with `default` values now use the schema-defined default instead of `None`. Supports string, integer, float, and boolean defaults.
- **Python generator ignores validation rules in schema attributes** (#44): Validation rules (`min`, `max`, `pattern`) are now correctly included in generated Pydantic Field() definitions.

### Added
- **Default value support for TypeScript and Dart generators**: Schema-defined defaults are now used in TypeScript class constructors and Dart named constructors.
- **New documentation**: Added `docs/generation/schema-attributes.md` with comprehensive documentation for default values and validation rules.

### Documentation
- Added schema attribute features documentation covering default values and validation rules.
- Updated examples to show default and validation usage.

## [0.10.2] - 2026-01-07

### Fixed
- **Python generator uses wrong import depth for same-directory model references** (#42): When a model references another model in the same directory, the generator now correctly uses single-dot imports (`from .GPSPointModel import GPSPoint`) instead of double-dot imports (`from ..GPSPointModel`). This also applies to enum imports when enums are configured in the same directory as models.

## [0.10.1] - 2026-01-07

### Fixed
- **Generated files missing AUTO-GENERATED header** (#38): All generated files (Python, Dart, TypeScript) now include an AUTO-GENERATED header with version and regeneration command.
- **Python generator incorrect relative import paths** (#39): Enum imports now use snake_case module names (e.g., `from ..enums.alert_type_enum import AlertType`).
- **Python uses deprecated Pydantic `class Config`** (#40): Migrated to modern `model_config = ConfigDict(from_attributes=True)` pattern.

### Added
- **Python `__init__.py` barrel file generation** (#41): The Python generator now creates `__init__.py` files in models and enums directories with imports and `__all__` exports.
- **Dart barrel file generation** (#41): The Dart generator now creates barrel files (`models.dart`, `enums.dart`) with export statements.
- **New configuration options**: Added `generate_init` (Python) and `barrel_file` (Dart) options to control barrel file generation.

### Documentation
- Updated `docs/configuration/targets.md` with barrel file configuration options.
- Updated `docs/generation/dart-generation.md` with AUTO-GENERATED header and barrel file documentation.

## [0.10.0] - 2026-01-06

### Breaking Changes
- **Schema `target` field is now required** (#37): All schema files must include a `target` field that specifies which output target the generated code should go to.
- **Configuration must use `targets` map**: The `base_dir` configuration under each language output has been replaced with a `targets` map that defines named output destinations.

### Added
- **Multi-destination output support** (#37): Schemas can now be routed to different output directories based on their `target` field. This enables use cases like:
  - API schemas → Backend API models
  - Package schemas → Shared library models
  - Mobile schemas → Mobile app models
- **Target validation**: The generator validates that all schema targets exist in configuration and all configured targets are used by schemas.
- **New documentation**: Added `docs/configuration/targets.md` with comprehensive target configuration guide and migration instructions.

### Migration Guide

1. **Add `target` field to all schemas**:
   ```yaml
   # Before
   name: Users
   model:
     ...

   # After
   name: Users
   target: api  # Add this line
   model:
     ...
   ```

2. **Update configuration to use `targets` map**:
   ```yaml
   # Before
   output:
     python:
       enabled: true
       base_dir: ./backend/models
       enums_subdir: enums

   # After
   output:
     python:
       enabled: true
       targets:
         api:
           base_dir: ./backend/models
           enums_subdir: enums
   ```

See `docs/configuration/targets.md` for complete documentation.

## [0.9.6] - 2026-01-05

### Fixed
- **`orb-schema whatsnew` fails when installed from CodeArtifact** (#36): The `whatsnew` command now uses `importlib.resources` to read CHANGELOG.md from the installed package, with fallback to filesystem paths for development mode.

### Added
- **CHANGELOG.md bundled with package**: CHANGELOG.md is now included in wheel builds via `[tool.setuptools.package-data]` configuration, enabling the `whatsnew` command to work when installed from PyPI or CodeArtifact.

## [0.9.5] - 2026-01-03

### Fixed
- **Removed pytest.skip() from integration tests**: Per project standards, tests must pass or fail, never skip. Integration tests now use proper pytest markers (`@pytest.mark.codeartifact`, `@pytest.mark.github_actions`, `@pytest.mark.integration`) instead of runtime skips.

### Changed
- **CodeArtifact tests use markers**: Run with `pytest -m codeartifact` (requires AWS credentials), skip with `pytest -m "not codeartifact"`
- **GitHub Actions tests use markers**: Run with `pytest -m github_actions`, skip with `pytest -m "not github_actions"`
- **Python API integration tests refactored**: Removed try/except blocks that caught all exceptions and skipped tests

## [0.9.4] - 2026-01-03

### Fixed
- **GraphQL schema uses unsupported custom 'DateTime' scalar** (#35): Changed from custom `scalar DateTime` to AWS AppSync built-in scalars (`AWSDateTime`, `AWSTimestamp`). AppSync does not support user-defined custom scalars.

### Changed
- **`datetime` type now maps to `AWSDateTime`**: ISO 8601 format (YYYY-MM-DDThh:mm:ss.sssZ)
- **`timestamp` type now maps to `AWSTimestamp`**: Unix epoch seconds (integer)
- **No custom scalar definitions generated**: AppSync built-in scalars don't require explicit definitions

### Added
- **New AWS AppSync scalar type mappings**:
  - `date` → `AWSDate` (YYYY-MM-DD)
  - `time` → `AWSTime` (hh:mm:ss.sss)
  - `email` → `AWSEmail` (with email validation)
  - `url` → `AWSURL` (with URL validation)
  - `phone` → `AWSPhone` (with phone validation)
  - `ipaddress` → `AWSIPAddress` (with IP validation)
  - `json` → `AWSJSON` (arbitrary JSON data)
- **77 new unit tests** for AWS AppSync scalar type mappings

### Documentation
- Updated `docs/generation/graphql.md` with AWS AppSync scalar documentation
- Added scalar type selection guide for date/time fields
- Updated example generated schema to use AppSync scalars

## [0.9.3] - 2026-01-03

### Fixed
- **GraphQL input types reference output types** (#34): Nested object references (`object_ref`) and array references (`items_ref`) in mutation inputs now correctly generate `{TypeName}Input` variants instead of referencing output types. This ensures GraphQL schema validity when mutations accept nested objects.

### Added
- **Nested Input Type Generation**: GraphQL generator now automatically creates `{TypeName}Input` variants for all nested types used in Create and Update mutations.
- **`_collect_nested_types()` Method**: Scans schemas to identify all `object_ref` and `items_ref` references that need Input variants.
- **`_generate_nested_input_types()` Method**: Generates Input type definitions for nested types with proper field type resolution.
- **`for_input` Parameter**: Enhanced `_graphql_type()` method with `for_input: bool` parameter to control whether output types or input types are generated.
- **Workflow `skip_tests` Input** (#33): Added `skip_tests` boolean input to publishing workflow for emergency use when tests fail due to infrastructure issues.
- **Workflow Timeout**: Added `timeout-minutes: 30` to prevent hung workflow jobs.
- **Workflow Working Directory**: Added explicit `defaults.run.working-directory: .` for consistent path resolution.
- **Property-Based Tests**: Added 5 property tests validating nested input type generation, deduplication, and schema validation.

### Changed
- **Create Mutation Inputs**: Now use `_graphql_type(attr, for_input=True)` to generate proper Input type references.
- **Update Mutation Inputs**: Non-key fields now use `_graphql_type(attr, for_input=True)` for proper Input type references.

### Documentation
- Updated `docs/generation/graphql.md` with nested input type generation documentation and examples.
- Updated `docs/deployment/publishing-workflow.md` with `skip_tests` input and timeout documentation.

## [0.9.2] - 2024-12-31

### Fixed
- **GraphQL duplicate input types** (#32): Implemented type registry pattern to prevent duplicate type definitions. All types, inputs, enums, and response types are now tracked and deduplicated during generation.

### Added
- **Type Registry**: GraphQL generator now uses a centralized type registry to track all generated types and prevent duplicates across schemas.
- **AppSync Directive Definitions**: Generated schemas now include AWS AppSync directive definitions (@aws_auth, @aws_cognito_user_pools, @aws_api_key, @aws_iam) at the top of the schema.
- **Post-generation GraphQL Validation**: When `validate_graphql: true` (default), the generator validates the schema after generation and logs any warnings.
- **`validate-graphql` CLI Command**: New command to validate GraphQL schema files for syntax errors, duplicate types, and AppSync compatibility.
- **MCP Server Protocol**: Rewrote MCP server to use the official `mcp` Python package for proper protocol compliance.
- **MCP Package Dependency**: Added `mcp>=1.0.0` to project dependencies.

### Changed
- **Consolidated Input Generation**: Removed separate `_generate_inputs()` method; all input types are now generated through `_generate_all_inputs()` from operations.
- **MCP Server Tools**: Simplified to four core tools: `list_schemas`, `inspect_schema`, `validate_schema`, `generate_from_schema`.

### Documentation
- Updated `docs/generation/graphql.md` with type registry and AppSync directive documentation.
- Updated `docs/development/mcp-server.md` with new MCP server configuration and tool reference.
- Updated `docs/configuration/validation.md` with `validate-graphql` CLI command documentation.

## [0.9.1] - 2024-12-31

### Fixed
- **GraphQL schema missing DateTime scalar** (#31): DateTime scalar is now automatically generated when schemas contain `datetime` or `timestamp` fields. The scalar definition appears before type definitions.
- **GraphQL schema missing Response types** (#31): `{SchemaName}Response` types are now generated for all TableSchemas with `items: [SchemaName!]` and `nextToken: String` fields for pagination support.
- **GraphQL schema missing Operation Input types** (#31): `{OperationName}Input` types are now generated for all operations including Query inputs with pagination fields (`limit`, `nextToken`).

### Deprecated
- **Config 'version' field** (#30): The `version` field in `schema-generator.yml` is now deprecated and will trigger a warning. Use `orb-schema --version` to check the generator version instead.

### Added
- **GraphQL generation documentation**: New `docs/generation/graphql.md` with complete documentation for GraphQL schema generation including custom scalars, Response types, and Operation Input types.
- **Property-based tests for GraphQL**: Added 7 property-based tests validating Response type completeness, Operation Input generation, and custom scalar handling.

## [0.9.0] - 2024-12-31

### Added
- **Environment enumeration**: Standard environment values (dev, stg, uat, qa, prd) with validation warnings for non-standard values
- **`validate-config` command**: Validate configuration files with `--fix` for auto-correction and `--schema` for JSON schema output
- **`whatsnew` command**: View changelog entries since a specified version with `--since <version>`
- **`--skip-validation` flag**: Bypass configuration validation during generation when needed
- **Output directory validation**: Scan output directories for custom files that may be overwritten
- **File overwrite protection**: Files without `AUTO-GENERATED` header are skipped during generation to protect custom code
- **Configuration validation during generation**: Automatic validation before code generation (errors block, warnings display)

### Fixed
- **Environment field now read from config file** (#28): The `environment` field in `project` section is now correctly read from the configuration file, with fallback to `ENVIRONMENT` env var, then "development"
- **Project name bug**: Fixed issue where `project_name` was incorrectly set when not specified in config

### Changed
- **Generation now validates config automatically**: Use `--skip-validation` to bypass validation if needed

## [0.8.2] - 2024-12-30

### Fixed
- **DynamoDB table naming ignores customerId/projectId** (#28): CDK generator now correctly uses `GeneratorConfig` values (`customer_id`, `project_id`, `environment`) for resource naming. Removed redundant `project_config.py` singleton module that was causing the issue.

### Changed
- **Issue tracking location**: Migrated from `.kiro/issues/` to `.github/ISSUES/` for better visibility and GitHub integration
- **Added CODEOWNERS file**: Defines code ownership for automated review requests
- **Updated steering file command phrases**: Added `update ticket` and `close ticket` commands, updated `open bug` to use `--body-file` pattern
- **Added PR review response guidance**: Documentation for responding to PR review comments
- **Added priority labels**: Created `priority: critical`, `priority: high`, `priority: medium`, `priority: low` labels
- **Added WSL troubleshooting**: Documentation for fixing pre-commit hook issues when WSL venv is missing dev dependencies

## [0.8.1] - 2024-12-29

### Fixed
- **Duplicate QueryBy class prevention** (#24): Python generator now tracks generated class names to prevent duplicate `QueryBy{PartitionKey}Input` classes when multiple GSIs share the same partition key
- **Hierarchical SSM parameter naming** (#26): SSM parameters now use hierarchical path-based names (e.g., `/orb/project/dev/appsync/api-id`) instead of flat hyphen-separated names. AWS resource names remain flat.

## [0.8.0] - 2024-12-24

### Added - CDK AppSync Phase 1 Core Features

#### Configurable Authorization
- **USER_POOL as default**: When `auth.userPoolId` is configured, USER_POOL becomes the default authorization
- **API_KEY for public endpoints**: When `auth.publicEndpoints: true` (default), API_KEY is added as additional auth
- **SSM parameter lookup**: User Pool ID is resolved from SSM at deploy time (not hardcoded)
- **Cognito and SSM imports**: Automatically added when USER_POOL auth is configured

#### CloudWatch Logging
- **Configurable logging**: Enable with `logging.enabled: true`
- **IAM role generation**: Creates role with `AWSAppSyncPushToCloudWatchLogs` policy
- **Log level configuration**: Supports ALL, ERROR, NONE via `logging.level`

#### API Key Resource
- **Automatic API Key creation**: Generated when `publicEndpoints: true`
- **Configurable expiration**: Set via `apiKey.expirationDays` (default 365 days)
- **Expiration calculation**: Uses Unix timestamp for CDK compatibility

#### SSM Parameter Outputs
- **API discovery**: Stores API ID and GraphQL URL in SSM
- **Table discovery**: Stores table names and ARNs in SSM
- **Naming convention**: `{customerId}-{projectId}-{environment}-{resource}-{type}`

#### Configuration Example
```yaml
output:
  infrastructure:
    appsync:
      auth:
        userPoolId: "orb-project-dev-cognito-user-pool-id"
        publicEndpoints: true
      logging:
        enabled: true
        level: ALL
      apiKey:
        expirationDays: 365
      ssm:
        enabled: true
```

## [0.7.5] - 2024-12-24

### Fixed - Python Model Import Generation (Issue #24)

#### Improved Typing Import Handling
- **Bug Fix**: Python models now correctly track and deduplicate typing imports
- **Root Cause**: The fallback import logic could add duplicate `from typing import` statements
- **Solution**: Analyze all attributes to determine exactly which typing imports are needed, then generate a single consolidated import line

#### Changes
- `Optional` and `List` are always imported (needed for response types)
- Additional typing imports (`Dict`, `Any`, `Set`) added only when used
- `datetime` imports handled separately from typing imports
- No more duplicate import statements

### Fixed - AppSync CDK Authorization Default (Issue #23)

#### Changed Default Auth from USER_POOL to API_KEY
- **Bug Fix**: AppSync CDK constructs now default to `API_KEY` authorization
- **Root Cause**: `USER_POOL` authorization requires `user_pool_config` which wasn't provided
- **Solution**: Changed default to `API_KEY` which works out-of-the-box without additional configuration

#### Breaking Change
- Projects relying on `USER_POOL` as the default will need to configure auth explicitly
- Future release will add configurable auth types via `schema-generator.yml`

#### Example
```typescript
// Before (broken - USER_POOL without config)
authorizationType: appsync.AuthorizationType.USER_POOL,

// After (working - API_KEY default)
authorizationType: appsync.AuthorizationType.API_KEY,
```

## [0.7.4] - 2024-12-23

### Fixed - CDK Python Stack Import Error (Issue #22)

#### Python Uses Absolute Imports
- **Bug Fix**: Python CDK stack files now use absolute imports instead of relative imports
- **Root Cause**: Python relative imports (`from ..cdk`) navigate package hierarchy, not filesystem. When CDK runs `python app.py`, `lib/` is a top-level module with no parent package.
- **Solution**: Changed to absolute imports (`from cdk.tables.users_table import`) which resolve from `sys.path`

#### TypeScript Unchanged
- TypeScript continues using relative imports (`../cdk/tables/`) as this is standard CDK convention and works correctly

#### New ConfigurationError
- Added `ConfigurationError` exception for invalid configurations
- Raised when `cdk_output_dir` is outside `stack_output_dir`

#### Example
```python
# Before (broken - relative imports)
from ..cdk.tables.users_table import UsersTable

# After (fixed - absolute imports)
from cdk.tables.users_table import UsersTable
```

## [0.7.3] - 2024-12-19

### Breaking - Standardized Config Keys

#### CDK Config Uses `base_dir`
- **Breaking**: CDK config key changed from `output` to `base_dir`
- **Consistent**: All output configs now use `base_dir` (python, typescript, dart, graphql, cdk)

#### Migration
```yaml
# Before (0.7.2 and earlier)
output:
  infrastructure:
    cdk:
      output: infrastructure/cdk  # OLD

# After (0.7.3+)
output:
  infrastructure:
    cdk:
      base_dir: infrastructure/cdk  # NEW
```

## [0.7.2] - 2024-12-19

### Fixed - CDK Stack Import Paths (Issue #21)

#### Import Path Calculation Fix
- **Bug Fix**: Stack imports now correctly calculate relative paths to `cdk_output_dir`
- **Dynamic path resolution**: Import paths are computed based on actual directory structure
- **Example**: When `base_dir: infrastructure/cdk`, stack imports `from ..cdk.tables.users_table`

#### Removed `generated/` from Default Path
- **Changed default `cdk_output_dir`**: `./infrastructure/cdk` (was `./infrastructure/cdk/generated`)
- **Cleaner structure**: No more `generated/` subdirectory in default paths

#### Generated Directory Structure
```
infrastructure/
├── app.py              # CDK app entry point
├── cdk.json
├── lib/
│   └── backend_stack.py   # Stack imports from ../cdk/tables/
└── cdk/
    ├── tables/
    │   └── users_table.py
    └── appsync/
        └── api.py
```

#### Configuration (standardized)
```yaml
output:
  infrastructure:
    cdk:
      base_dir: infrastructure/cdk   # Preferred (was 'output')
      language: python
      generate_stack: true
      stack_name: backend_stack
```

## [0.7.1] - 2024-12-19

### Fixed - CDK Stack Import Paths and Naming (Issue #21)

#### Stack Import Path Fix
- **Bug Fix**: Stack imports now correctly reference sibling directories (`../tables/`, `../appsync/`)
- **Removed `generated/` nesting**: Constructs are generated directly in `tables/`, `appsync/` subdirectories
- **Cleaner structure**: No more redundant `generated/` directory in import paths

#### Generic Stack Naming
- **New `stack_name` option**: Configure stack file name (defaults to `backend_stack`)
- **LLM-friendly naming**: Generic names like `backend_stack.py` instead of project-specific names
- **Flat app entry point**: `app.py`/`app.ts` at root instead of `bin/{project}.ts`

#### New Defaults
- **`language: python`**: Python CDK is now the default (was typescript)
- **`generate_stack: true`**: Stack generation enabled by default (was false)

#### Generated Directory Structure
```
infrastructure/
├── app.py              # CDK app entry point
├── cdk.json
├── lib/
│   └── backend_stack.py   # Stack class (configurable name)
├── tables/
│   └── users_table.py
└── appsync/
    └── api.py
```

#### Configuration
```yaml
output:
  infrastructure:
    cdk:
      output: ./infrastructure
      language: python
      generate_stack: true         # Default: true
      stack_name: backend_stack    # Optional, defaults to "backend_stack"
```

### Added - CDK Documentation (Issue #20, Items 3, 4, 6, 7, 9, 10, 11, 12, 13)

#### New Documentation
- **CDK Integration Guide** (`docs/cdk-integration-guide.md`): How to integrate generated constructs with existing CDK stacks
- **CDK Local Development** (`docs/cdk-local-development.md`): Local testing with SAM, LocalStack, and dev environments
- **GitHub Actions Examples** (`docs/github-actions-examples/`): CI/CD workflow templates for schema validation and CDK deployment

#### Documentation Updates
- **Lambda Resolver Integration**: Handler signatures, CDK wiring, SSM parameter patterns
- **Environment/Stage Support**: Resource naming, CDK context, stack parameterization
- **Schema Validation**: AppSync directives, supported scalars, error reporting
- Advanced MCP watch mode integration
- Enhanced AI-powered schema analysis
- Lambda resolver generation for AppSync

## [0.7.0] - 2024-12-19

### Added - CDK Stack Generation (Issue #20, Item 2)

#### Complete CDK Stack Scaffolding
- **Stack Generation**: New `generate_stack: true` option generates complete CDK stack files
- **TypeScript Stack**: Generates `lib/{project}-stack.ts`, `bin/{project}.ts`, and `cdk.json`
- **Python Stack**: Generates `lib/{project}_stack.py`, `app.py`, and `cdk.json`
- **Construct Wiring**: Stack automatically imports and instantiates all generated table and API constructs
- **CloudFormation Outputs**: Exports API URL and table names

#### Stack Configuration
```yaml
output:
  infrastructure:
    cdk:
      output: ./infrastructure/cdk/generated
      language: typescript  # or "python"
      generate_stack: true
      stack_output_dir: ./infrastructure/cdk  # optional
```

#### File Collision Handling
- **Safe Regeneration**: Stack files are only generated if they don't exist
- **Customization Preserved**: Existing stack files are never overwritten
- **Warning Logged**: Clear warning when skipping existing files

#### Generated Stack Features
- Environment-based stack naming (`{Project}Stack-{env}`)
- Standard CDK tags (project, environment)
- Removal policy configuration via CDK context
- Proper construct imports from generated directory

#### Testing
- **10 new tests** for stack generation (6 in TestCDKStackGeneration, 4 in TestCDKStackGenerationConfig)
- **637 total tests passing**

## [0.6.5] - 2024-12-19

### Fixed - Python CDK Generation and GraphQL Path Resolution (Issue #20, Items 1, 5)

#### Python CDK Language Support
- **Bug Fix**: `language: python` configuration now correctly generates Python CDK constructs
- **Python Table Constructs**: Generates `{name}_table.py` files with proper `aws_cdk` imports
- **Python AppSync Constructs**: Generates `api.py` with Python CDK syntax
- **Python Index Files**: Generates `__init__.py` with proper exports
- **PEP 8 Compliance**: Uses snake_case for file names and method calls

#### GraphQL Schema Path Resolution
- **Bug Fix**: Replaced hardcoded `'path/to/schema.graphql'` with auto-resolved path
- **Relative Path Calculation**: Calculates correct relative path from CDK output to GraphQL schema
- **Cross-Platform**: Uses forward slashes for Windows compatibility
- **TypeScript**: Uses `path.join(__dirname, 'relative/path')` for resolution

#### Generated Code Headers
- **All Generated Files**: Now include `// AUTO-GENERATED by orb-schema-generator vX.X.X - DO NOT EDIT`
- **Regeneration Command**: Header includes `orb-schema generate` command
- **Both Languages**: TypeScript uses `//` comments, Python uses `#` comments

#### Configuration Example
```yaml
output:
  infrastructure:
    cdk:
      output: ./infrastructure/cdk/generated
      language: python  # Now works! Generates Python CDK constructs
```

#### Testing
- **26 new property-based tests** for Python CDK generation
- **638 total tests passing**

## [0.6.4] - 2024-12-18

### Fixed - Cross-Subdirectory Import Paths (Issue #19)

#### Problem
When `enums_subdir` and `models_subdir` were configured to different directories (e.g., `enums/` vs `models/`), generated model files produced incorrect import paths that assumed all files were in the same directory.

#### Solution
- **Centralized Path Calculation**: Added `relative_import_path()` method to `OutputConfig` - single source of truth for all generators
- **Dart**: Now generates `import '../enums/alert_type.dart';` instead of `import 'alert_type.dart';`
- **TypeScript**: Now generates `import { AlertType } from '../enums/AlertTypeEnum';` instead of `import { AlertType } from './AlertTypeEnum';`
- **Python**: Now generates `from ..enums.alert_type_enum import AlertType` instead of `from .alert_type_enum import AlertType`

#### Edge Cases Handled
- Same directory (both subdirs equal): Uses `./` prefix
- Empty subdirectories: Correctly navigates to/from base directory
- Nested subdirectories (e.g., `types/enums`): Calculates correct relative path

## [0.6.3] - 2024-12-18

### Fixed - Universal Reference Resolution (Issue #18)

#### Model References in All Generators
- **Array References**: `items.$ref` now correctly resolves to `List<Model>` (Dart), `List[Model]` (Python), `Model[]` (TypeScript), `[Model!]!` (GraphQL)
- **Object References**: `object_ref` now correctly resolves to the referenced model type instead of `Map<String, dynamic>`
- **DRY Architecture**: Reference resolution centralized in schema loader - all generators benefit from single implementation

#### Import Generation
- **Automatic Imports**: Referenced models are automatically imported in generated code
- **Deduplication**: Multiple references to same model produce single import statement
- **Cross-Language**: Python, TypeScript, and Dart all generate appropriate import statements

#### JSON Serialization (Dart)
- **Array fromJson**: Generates `.map((e) => Model.fromJson(e)).toList()` for array refs
- **Array toJson**: Generates `.map((e) => e.toJson()).toList()` for array refs
- **Object fromJson**: Generates `Model.fromJson(json['field'])` for object refs
- **Object toJson**: Generates `field.toJson()` for object refs
- **Null Safety**: Optional refs include proper null checks (`?.toJson()`)

#### Configuration Example
```yaml
name: TrackingSession
type: standard
model:
  attributes:
    points:
      type: array
      items:
        $ref: "GPSPoint"
      required: true
    area:
      type: object
      object_ref: "AreaMeasurement"
      required: false
```

#### Testing
- **13 new property-based tests** for reference resolution across all generators
- **579 total tests passing** with 70%+ coverage

## [0.6.2] - 2024-12-18

### Fixed - Dart Duplicate Files and Hive typeId Conflicts (Issue #17)

#### Duplicate File Prevention
- **Single File Generation**: Enum files are now generated exactly once to the `enums/` subdirectory
- **Removed Duplicate Call**: Fixed main generator calling both `generate()` and deprecated `generate_dart_enums()`
- **Clean Output**: No more duplicate files in root output directory

#### Hive typeId Configuration
- **Configurable Starting typeId**: New `hive_type_id_start` option to avoid conflicts with existing models
- **Sequential Assignment**: typeIds are assigned sequentially from the configured start value
- **Default Behavior**: Starts at 0 if not configured (backward compatible)

#### Configuration Example
```yaml
output:
  dart:
    enabled: true
    options:
      hive: true
      hive_type_id_start: 100  # Avoid conflicts with existing models
```

#### Migration
If upgrading from v0.6.1 or earlier:
1. Delete duplicate `.dart` files from your output root directory
2. Keep only files in `enums/` and `models/` subdirectories
3. Regenerate to ensure clean output

#### Testing
- **8 new property-based tests** for duplicate file prevention and typeId management
- **559 total tests passing** with 70.87% coverage

## [0.6.1] - 2024-12-18

### Fixed - Windows Console Output and Dart Enum Imports (Issues #15, #16)

#### Windows Console Compatibility (Issue #15)
- **Unicode/ASCII Fallback**: Console output now detects terminal encoding and uses ASCII-safe symbols (`[OK]`, `[FAIL]`, `[WARN]`, `[INFO]`) on Windows cp1252 terminals instead of emoji (✅, ❌, ⚠️, ℹ️)
- **No More UnicodeEncodeError**: Windows developers can now run the generator without encoding errors
- **Encoding Detection**: Automatic detection of UTF-8 vs non-UTF-8 terminals with caching for performance

#### Warning Message Improvements (Issue #15)
- **enums.yml Warning Level**: Changed from WARNING to INFO when `enums.yml` is not found (individual enum schema files are the preferred pattern)
- **Schema Type Warnings**: Now include the actual directory path and explain that the explicit `type` field takes precedence

#### Dart Enum Import Generation (Issue #16)
- **Automatic Enum Imports**: Dart generator now automatically generates import statements for `enum_ref` fields
- **Snake_case File Paths**: Import paths follow Dart conventions (e.g., `import 'alert_type.dart';` for `AlertType`)
- **Multiple Enum Support**: All referenced enums are imported, with deduplication for repeated references
- **Cross-Generator Consistency**: Python, TypeScript, and Dart generators all follow the same enum import pattern

#### New Console Utilities
- **`src/utils/console.py`**: New module with encoding-safe output functions
  - `success(message)` - Format success messages
  - `error(message)` - Format error messages
  - `warning(message)` - Format warning messages
  - `info(message)` - Format info messages
  - `get_symbol(name)` - Get appropriate symbol for terminal encoding

#### Testing
- **16 new unit tests** for console output encoding
- **8 new unit tests** for Dart enum imports
- **4 new property-based tests** for cross-generator enum import consistency
- **3 new unit tests** for warning message improvements
- **551 total tests passing** with 70.82% coverage

## [0.6.0] - 2024-12-18

### Breaking Changes - Nx-Style Directory Structure

**Default output paths changed to Nx/Turborepo-style `apps/` structure.**

Legacy `backend` and `frontend` config keys are no longer supported.

#### New Default Paths

| Language | Old Default | New Default |
|----------|-------------|-------------|
| Python | `./generated/python` | `./apps/api` |
| TypeScript | `./generated/typescript` | `./apps/web` |
| Dart | `./generated/dart` | `./apps/mobile/lib` |
| GraphQL | `./generated/graphql` | `./apps/api/graphql` |
| CDK | `./infrastructure/lib/generated` | `./infrastructure/cdk/generated` |

#### Migration

Update `schema-generator.yml` to use new config keys:

```yaml
# Old (no longer supported)
output:
  backend:
    models: ./backend/models
  frontend:
    models: ./frontend/models

# New
output:
  python:
    base_dir: ./apps/api
  typescript:
    base_dir: ./apps/web
  dart:
    base_dir: ./apps/mobile/lib
  graphql:
    base_dir: ./apps/api/graphql
```

#### Why This Change?

- **LLM Discoverability**: Nx/Turborepo is the most common monorepo pattern
- **Consistency**: All deployable apps (including backend API) under `apps/`
- **Industry Standard**: Aligns with modern monorepo best practices

#### Related

- Spec: `.kiro/specs/nx-style-directory-structure/`
- orb-templates issue: https://github.com/com-oneredboot/orb-templates/issues/5

### Changed

- Moved `example_schemas/` to `tests/fixtures/example_schemas/`
- Added `apps/` to `.gitignore` (generated output directory)

### Fixed

- Fixed flaky property test for package naming (min length check 1→2)

## [0.5.4] - 2024-12-18

### Fixed - Duplicate Output to Default Paths (Issue #14)
- **Single Source of Truth**: `OutputConfig` is now the ONLY path system for all generators
- **No Duplicate Files**: Custom output paths no longer also generate to `./generated/` directory
- **Legacy Config Support**: Both new (`output.python.output`) and legacy (`output.backend.models`) YAML formats work correctly
- **DRY Architecture**: Removed legacy path fields (`backend_models_dir`, `frontend_models_dir`, etc.)

#### Root Cause
The config system had TWO path systems:
1. Legacy paths: `backend_models_dir`, `frontend_models_dir`, etc.
2. New OutputConfig: `python_output`, `typescript_output`, etc.

When custom paths were configured via legacy YAML keys, the new `OutputConfig` objects weren't updated, causing generators to use default paths.

#### Solution
- Removed all legacy path fields from `GeneratorConfig`
- All generators now use `OutputConfig` exclusively
- Config parsing normalizes all YAML formats to `OutputConfig`
- Fluent API methods set `OutputConfig` directly

#### Example - Now Works Correctly
```yaml
output:
  backend:
    models: ./backend/models    # → python_output.base_dir
  dart:
    output: ./apps/mobile/lib   # → dart_output.base_dir
```

Files are generated ONLY to the configured paths, not also to `./generated/`.

## [0.5.3] - 2024-12-17

### Fixed - Registry Schema Loading from Any Directory (Issue #13)
- **All Subdirectories Scanned**: Schema loader now scans ALL configured subdirectories, not just specific ones
- **Type Field is Source of Truth**: Schema `type` field determines processing, not directory location
- **Mixed Types Supported**: Same directory can contain `type: registry`, `type: standard`, etc.
- **Core Directory No Longer Skipped**: Previously, `core/` subdirectory was explicitly skipped
- **Non-Schema Files Gracefully Skipped**: Files without `name` field (e.g., `types.yml`, `validators.yml`) are now skipped instead of causing errors

#### Root Cause
The schema loader had logic that skipped the `core` subdirectory entirely, assuming it only contained non-schema files. This caused `type: registry` schemas in `core/` to never be loaded.

#### Additional Fix
When scanning all directories, type definition files (like `core/types.yml`) that don't have a `name` field are now gracefully skipped instead of causing validation errors.

#### Example - Now Works
```
schemas/
├── core/
│   ├── AlertType.yml      # type: registry ✓ Now loaded!
│   └── WarningType.yml    # type: registry ✓ Now loaded!
└── models/
    └── Alert.yml          # type: standard
```

#### Documentation
- Updated `docs/schema-organization.md` to clarify type detection priority
- Schema `type` field is the recommended way to specify schema type

## [0.5.2] - 2024-12-17

### Fixed - Registry Enum Generation (Issue #12)
- **RegistryType Support**: `type: registry` schemas now generate Dart enums via unified `generate()` method
- **Enhanced Enum Syntax**: Uses Dart 2.17+ enhanced enums with value parameter
- **JSON Serialization**: Generated enums include `toJson()` and `fromJson()` methods
- **Output Location**: Enums output to `enums/` subdirectory (1 enum = 1 file)
- **Naming Conventions**: SCREAMING_SNAKE_CASE → camelCase for enum values

#### Example Generated Enum
```dart
enum AlertType {
  accuracyExceeded('accuracy_exceeded'),
  closureDetected('closure_detected');

  const AlertType(this.value);
  final String value;

  String toJson() => value;
  static AlertType fromJson(String json) { ... }
}
```

## [0.5.1] - 2024-12-17

### Fixed - Dart Naming Conventions (Issue #11)

#### Dart Style Guide Compliance
- **Class Names**: Acronyms now preserved (`GPSPoint` stays `GPSPoint`, not `GpsPoint`)
- **Field Names**: Now use camelCase (`squareMeters`, not `square_meters`)
- **Constructor Parameters**: Use camelCase (`required this.squareMeters`)
- **copyWith Parameters**: Use camelCase (`double? squareMeters`)

#### JSON Serialization Mapping
- `fromJson()` maps snake_case JSON keys to camelCase Dart fields
- `toJson()` maps camelCase Dart fields back to snake_case JSON keys
- Maintains API compatibility while following Dart conventions

#### Example
```dart
// Schema: square_meters → Dart: squareMeters
factory AreaMeasurement.fromJson(Map<String, dynamic> json) {
  return AreaMeasurement(
    squareMeters: (json['square_meters'] as num).toDouble(),
  );
}
```

### Fixed - Schema Loader enum_ref Resolution (Issue #10)
- `enum_ref` fields now correctly resolve to `enum_type` in schema loader
- Fixes enum type resolution for Dart and other generators

## [0.5.0] - 2024-12-16

### Added - Dart/Flutter Code Generation (Issue #9)

#### DartGenerator
- **Model Classes**: Complete Dart model generation from YAML schemas
- **JSON Serialization**: `fromJson()` factory and `toJson()` method with proper type conversions
- **Immutability Support**: `final` fields and `copyWith()` method for state management
- **Null Safety**: Full Dart 2.12+ null safety with `?` suffix for optional fields
- **Named Constructors**: `required` keyword for required parameters

#### Hive Integration (Optional)
- **Type Adapters**: `@HiveType(typeId: n)` annotations for local storage
- **Field Annotations**: `@HiveField(n)` with sequential indices
- **Part Directive**: Automatic `part 'filename.g.dart';` generation
- **Unique TypeIds**: Tracking across multiple models for uniqueness

#### Equatable Integration (Optional)
- **State Management**: `extends Equatable` for BLoC and other patterns
- **Props Override**: Automatic `props` getter with all fields
- **Package Import**: Automatic equatable import when enabled

#### Enum Generation
- **Dart Enums**: Generate Dart enums from schema enum definitions
- **Hive Support**: Optional Hive annotations on enums
- **Type References**: Proper enum type usage in model fields

#### Type Mapping
- `string` → `String`
- `float`/`number` → `double`
- `integer` → `int`
- `boolean` → `bool`
- `datetime`/`timestamp` → `DateTime`
- `array<T>` → `List<T>`
- `object` → `Map<String, dynamic>`
- `set` → `Set<String>`

#### Configuration
- **DartConfig**: New dataclass with enabled, output_dir, hive, equatable, immutable, null_safety
- **Generator Enable Flags**: `python_enabled`, `typescript_enabled`, `dart_enabled` in GeneratorConfig
- **Backward Compatibility**: Python/TypeScript default enabled, Dart default disabled (opt-in)
- **YAML Config**: `output.dart.enabled`, `output.dart.output`, `output.dart.options.*`

#### Testing
- **32 Property-Based Tests**: Hypothesis-based tests with 100 iterations each
- **14 Correctness Properties**: JSON round-trip, nullability, immutability, Hive, Equatable, naming
- **433 Total Tests Passing**: Full test suite with 68.72% coverage

#### Documentation
- **docs/dart-generation.md**: Complete configuration and usage guide
- **example_schemas/dart_example/**: Example GPS Point schema

### Technical Details
- **File Naming**: `snake_case.dart` for models, `snake_case_enum.dart` for enums
- **Class Naming**: `PascalCase` following Dart conventions
- **Field Naming**: `snake_case` for Dart field names
- **DateTime Handling**: ISO8601 string serialization in JSON

## [0.4.0] - 2024-12-16

### Added - VTL Resolver Generation for AppSync (Issue #7)

#### VTL Generator
- **CRUD Operations**: Complete VTL templates for PutItem, UpdateItem, DeleteItem, GetItem, Query
- **Request Templates**: DynamoDB-specific request mapping templates with proper key handling
- **Response Templates**: Error handling and JSON serialization for all operations
- **Pagination Support**: Built-in limit and nextToken handling for Query operations
- **Secondary Index Queries**: Automatic GSI query template generation

#### VTL Template Builder Utility
- **Fluent API**: Builder pattern for constructing VTL templates programmatically
- **Syntax Validation**: Validates balanced braces, brackets, and VTL directives
- **DynamoDB Helpers**: Utility methods for key construction and attribute mapping

#### CDK Integration
- **Resolver Wiring**: Automatic resolver attachment when VTL generation is enabled
- **MappingTemplate.fromFile()**: CDK constructs reference generated VTL files
- **Data Source Configuration**: DynamoDB data sources with proper table references

#### Configuration
- **AppSyncConfig**: New dataclass for AppSync-specific settings
- **CLI Flags**: `--generate-resolvers` and `--resolver-output` options
- **YAML Config**: `output.infrastructure.appsync.generateResolvers` setting

#### Testing
- **77 Tests**: 56 for VTL generator, 21 for builder utility
- **11 Property-Based Tests**: Hypothesis-based tests with 100 iterations each
- **Correctness Properties**: CRUD completeness, key handling, syntax validity

### Technical Details
- **File Naming**: `{TypeName}.{FieldName}.{request|response}.vtl` convention
- **TypeName Mapping**: Mutation for write ops, Query for read ops
- **Key Exclusion**: UpdateItem excludes partition/sort keys from update expressions
- **VTL Version**: Uses `2018-05-29` resolver format

### Scope
- **Included**: DynamoDB direct resolvers (schema type: `dynamodb`)
- **Not Included**: Lambda-backed resolvers (`lambda`, `lambda-dynamodb` types) - planned for future release

## [0.3.0] - 2024-12-15

### Major Fixes - Type Mapping and Code Generation

**Addresses GitHub Issues #1-#5 reported by orb-geo-fence team**

#### Fixed Python Generator (Issue #1)
- **Correct Type Mappings**: `float` → `float`, `integer` → `int`, `datetime` → `datetime` (was all `str`)
- **Pydantic Validation**: Added support for `min`/`max`/`pattern` constraints → `Field(ge=, le=, pattern=)`
- **Optional Fields**: Proper `Optional[type]` annotations with required imports
- **Import Management**: Automatic `datetime`, `Optional`, `Dict`, `Any` imports

#### Fixed TypeScript Generator (Issue #2)
- **Valid TypeScript Types**: `float` → `number`, `datetime` → `Date` (was invalid TS types)
- **Optional Syntax**: `field?: type` instead of `field: type | undefined`
- **Constructor Generation**: Proper initialization with defaults instead of `undefined` assignments
- **Type Validity**: All generated types are valid TypeScript

#### Fixed GraphQL Generator (Issue #3)
- **Correct Type Mappings**: `float` → `Float`, `datetime` → `DateTime` (was `Int`)
- **Scalar Definitions**: Automatic `scalar DateTime` generation
- **Enum Generation**: Proper enum type definitions from `enum_ref`
- **Reference Resolution**: `[ModelName]!` for array references instead of `[String]!`

#### Fixed Validation Constraints (Issue #4)
- **Python**: YAML constraints → Pydantic `Field(ge=min, le=max, pattern="regex")`
- **Constraint Preservation**: Exact numeric values and patterns preserved
- **Multiple Constraints**: Combined in single Field definition
- **Import Handling**: Automatic Pydantic imports when constraints used

#### Fixed Output Directory Structure (Issue #5)
- **Exact Path Placement**: Files generated in configured directories without `generated/` prefix
- **Path Configuration**: `output.backend.models: ./backend/models` → files in `./backend/models/`
- **No Unwanted Nesting**: Removed automatic directory prefixes
- **Multiple Paths**: Independent handling of different output configurations

### Technical Improvements

#### Enhanced Type Mapping System
- **Comprehensive TypeMapping**: Dataclass with Python/TypeScript/GraphQL mappings
- **Validation Constraints**: Built-in constraint translation system
- **Reference Resolution**: Support for `$ref` and `enum_ref` resolution
- **Import Management**: Automatic tracking of required imports
- **Extensible Design**: Easy to add new types and mappings

#### Property-Based Testing
- **Hypothesis Integration**: 100+ property-based tests with 100 iterations each
- **Cross-Generator Consistency**: Validates type mapping consistency
- **Constraint Preservation**: Verifies validation constraint translation
- **Path Exactness**: Tests output directory handling
- **Type Validity**: Ensures generated code uses valid language types

#### Error Handling
- **Unsupported Types**: Clear error messages with supported type lists
- **Path Validation**: Early detection of invalid output paths
- **Constraint Validation**: Validation of constraint values before processing
- **Reference Resolution**: Specific errors for unresolvable references

### Breaking Changes
- **Output Paths**: Files no longer automatically placed in `generated/` subdirectory
- **Type Mappings**: More accurate type mappings may require code updates
- **TypeScript**: Optional field syntax changed from `| undefined` to `?`
- **GraphQL**: DateTime fields now use `DateTime` scalar instead of `Int`

### Migration Guide
- See `docs/type-mapping-fixes.md` for detailed migration instructions
- Update output path configurations if relying on `generated/` prefix
- Review generated code for improved type accuracy
- Add GraphQL scalar definitions for DateTime fields

### Testing
- **213 tests passing** with 62% code coverage
- **Property-based tests** validate correctness across random inputs
- **Integration tests** with real-world schema examples
- **Cross-platform compatibility** verified

### Pipeline Fixes (No Version Change)
- **CodeArtifact Publishing Workflow** - Fixed JMESPath field name in package verification (packageName → package)
- **Package Verification** - Corrected package name consistency in verification step
- **CI/CD Reliability** - Resolved verification failures after successful publishing

## [0.2.0] - 2024-12-13

### Added
- **Automated Version Management System**
  - Interactive pre-commit version prompts for patch/minor/major updates
  - Automated version validation and semantic versioning enforcement
  - Integration with CodeArtifact publishing workflow
  - UTF-8 encoding fixes for cross-platform compatibility

- **Enhanced CodeArtifact Publishing**
  - Exponential backoff retry mechanism (1,2,4,8,16,32,64,128s) for package verification
  - Package name consistency fixes (orb-schema-generator vs orb_schema_generator)
  - Comprehensive error handling and logging with status indicators
  - Build artifact cleanup to prevent version conflicts

- **Developer Experience Improvements**
  - Version management documentation with workflow guides
  - Pre-commit hook integration for seamless development
  - Bypass mechanism with NO_VERSION_CHECK environment variable
  - Automated staging of version files during commits

### Fixed
- **Publishing Workflow Reliability**
  - Fixed package verification step with proper retry logic
  - Resolved package naming mismatches between metadata and files
  - Improved error messages and troubleshooting information
  - Enhanced installation testing with isolated environments

### Technical Details
- **Version Management**: Fully automated with interactive prompts
- **Publishing**: Robust retry mechanism with ~5 minute timeout
- **Testing**: All 18 property-based tests passing
- **Documentation**: Comprehensive version management and release process guides

## [0.1.0] - 2024-12-11

### Added
- **Complete Schema-to-Code Generation Pipeline**
  - Python model generation with Pydantic validation
  - TypeScript model generation with interfaces and classes
  - GraphQL schema generation with auth directives
  - AWS CDK construct generation for DynamoDB and AppSync
  - Enum generation for both Python and TypeScript

- **Professional Development Workflow**
  - Automated publishing to AWS CodeArtifact on GitHub releases
  - Pre-commit hooks with code quality gates (black, ruff, mypy, bandit)
  - Comprehensive property-based testing with Hypothesis
  - Unit tests with 80%+ coverage

- **Enhanced Developer Experience**
  - Fluent Python API for programmatic use
  - Watch mode for automatic regeneration on file changes
  - Dry-run and diff modes for previewing changes
  - Rich CLI with selective generation capabilities
  - Interactive mode for approving changes

- **Schema Organization System**
  - Type-based directory structure (core/, entities/, templates/)
  - Automatic schema type detection
  - Migration tool for restructuring schemas
  - Support for both organized and flat structures

- **AI Assistant Integration**
  - MCP (Model Context Protocol) server for Kiro IDE
  - Schema validation and inspection tools
  - Core generation capabilities accessible via MCP
  - Integration with AI development workflows

- **Event System & Progress Tracking**
  - Real-time progress updates during generation
  - Event-driven architecture with sync/async callbacks
  - Detailed generation statistics and metadata
  - Comprehensive error handling and reporting

### Technical Details
- **Generated Files**: Successfully generates 83+ files from 17 example schemas
- **Performance**: Complete generation in ~2 seconds
- **Languages**: Python 3.10+, TypeScript, GraphQL
- **Infrastructure**: AWS CDK constructs for DynamoDB and AppSync
- **Testing**: Property-based tests for all 10 correctness properties
- **Documentation**: Complete setup guides and troubleshooting resources

### Breaking Changes
- None (initial release)

### Migration Guide
- This is the initial release, no migration needed

---

## Version Strategy

- **0.1.x**: Core functionality, bug fixes, documentation improvements
- **0.2.x**: AI features (natural language generation, automated migrations)
- **0.3.x**: Advanced integrations (GitHub Actions, VS Code extension, Web API)
- **1.0.x**: Stable API, production-ready for enterprise use

## Contributing

When making changes that affect the public API or add new features:

1. The pre-commit hook will prompt you to update the version
2. Update this CHANGELOG.md with your changes
3. Follow semantic versioning guidelines:
   - **Patch** (0.1.1): Bug fixes, documentation updates
   - **Minor** (0.2.0): New features, backward compatible
   - **Major** (1.0.0): Breaking changes

## Support

- **Documentation**: See `docs/` directory
- **Issues**: GitHub Issues for bug reports and feature requests
- **Discussions**: GitHub Discussions for questions and community support
