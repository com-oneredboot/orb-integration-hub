"""Generation result metadata."""

from dataclasses import dataclass, field
from typing import List, Dict, Any
from pathlib import Path


@dataclass
class GenerationResult:
    """
    Result of schema generation with statistics and metadata.
    """

    success: bool = True
    files_generated: List[str] = field(default_factory=list)
    schemas_processed: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    elapsed_time: float = 0.0
    stage_times: Dict[str, float] = field(default_factory=dict)

    @property
    def files_count(self) -> int:
        """Get total number of files generated."""
        return len(self.files_generated)

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0

    def add_file(self, file_path: str) -> None:
        """
        Add a generated file to the result.

        Args:
            file_path: Path to generated file
        """
        self.files_generated.append(file_path)

    def add_error(self, error: str) -> None:
        """
        Add an error to the result.

        Args:
            error: Error message
        """
        self.errors.append(error)
        self.success = False

    def add_warning(self, warning: str) -> None:
        """
        Add a warning to the result.

        Args:
            warning: Warning message
        """
        self.warnings.append(warning)

    def get_summary(self) -> Dict[str, Any]:
        """
        Get result summary.

        Returns:
            Dictionary with result information
        """
        return {
            "success": self.success,
            "files_count": self.files_count,
            "schemas_processed": self.schemas_processed,
            "errors_count": len(self.errors),
            "warnings_count": len(self.warnings),
            "elapsed_time": self.elapsed_time,
            "stage_times": self.stage_times,
        }

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get detailed statistics.

        Returns:
            Dictionary with detailed statistics
        """
        # Group files by type
        file_types: Dict[str, int] = {}
        for file_path in self.files_generated:
            ext = Path(file_path).suffix
            file_types[ext] = file_types.get(ext, 0) + 1

        return {
            "total_files": self.files_count,
            "files_by_type": file_types,
            "schemas_processed": self.schemas_processed,
            "errors": len(self.errors),
            "warnings": len(self.warnings),
            "total_time": self.elapsed_time,
            "avg_time_per_schema": (
                self.elapsed_time / self.schemas_processed if self.schemas_processed > 0 else 0
            ),
        }

    def __repr__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return (
            f"GenerationResult(status={status}, "
            f"files={self.files_count}, "
            f"schemas={self.schemas_processed}, "
            f"errors={len(self.errors)}, "
            f"warnings={len(self.warnings)})"
        )
