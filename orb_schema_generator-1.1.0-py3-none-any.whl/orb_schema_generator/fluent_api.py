"""Fluent API for programmatic schema generation."""

from pathlib import Path
from typing import Optional, List, Callable, Dict, Any, AsyncIterator
import logging
import asyncio

from .core.config import GeneratorConfig
from .generator import SchemaGenerator

logger = logging.getLogger(__name__)


class Generator:
    """
    Fluent API for schema generation.

    Example:
        generator = (Generator()
            .schemas('./schemas')
            .python('./generated/backend/models', './generated/backend/enums')
            .typescript('./generated/frontend/models')
            .graphql('./generated/frontend/graphql')
            .cdk('./generated/infrastructure/cdk')
            .on_complete(lambda result: print(f"Generated {result.files_count} files"))
            .generate())
    """

    def __init__(self):
        """Initialize the generator with default configuration."""
        self._config = GeneratorConfig()
        self._callbacks = {
            "start": [],
            "progress": [],
            "file_generated": [],
            "complete": [],
            "error": [],
        }
        self._only_schemas: Optional[List[str]] = None
        self._exclude_schemas: Optional[List[str]] = None
        self._only_formats: Optional[List[str]] = None

    @classmethod
    def from_config(cls, config_path: str) -> "Generator":
        """
        Create generator from configuration file.

        Args:
            config_path: Path to configuration YAML file

        Returns:
            Generator instance
        """
        instance = cls()
        instance._config = GeneratorConfig.from_file(config_path)
        return instance

    @classmethod
    def from_config_object(cls, config: GeneratorConfig) -> "Generator":
        """
        Create generator from configuration object.

        Args:
            config: GeneratorConfig instance

        Returns:
            Generator instance
        """
        instance = cls()
        instance._config = config
        return instance

    def schemas(self, path: str, subdirectories: Optional[Dict[str, str]] = None) -> "Generator":
        """
        Set schema directory.

        Args:
            path: Path to schema directory
            subdirectories: Optional subdirectory configuration. Pass None for flat structure.

        Returns:
            Self for chaining
        """
        self._config.schema_dir = Path(path)
        # Always set subdirectories - None means flat structure
        self._config.schema_subdirectories = subdirectories
        return self

    def python(self, models_dir: str, enums_dir: Optional[str] = None) -> "Generator":
        """
        Configure Python output.

        Args:
            models_dir: Directory for Python models
            enums_dir: Directory for Python enums (optional)

        Returns:
            Self for chaining
        """
        from .core.config import OutputConfig

        models_path = Path(models_dir)
        enums_subdir = "enums"

        if enums_dir:
            enums_path = Path(enums_dir)
            # Check if enums is relative to models
            try:
                enums_subdir = str(enums_path.relative_to(models_path))
            except ValueError:
                # Different base paths - put enums in subdir of models base
                enums_subdir = "enums"

        output_config = OutputConfig(
            base_dir=models_path,
            enums_subdir=enums_subdir,
            models_subdir="",  # Models go directly in base_dir
        )
        self._config.python_output = output_config
        # Also set up targets for target validation
        # Use "default" as the target name for fluent API usage
        self._config.python_targets = {"default": output_config}
        return self

    def typescript(self, models_dir: str) -> "Generator":
        """
        Configure TypeScript output.

        Args:
            models_dir: Directory for TypeScript models

        Returns:
            Self for chaining
        """
        from .core.config import OutputConfig

        self._config.typescript_output = OutputConfig(
            base_dir=Path(models_dir),
            enums_subdir="enums",
            models_subdir="",  # Models go directly in base_dir
        )
        return self

    def graphql(self, output_dir: str) -> "Generator":
        """
        Configure GraphQL output.

        Args:
            output_dir: Directory for GraphQL schema

        Returns:
            Self for chaining
        """
        from .core.config import OutputConfig

        self._config.graphql_output = OutputConfig(
            base_dir=Path(output_dir),
            enums_subdir="",
            models_subdir="",
        )
        return self

    def cdk(self, output_dir: str, language: str = "typescript") -> "Generator":
        """
        Configure CDK output.

        Args:
            output_dir: Directory for CDK constructs
            language: CDK language (default: typescript)

        Returns:
            Self for chaining
        """
        self._config.cdk_output_dir = Path(output_dir)
        self._config.cdk_language = language
        self._config.infrastructure_format = "cdk"
        return self

    def cloudformation(self, output_dir: str) -> "Generator":
        """
        Configure CloudFormation output.

        Args:
            output_dir: Directory for CloudFormation templates

        Returns:
            Self for chaining
        """
        self._config.cloudformation_dir = Path(output_dir)
        self._config.infrastructure_format = "cloudformation"
        return self

    def only(self, *schema_names: str) -> "Generator":
        """
        Generate only specific schemas.

        Args:
            schema_names: Names of schemas to generate

        Returns:
            Self for chaining
        """
        self._only_schemas = list(schema_names)
        return self

    def exclude(self, *schema_names: str) -> "Generator":
        """
        Exclude specific schemas from generation.

        Args:
            schema_names: Names of schemas to exclude

        Returns:
            Self for chaining
        """
        self._exclude_schemas = list(schema_names)
        return self

    def python_only(self) -> "Generator":
        """
        Generate only Python code.

        Returns:
            Self for chaining
        """
        self._only_formats = ["python"]
        return self

    def typescript_only(self) -> "Generator":
        """
        Generate only TypeScript code.

        Returns:
            Self for chaining
        """
        self._only_formats = ["typescript"]
        return self

    def graphql_only(self) -> "Generator":
        """
        Generate only GraphQL schema.

        Returns:
            Self for chaining
        """
        self._only_formats = ["graphql"]
        return self

    def cdk_only(self) -> "Generator":
        """
        Generate only CDK constructs.

        Returns:
            Self for chaining
        """
        self._only_formats = ["cdk"]
        return self

    def skip_python(self) -> "Generator":
        """
        Skip Python generation.

        Returns:
            Self for chaining
        """
        if self._only_formats is None:
            self._only_formats = ["typescript", "graphql", "cdk"]
        elif "python" in self._only_formats:
            self._only_formats.remove("python")
        return self

    def skip_typescript(self) -> "Generator":
        """
        Skip TypeScript generation.

        Returns:
            Self for chaining
        """
        if self._only_formats is None:
            self._only_formats = ["python", "graphql", "cdk"]
        elif "typescript" in self._only_formats:
            self._only_formats.remove("typescript")
        return self

    def skip_graphql(self) -> "Generator":
        """
        Skip GraphQL generation.

        Returns:
            Self for chaining
        """
        if self._only_formats is None:
            self._only_formats = ["python", "typescript", "cdk"]
        elif "graphql" in self._only_formats:
            self._only_formats.remove("graphql")
        return self

    def skip_cdk(self) -> "Generator":
        """
        Skip CDK generation.

        Returns:
            Self for chaining
        """
        if self._only_formats is None:
            self._only_formats = ["python", "typescript", "graphql"]
        elif "cdk" in self._only_formats:
            self._only_formats.remove("cdk")
        return self

    def validate(self, schemas: bool = True, graphql: bool = True) -> "Generator":
        """
        Configure validation.

        Args:
            schemas: Enable schema validation
            graphql: Enable GraphQL validation

        Returns:
            Self for chaining
        """
        self._config.validate_schemas = schemas
        self._config.validate_graphql = graphql
        return self

    def log_level(self, level: str) -> "Generator":
        """
        Set logging level.

        Args:
            level: Logging level (DEBUG, INFO, WARNING, ERROR)

        Returns:
            Self for chaining
        """
        self._config.log_level = level
        return self

    def on_start(self, callback: Callable[[], None]) -> "Generator":
        """
        Register callback for generation start.

        Args:
            callback: Function to call when generation starts

        Returns:
            Self for chaining
        """
        self._callbacks["start"].append(callback)
        return self

    def on_progress(self, callback: Callable[[str, int, int], None]) -> "Generator":
        """
        Register callback for progress updates.

        Args:
            callback: Function(stage, current, total) to call on progress

        Returns:
            Self for chaining
        """
        self._callbacks["progress"].append(callback)
        return self

    def on_file_generated(self, callback: Callable[[str], None]) -> "Generator":
        """
        Register callback for file generation.

        Args:
            callback: Function(file_path) to call when file is generated

        Returns:
            Self for chaining
        """
        self._callbacks["file_generated"].append(callback)
        return self

    def on_complete(self, callback: Callable[[Dict[str, Any]], None]) -> "Generator":
        """
        Register callback for generation completion.

        Args:
            callback: Function(result) to call when generation completes

        Returns:
            Self for chaining
        """
        self._callbacks["complete"].append(callback)
        return self

    def on_error(self, callback: Callable[[Exception], None]) -> "Generator":
        """
        Register callback for errors.

        Args:
            callback: Function(error) to call on error

        Returns:
            Self for chaining
        """
        self._callbacks["error"].append(callback)
        return self

    def generate(self) -> Dict[str, Any]:
        """
        Execute generation.

        Returns:
            Generation result dictionary with statistics
        """
        from .events import EventEmitter, EventType

        # Create event emitter and wire up callbacks
        events = EventEmitter()

        # Wire start callbacks
        if self._callbacks["start"]:
            events.on(EventType.START, lambda e: [cb() for cb in self._callbacks["start"]])

        # Wire progress callbacks
        if self._callbacks["progress"]:

            def on_progress(event):
                stage = event.data.get("stage", "")
                current = event.data.get("current", 0)
                total = event.data.get("total", 0)
                for cb in self._callbacks["progress"]:
                    cb(stage, current, total)

            events.on(EventType.PROGRESS, on_progress)

        # Wire file generated callbacks
        if self._callbacks["file_generated"]:

            def on_file(event):
                file_path = event.data.get("file_path", "")
                for cb in self._callbacks["file_generated"]:
                    cb(file_path)

            events.on(EventType.FILE_GENERATED, on_file)

        # Wire error callbacks
        if self._callbacks["error"]:

            def on_error(event):
                error = event.data.get("error", "")
                for cb in self._callbacks["error"]:
                    cb(Exception(error))

            events.on(EventType.ERROR, on_error)

        try:
            # Create generator with event emitter
            generator = SchemaGenerator(self._config, events)

            # Apply filters
            logger.info("Starting generation via fluent API")
            result = generator.generate_all(
                only_schemas=self._only_schemas,
                exclude_schemas=self._exclude_schemas,
                only_formats=self._only_formats,
            )

            # Convert to dict
            result_dict = result.get_summary()

            # Trigger complete callbacks
            for callback in self._callbacks["complete"]:
                callback(result_dict)

            return result_dict

        except Exception as e:
            # Trigger error callbacks
            for callback in self._callbacks["error"]:
                callback(e)
            raise

    def get_config(self) -> GeneratorConfig:
        """
        Get the current configuration.

        Returns:
            GeneratorConfig instance
        """
        return self._config

    async def generate_async(self) -> Dict[str, Any]:
        """
        Execute generation asynchronously.

        Returns:
            Generation result dictionary with statistics
        """
        # Trigger start callbacks
        for callback in self._callbacks["start"]:
            if asyncio.iscoroutinefunction(callback):
                await callback()
            else:
                callback()

        try:
            # Run generation in executor to avoid blocking
            loop = asyncio.get_event_loop()

            def _generate():
                generator = SchemaGenerator(self._config)
                logger.info("Starting async generation via fluent API")
                generator.generate_all()
                return {
                    "success": True,
                    "files_count": 0,
                    "schemas_processed": 0,
                }

            result = await loop.run_in_executor(None, _generate)

            # Trigger complete callbacks
            for callback in self._callbacks["complete"]:
                if asyncio.iscoroutinefunction(callback):
                    await callback(result)
                else:
                    callback(result)

            return result

        except Exception as e:
            # Trigger error callbacks
            for callback in self._callbacks["error"]:
                if asyncio.iscoroutinefunction(callback):
                    await callback(e)
                else:
                    callback(e)
            raise

    async def generate_stream(self) -> AsyncIterator[Dict[str, Any]]:
        """
        Execute generation with streaming progress updates.

        Yields:
            Progress events as they occur
        """
        # Yield start event
        yield {"event": "start", "timestamp": asyncio.get_event_loop().time()}

        # Trigger start callbacks
        for callback in self._callbacks["start"]:
            if asyncio.iscoroutinefunction(callback):
                await callback()
            else:
                callback()

        try:
            # Run generation in executor
            loop = asyncio.get_event_loop()

            def _generate():
                generator = SchemaGenerator(self._config)
                logger.info("Starting streaming generation via fluent API")
                generator.generate_all()
                return {
                    "success": True,
                    "files_count": 0,
                    "schemas_processed": 0,
                }

            # Yield progress events (simulated for now)
            stages = [
                "loading",
                "validating",
                "generating_python",
                "generating_typescript",
                "generating_graphql",
                "generating_cdk",
            ]

            for i, stage in enumerate(stages):
                yield {
                    "event": "progress",
                    "stage": stage,
                    "current": i + 1,
                    "total": len(stages),
                    "percentage": int((i + 1) / len(stages) * 100),
                }
                await asyncio.sleep(0.1)  # Small delay for streaming effect

            # Execute generation
            result = await loop.run_in_executor(None, _generate)

            # Yield complete event
            yield {"event": "complete", "result": result}

            # Trigger complete callbacks
            for callback in self._callbacks["complete"]:
                if asyncio.iscoroutinefunction(callback):
                    await callback(result)
                else:
                    callback(result)

        except Exception as e:
            # Yield error event
            yield {"event": "error", "error": str(e)}

            # Trigger error callbacks
            for callback in self._callbacks["error"]:
                if asyncio.iscoroutinefunction(callback):
                    await callback(e)
                else:
                    callback(e)
            raise
