"""VTL template builder utility for constructing VTL templates programmatically."""

from typing import Any, Dict, List, Optional
import json
import re


class VTLTemplateBuilder:
    """Builder for constructing VTL templates programmatically.

    Provides a fluent interface for building VTL (Velocity Template Language)
    templates with proper indentation and JSON escaping.
    """

    def __init__(self):
        """Initialize the builder."""
        self._lines: List[str] = []
        self._indent_level: int = 0
        self._indent_str: str = "  "  # 2 spaces

    def add_line(self, line: str = "") -> "VTLTemplateBuilder":
        """
        Add a line with current indentation.

        Args:
            line: The line to add (empty string for blank line)

        Returns:
            Self for method chaining
        """
        if line:
            self._lines.append(f"{self._get_indent()}{line}")
        else:
            self._lines.append("")
        return self

    def add_raw(self, text: str) -> "VTLTemplateBuilder":
        """
        Add raw text without indentation.

        Args:
            text: Raw text to add

        Returns:
            Self for method chaining
        """
        self._lines.append(text)
        return self

    def indent(self) -> "VTLTemplateBuilder":
        """
        Increase indentation level.

        Returns:
            Self for method chaining
        """
        self._indent_level += 1
        return self

    def dedent(self) -> "VTLTemplateBuilder":
        """
        Decrease indentation level.

        Returns:
            Self for method chaining
        """
        if self._indent_level > 0:
            self._indent_level -= 1
        return self

    def add_json_object(
        self, obj: Dict[str, Any], trailing_comma: bool = False
    ) -> "VTLTemplateBuilder":
        """
        Add a JSON object with proper formatting.

        Args:
            obj: Dictionary to serialize as JSON
            trailing_comma: Whether to add a trailing comma

        Returns:
            Self for method chaining
        """
        json_str = json.dumps(obj, indent=2)
        lines = json_str.split("\n")

        for i, line in enumerate(lines):
            if i == len(lines) - 1 and trailing_comma:
                self.add_line(f"{line},")
            else:
                self.add_line(line)

        return self

    def add_vtl_json_start(self) -> "VTLTemplateBuilder":
        """
        Start a VTL JSON object.

        Returns:
            Self for method chaining
        """
        self.add_line("{")
        self.indent()
        return self

    def add_vtl_json_end(self) -> "VTLTemplateBuilder":
        """
        End a VTL JSON object.

        Returns:
            Self for method chaining
        """
        self.dedent()
        self.add_line("}")
        return self

    def add_vtl_property(
        self, name: str, value: str, is_last: bool = False, quote_value: bool = False
    ) -> "VTLTemplateBuilder":
        """
        Add a VTL JSON property.

        Args:
            name: Property name
            value: Property value (can include VTL expressions)
            is_last: Whether this is the last property (no trailing comma)
            quote_value: Whether to wrap value in quotes

        Returns:
            Self for method chaining
        """
        comma = "" if is_last else ","
        if quote_value:
            self.add_line(f'"{name}": "{value}"{comma}')
        else:
            self.add_line(f'"{name}": {value}{comma}')
        return self

    def add_conditional(
        self, condition: str, if_block: str, else_block: Optional[str] = None
    ) -> "VTLTemplateBuilder":
        """
        Add a VTL conditional block.

        Args:
            condition: The condition expression (without #if)
            if_block: Content for the if branch
            else_block: Optional content for the else branch

        Returns:
            Self for method chaining
        """
        self.add_line(f"#if({condition})")
        self.indent()
        self.add_line(if_block)
        self.dedent()

        if else_block:
            self.add_line("#else")
            self.indent()
            self.add_line(else_block)
            self.dedent()

        self.add_line("#end")
        return self

    def add_inline_conditional(self, condition: str, if_value: str, else_value: str) -> str:
        """
        Create an inline VTL conditional expression.

        Args:
            condition: The condition expression
            if_value: Value if condition is true
            else_value: Value if condition is false

        Returns:
            Inline conditional string
        """
        return f"#if({condition}) {if_value} #else {else_value} #end"

    def add_set(self, variable: str, value: str) -> "VTLTemplateBuilder":
        """
        Add a VTL #set directive.

        Args:
            variable: Variable name (without $)
            value: Value expression

        Returns:
            Self for method chaining
        """
        self.add_line(f"#set(${variable} = {value})")
        return self

    def add_foreach(
        self, item: str, collection: str, body_lines: List[str]
    ) -> "VTLTemplateBuilder":
        """
        Add a VTL #foreach loop.

        Args:
            item: Loop variable name (without $)
            collection: Collection expression
            body_lines: Lines inside the loop

        Returns:
            Self for method chaining
        """
        self.add_line(f"#foreach(${item} in {collection})")
        self.indent()
        for line in body_lines:
            self.add_line(line)
        self.dedent()
        self.add_line("#end")
        return self

    def add_dynamodb_key(
        self,
        partition_key: str,
        sort_key: Optional[str] = None,
        input_path: str = "$ctx.args.input",
    ) -> "VTLTemplateBuilder":
        """
        Add a DynamoDB key object for VTL.

        Args:
            partition_key: Partition key attribute name
            sort_key: Optional sort key attribute name
            input_path: Path to input object

        Returns:
            Self for method chaining
        """
        self.add_line('"key": {')
        self.indent()

        pk_value = f"$util.dynamodb.toDynamoDBJson({input_path}.{partition_key})"

        if sort_key and sort_key != "None":
            self.add_vtl_property(partition_key, pk_value)
            sk_value = f"$util.dynamodb.toDynamoDBJson({input_path}.{sort_key})"
            self.add_vtl_property(sort_key, sk_value, is_last=True)
        else:
            self.add_vtl_property(partition_key, pk_value, is_last=True)

        self.dedent()
        self.add_line("},")
        return self

    def build(self) -> str:
        """
        Build the final VTL template string.

        Returns:
            Complete VTL template as a string
        """
        return "\n".join(self._lines)

    def _get_indent(self) -> str:
        """Get the current indentation string."""
        return self._indent_str * self._indent_level

    def clear(self) -> "VTLTemplateBuilder":
        """
        Clear the builder for reuse.

        Returns:
            Self for method chaining
        """
        self._lines = []
        self._indent_level = 0
        return self


def parse_vtl(vtl_content: str) -> Dict[str, Any]:
    """
    Parse a VTL template into a structured representation.

    This is a simplified parser that extracts key structural elements
    for validation and round-trip testing.

    Args:
        vtl_content: VTL template content

    Returns:
        Dictionary with parsed structure
    """
    result: Dict[str, Any] = {
        "directives": [],
        "json_blocks": [],
        "variables": [],
        "conditionals": [],
    }

    # Extract VTL directives
    directive_pattern = r"#(if|else|end|set|foreach)\b"
    result["directives"] = re.findall(directive_pattern, vtl_content)

    # Extract variable references
    var_pattern = r"\$[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*"
    result["variables"] = list(set(re.findall(var_pattern, vtl_content)))

    # Extract $util method calls
    util_pattern = r"\$util\.[a-zA-Z]+\.[a-zA-Z]+\([^)]*\)"
    result["util_calls"] = re.findall(util_pattern, vtl_content)

    # Check for balanced braces
    open_braces = vtl_content.count("{")
    close_braces = vtl_content.count("}")
    result["balanced_braces"] = open_braces == close_braces

    # Check for balanced #if/#end
    if_count = vtl_content.count("#if(")
    end_count = vtl_content.count("#end")
    result["balanced_conditionals"] = if_count == end_count

    return result


def validate_vtl_syntax(vtl_content: str) -> tuple[bool, List[str]]:
    """
    Validate VTL template syntax.

    Args:
        vtl_content: VTL template content

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: List[str] = []

    # Check balanced braces
    open_braces = vtl_content.count("{")
    close_braces = vtl_content.count("}")
    if open_braces != close_braces:
        errors.append(f"Unbalanced braces: {open_braces} open, {close_braces} close")

    # Check balanced brackets
    open_brackets = vtl_content.count("[")
    close_brackets = vtl_content.count("]")
    if open_brackets != close_brackets:
        errors.append(f"Unbalanced brackets: {open_brackets} open, {close_brackets} close")

    # Check balanced block directives (#if, #foreach) vs #end
    # Both #if and #foreach require matching #end
    if_count = vtl_content.count("#if(")
    foreach_count = vtl_content.count("#foreach(")
    end_count = vtl_content.count("#end")
    block_start_count = if_count + foreach_count
    if block_start_count != end_count:
        errors.append(
            f"Unbalanced block directives: {if_count} #if + {foreach_count} #foreach = {block_start_count}, but {end_count} #end"
        )

    # Check for common VTL syntax errors
    if "$util.dynamodb.toDynamoDBJson" in vtl_content:
        # Verify proper usage
        pattern = r"\$util\.dynamodb\.toDynamoDBJson\([^)]+\)"
        if not re.search(pattern, vtl_content):
            errors.append("Invalid $util.dynamodb.toDynamoDBJson usage")

    if "$util.toJson" in vtl_content:
        pattern = r"\$util\.toJson\([^)]+\)"
        if not re.search(pattern, vtl_content):
            errors.append("Invalid $util.toJson usage")

    return len(errors) == 0, errors
