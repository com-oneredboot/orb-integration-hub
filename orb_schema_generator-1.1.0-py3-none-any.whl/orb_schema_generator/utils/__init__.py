"""Utility functions for schema generation."""

from .case_conversion import (
    to_camel_case,
    to_pascal_case,
    to_snake_case,
    to_kebab_case,
    to_typescript_enum_member,
    to_python_enum_member,
    to_dart_enum_member,
    to_graphql_enum_member,
)
from .type_mapping import to_python_type, to_typescript_type, to_dynamodb_type, to_graphql_type
from .file_io import write_file, atomic_write
from .vtl_builder import VTLTemplateBuilder, parse_vtl, validate_vtl_syntax
from .glob_matcher import (
    matches_any_pattern,
    filter_operations,
    filter_operation_names,
    is_valid_glob_pattern,
)

__all__ = [
    "to_camel_case",
    "to_pascal_case",
    "to_snake_case",
    "to_kebab_case",
    "to_typescript_enum_member",
    "to_python_enum_member",
    "to_dart_enum_member",
    "to_graphql_enum_member",
    "to_python_type",
    "to_typescript_type",
    "to_dynamodb_type",
    "to_graphql_type",
    "write_file",
    "atomic_write",
    "VTLTemplateBuilder",
    "parse_vtl",
    "validate_vtl_syntax",
    "matches_any_pattern",
    "filter_operations",
    "filter_operation_names",
    "is_valid_glob_pattern",
]
