"""Glob pattern matching utilities for operation filtering.

This module provides utilities for filtering operations based on glob patterns.
Used by multi-API configuration to filter which operations are exposed per API.
"""

import fnmatch
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from src.core.models import Operation


def matches_any_pattern(operation_name: str, patterns: List[str]) -> bool:
    """Check if operation name matches any glob pattern.

    Uses Python's fnmatch for glob-style pattern matching:
    - `*` matches any sequence of characters
    - `?` matches any single character
    - `[seq]` matches any character in seq
    - `[!seq]` matches any character not in seq

    Args:
        operation_name: The operation name to check (e.g., "UsersCreate", "OrganizationsListByOwnerId")
        patterns: List of glob patterns (e.g., ["*Create", "*Update", "*ListBy*"])

    Returns:
        True if operation matches at least one pattern, False otherwise

    Examples:
        >>> matches_any_pattern("UsersCreate", ["*Create", "*Update"])
        True
        >>> matches_any_pattern("UsersGet", ["*Create", "*Update"])
        False
        >>> matches_any_pattern("OrganizationsListByOwnerId", ["*ListBy*"])
        True
        >>> matches_any_pattern("UsersCreate", ["*"])
        True
    """
    if not patterns:
        return False
    return any(fnmatch.fnmatch(operation_name, pattern) for pattern in patterns)


def filter_operations(operations: List["Operation"], patterns: List[str]) -> List["Operation"]:
    """Filter operations to only those matching include patterns.

    This is the primary filtering function used by generators to limit
    which operations are exposed in a given API definition.

    Args:
        operations: List of Operation objects to filter
        patterns: List of glob patterns to match against operation field names

    Returns:
        List of operations where the field name matches at least one pattern

    Examples:
        >>> from src.core.models import Operation
        >>> ops = [
        ...     Operation(field="UsersCreate", ...),
        ...     Operation(field="UsersUpdate", ...),
        ...     Operation(field="UsersGet", ...),
        ... ]
        >>> filtered = filter_operations(ops, ["*Create", "*Update"])
        >>> [op.field for op in filtered]
        ['UsersCreate', 'UsersUpdate']
    """
    if not patterns:
        return []
    return [op for op in operations if matches_any_pattern(op.field, patterns)]


def filter_operation_names(operation_names: List[str], patterns: List[str]) -> List[str]:
    """Filter operation names to only those matching include patterns.

    Convenience function for filtering string lists without Operation objects.

    Args:
        operation_names: List of operation name strings to filter
        patterns: List of glob patterns to match against

    Returns:
        List of operation names matching at least one pattern

    Examples:
        >>> names = ["UsersCreate", "UsersUpdate", "UsersGet", "UsersDelete"]
        >>> filter_operation_names(names, ["*Create", "*Delete"])
        ['UsersCreate', 'UsersDelete']
    """
    if not patterns:
        return []
    return [name for name in operation_names if matches_any_pattern(name, patterns)]


def is_valid_glob_pattern(pattern: str) -> bool:
    """Check if a glob pattern is syntactically valid.

    Validates that the pattern can be used with fnmatch without errors.
    This is a basic validation - fnmatch is quite permissive.

    Args:
        pattern: The glob pattern to validate

    Returns:
        True if the pattern is valid, False otherwise

    Examples:
        >>> is_valid_glob_pattern("*Create")
        True
        >>> is_valid_glob_pattern("Users*")
        True
        >>> is_valid_glob_pattern("[abc]")
        True
        >>> is_valid_glob_pattern("[")  # Unclosed bracket
        False
    """
    if not pattern:
        return False
    try:
        # fnmatch.translate converts glob to regex - if it fails, pattern is invalid
        fnmatch.translate(pattern)
        return True
    except Exception:
        return False
