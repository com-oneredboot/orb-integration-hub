"""Enhanced type mapping utilities for different target languages."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Set


@dataclass
class TypeMapping:
    """Comprehensive type mapping for all target languages."""

    python_type: str
    typescript_type: str
    graphql_type: str
    dart_type: str = ""  # Dart type mapping
    python_import: Optional[str] = None
    typescript_import: Optional[str] = None
    dart_import: Optional[str] = None  # Dart import statement
    graphql_scalar_def: Optional[str] = None


class EnhancedTypeMapper:
    """Enhanced type mapping system with validation constraint support."""

    def __init__(self):
        self.type_mappings = {
            "string": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="String",
                dart_type="String",
            ),
            "id": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="ID",  # GraphQL ID scalar - unique identifier
                dart_type="String",
            ),
            "float": TypeMapping(
                python_type="float",
                typescript_type="number",
                graphql_type="Float",
                dart_type="double",
            ),
            "integer": TypeMapping(
                python_type="int",
                typescript_type="number",
                graphql_type="Int",
                dart_type="int",
            ),
            "boolean": TypeMapping(
                python_type="bool",
                typescript_type="boolean",
                graphql_type="Boolean",
                dart_type="bool",
            ),
            "datetime": TypeMapping(
                python_type="datetime",
                typescript_type="Date",
                graphql_type="AWSDateTime",  # AppSync built-in scalar
                dart_type="DateTime",
                python_import="from datetime import datetime",
                graphql_scalar_def=None,  # No custom scalar needed - AWSDateTime is built-in
            ),
            # Legacy support for existing schemas
            "number": TypeMapping(
                python_type="float",  # Default number to float
                typescript_type="number",
                graphql_type="Float",
                dart_type="double",
            ),
            "timestamp": TypeMapping(
                python_type="datetime",
                typescript_type="Date",
                graphql_type="AWSTimestamp",  # AppSync built-in scalar for Unix timestamps
                dart_type="DateTime",
                python_import="from datetime import datetime",
                graphql_scalar_def=None,  # No custom scalar needed - AWSTimestamp is built-in
            ),
            "array": TypeMapping(
                python_type="List[str]",
                typescript_type="string[]",
                graphql_type="[String]",
                dart_type="List<String>",
                python_import="from typing import List",
            ),
            "object": TypeMapping(
                python_type="Dict[str, Any]",
                typescript_type="Record<string, unknown>",  # Issue #59: use unknown instead of any
                graphql_type="String",  # Objects serialized as JSON strings in GraphQL
                dart_type="Map<String, dynamic>",
                python_import="from typing import Dict, Any",
            ),
            "set": TypeMapping(
                python_type="Set[str]",
                typescript_type="Set<string>",
                graphql_type="[String]",  # Sets as arrays in GraphQL
                dart_type="Set<String>",
                python_import="from typing import Set",
            ),
            # AWS AppSync specific scalar types
            "date": TypeMapping(
                python_type="date",
                typescript_type="string",  # ISO date string
                graphql_type="AWSDate",  # AppSync built-in: YYYY-MM-DD
                dart_type="DateTime",
                python_import="from datetime import date",
                graphql_scalar_def=None,
            ),
            "time": TypeMapping(
                python_type="time",
                typescript_type="string",  # ISO time string
                graphql_type="AWSTime",  # AppSync built-in: hh:mm:ss.sss
                dart_type="DateTime",
                python_import="from datetime import time",
                graphql_scalar_def=None,
            ),
            "email": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="AWSEmail",  # AppSync built-in email validation
                dart_type="String",
                graphql_scalar_def=None,
            ),
            "url": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="AWSURL",  # AppSync built-in URL validation
                dart_type="String",
                graphql_scalar_def=None,
            ),
            "phone": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="AWSPhone",  # AppSync built-in phone validation
                dart_type="String",
                graphql_scalar_def=None,
            ),
            "ipaddress": TypeMapping(
                python_type="str",
                typescript_type="string",
                graphql_type="AWSIPAddress",  # AppSync built-in IP validation
                dart_type="String",
                graphql_scalar_def=None,
            ),
            "json": TypeMapping(
                python_type="Dict[str, Any]",
                typescript_type="Record<string, unknown>",  # Issue #59: use unknown instead of any
                graphql_type="AWSJSON",  # AppSync built-in JSON scalar
                dart_type="Map<String, dynamic>",
                python_import="from typing import Dict, Any",
                graphql_scalar_def=None,
            ),
            "map": TypeMapping(
                python_type="Dict[str, Any]",
                typescript_type="Record<string, unknown>",
                graphql_type="AWSJSON",
                dart_type="Map<String, dynamic>",
                python_import="from typing import Dict, Any",
            ),
        }

        self.validation_mappings = {
            "min": {"python": "ge", "typescript": "min", "graphql": "@constraint(min: {})"},
            "max": {"python": "le", "typescript": "max", "graphql": "@constraint(max: {})"},
            "pattern": {
                "python": "pattern",
                "typescript": "pattern",
                "graphql": '@constraint(pattern: "{}")',
            },
        }

    def _get_typed_map_mapping(self, value_type: str) -> TypeMapping:
        """
        Get type mapping for a typed map (map<value_type>).

        Args:
            value_type: The type of values in the map

        Returns:
            TypeMapping with typed map types

        Raises:
            ValueError: If value_type is not supported
        """
        # Supported value types for typed maps
        value_type_mappings = {
            "string": TypeMapping(
                python_type="Dict[str, str]",
                typescript_type="Record<string, string>",
                graphql_type="AWSJSON",  # GraphQL always uses AWSJSON
                dart_type="Map<String, String>",
                python_import="from typing import Dict",
            ),
            "integer": TypeMapping(
                python_type="Dict[str, int]",
                typescript_type="Record<string, number>",
                graphql_type="AWSJSON",
                dart_type="Map<String, int>",
                python_import="from typing import Dict",
            ),
            "boolean": TypeMapping(
                python_type="Dict[str, bool]",
                typescript_type="Record<string, boolean>",
                graphql_type="AWSJSON",
                dart_type="Map<String, bool>",
                python_import="from typing import Dict",
            ),
            "float": TypeMapping(
                python_type="Dict[str, float]",
                typescript_type="Record<string, number>",
                graphql_type="AWSJSON",
                dart_type="Map<String, double>",
                python_import="from typing import Dict",
            ),
        }

        if value_type.lower() not in value_type_mappings:
            supported = list(value_type_mappings.keys())
            raise ValueError(
                f"Unsupported map value type: {value_type}. " f"Supported value types: {supported}"
            )

        return value_type_mappings[value_type.lower()]

    def get_type_mapping(self, yaml_type: str, constraints: Optional[Dict] = None) -> TypeMapping:
        """
        Get comprehensive type mapping for a YAML type.

        Args:
            yaml_type: The type from YAML schema
            constraints: Optional validation constraints

        Returns:
            TypeMapping with all target language types

        Raises:
            ValueError: If type is not supported
        """
        # Handle map types with optional value_type
        if yaml_type.lower().startswith("map<"):
            value_type = yaml_type[4:-1]  # Extract type between map< and >
            return self._get_typed_map_mapping(value_type)
        elif yaml_type.lower() == "map":
            return self.type_mappings["map"]

        # Handle array types
        if yaml_type.lower().startswith("array<"):
            element_type = yaml_type[6:-1]  # Extract type between array< and >
            element_mapping = self.get_type_mapping(element_type)

            python_import = "from typing import List"
            if element_mapping.python_import:
                python_import = (
                    f"{python_import}, {element_mapping.python_import.split('import ')[1]}"
                )

            return TypeMapping(
                python_type=f"List[{element_mapping.python_type}]",
                typescript_type=f"{element_mapping.typescript_type}[]",
                graphql_type=f"[{element_mapping.graphql_type}]",
                dart_type=f"List<{element_mapping.dart_type}>",
                python_import=python_import,
                typescript_import=element_mapping.typescript_import,
                dart_import=element_mapping.dart_import,
                graphql_scalar_def=element_mapping.graphql_scalar_def,
            )

        # Handle enum references
        if yaml_type.startswith("enum:"):
            # Extract enum name from "enum:EnumName" format
            enum_name = yaml_type[5:]  # Remove "enum:" prefix
            return TypeMapping(
                python_type=enum_name,
                typescript_type=enum_name,
                graphql_type=enum_name,
                dart_type=enum_name,
            )
        elif yaml_type.endswith("Enum") and len(yaml_type) > 4:
            # Handle "SomeNameEnum" format - strip "Enum" suffix
            enum_name = yaml_type[:-4]
            return TypeMapping(
                python_type=enum_name,
                typescript_type=enum_name,
                graphql_type=enum_name,
                dart_type=enum_name,
            )

        # Get base type mapping
        base_type = yaml_type.lower()
        if base_type not in self.type_mappings:
            raise ValueError(
                f"Unsupported type: {yaml_type}. Supported types: {list(self.type_mappings.keys())}"
            )

        return self.type_mappings[base_type]

    def get_validation_constraints(self, constraints: Dict[str, Any]) -> Dict[str, List[str]]:
        """
        Convert YAML validation constraints to target language validators.

        Args:
            constraints: Dictionary of validation constraints from YAML

        Returns:
            Dictionary mapping target languages to their constraint syntax
        """
        result: Dict[str, List[str]] = {"python": [], "typescript": [], "graphql": []}

        for constraint_name, constraint_value in constraints.items():
            if constraint_name in self.validation_mappings:
                mapping = self.validation_mappings[constraint_name]

                # Python (Pydantic Field constraints)
                if constraint_name == "pattern":
                    result["python"].append(f'{mapping["python"]}=r"{constraint_value}"')
                else:
                    result["python"].append(f'{mapping["python"]}={constraint_value}')

                # TypeScript (for documentation/validation libraries)
                result["typescript"].append(f'{mapping["typescript"]}: {constraint_value}')

                # GraphQL (constraint directives)
                result["graphql"].append(mapping["graphql"].format(constraint_value))

        return result

    def resolve_reference(self, ref: str) -> str:
        """
        Resolve object or enum references to proper type names.

        Args:
            ref: Reference string (e.g., "$ref: GPSPoint" or "enum_ref: AlertType")

        Returns:
            Resolved type name
        """
        # Handle $ref object references
        if ref.startswith("$ref:"):
            return ref[5:].strip()
        elif ref.startswith("enum_ref:"):
            return ref[9:].strip()
        else:
            # Assume it's already a clean reference
            return ref

    def get_required_imports(
        self, type_mappings: List[TypeMapping], target_language: str
    ) -> Set[str]:
        """
        Get all required import statements for a list of type mappings.

        Args:
            type_mappings: List of TypeMapping objects
            target_language: 'python', 'typescript', or 'dart'

        Returns:
            Set of import statements
        """
        imports = set()

        for mapping in type_mappings:
            if target_language == "python" and mapping.python_import:
                imports.add(mapping.python_import)
            elif target_language == "typescript" and mapping.typescript_import:
                imports.add(mapping.typescript_import)
            elif target_language == "dart" and mapping.dart_import:
                imports.add(mapping.dart_import)

        return imports

    def get_graphql_scalars(self, type_mappings: List[TypeMapping]) -> Set[str]:
        """
        Get all required GraphQL scalar definitions.

        Args:
            type_mappings: List of TypeMapping objects

        Returns:
            Set of scalar definition strings
        """
        scalars = set()

        for mapping in type_mappings:
            if mapping.graphql_scalar_def:
                scalars.add(mapping.graphql_scalar_def)

        return scalars


# Global instance for backward compatibility
_type_mapper = EnhancedTypeMapper()


def to_python_type(attr_type: str) -> str:
    """
    Convert schema type to Python type (backward compatibility).

    Args:
        attr_type: Schema type

    Returns:
        Python type string
    """
    try:
        mapping = _type_mapper.get_type_mapping(attr_type)
        return mapping.python_type
    except ValueError:
        # Fallback for unknown types
        return "str"


def to_typescript_type(attr_type: str) -> str:
    """
    Convert schema type to TypeScript type (backward compatibility).

    Args:
        attr_type: Schema type

    Returns:
        TypeScript type string
    """
    try:
        mapping = _type_mapper.get_type_mapping(attr_type)
        return mapping.typescript_type
    except ValueError:
        # Fallback for unknown types
        return attr_type


def to_graphql_type(type_name: str) -> str:
    """
    Convert schema type to GraphQL type (backward compatibility).

    Args:
        type_name: Schema type

    Returns:
        GraphQL type string
    """
    try:
        mapping = _type_mapper.get_type_mapping(type_name)
        return mapping.graphql_type
    except ValueError:
        # Fallback for unknown types
        return type_name


def to_dart_type(attr_type: str) -> str:
    """
    Convert schema type to Dart type (backward compatibility).

    Args:
        attr_type: Schema type

    Returns:
        Dart type string
    """
    try:
        mapping = _type_mapper.get_type_mapping(attr_type)
        return mapping.dart_type
    except ValueError:
        # Fallback for unknown types
        return "dynamic"


def to_dynamodb_type(attr_type: str) -> str:
    """
    Convert schema type to DynamoDB attribute type (backward compatibility).

    Args:
        attr_type: Schema type

    Returns:
        DynamoDB type (S, N, B, etc.)
    """
    type_mapping = {
        "string": "S",
        "number": "N",
        "float": "N",
        "integer": "N",
        "boolean": "S",  # DynamoDB doesn't have a boolean type
        "array": "S",  # DynamoDB doesn't have an array type
        "object": "S",  # DynamoDB doesn't have an object type
        "timestamp": "N",  # Timestamps are stored as numbers
        "datetime": "N",  # Datetime stored as epoch numbers
    }
    return type_mapping.get(attr_type.lower(), "S")
