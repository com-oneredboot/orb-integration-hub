"""Case conversion utilities."""

import re


def to_camel_case(s: str) -> str:
    """
    Convert string to camelCase, preserving internal capitalization.

    Examples:
        >>> to_camel_case("user_id")
        'userId'
        >>> to_camel_case("UserID")
        'userID'
    """
    # If already camelCase or PascalCase, just lowercase the first character
    if "_" not in s and "-" not in s:
        return s[0].lower() + s[1:] if s else s
    # Otherwise, convert snake_case or kebab-case to camelCase
    parts = re.split(r"[_-]", s)
    return parts[0].lower() + "".join(word.capitalize() for word in parts[1:])


def to_pascal_case(s: str) -> str:
    """
    Convert string to PascalCase, preserving consecutive capitals (acronyms).

    Per PEP 8: When an acronym is part of a class name, each letter of the
    acronym should be capitalized (e.g., HTTPClient, XMLParser, POICategory).

    Examples:
        >>> to_pascal_case("user_id")
        'UserId'
        >>> to_pascal_case("userId")
        'UserId'
        >>> to_pascal_case("A")
        'A'
        >>> to_pascal_case("POICategory")
        'POICategory'
        >>> to_pascal_case("HTTPClient")
        'HTTPClient'
        >>> to_pascal_case("http_client")
        'HttpClient'
    """
    if not s:
        return s

    # If already PascalCase (starts with uppercase, no underscores/hyphens), preserve it
    # This handles acronyms like POICategory, HTTPClient, XMLParser
    if s[0].isupper() and "_" not in s and "-" not in s:
        return s

    # Split by underscores and hyphens
    words = re.split(r"[_-]", s)
    result = []

    for word in words:
        # Handle empty strings
        if not word:
            continue

        # Handle single character words
        if len(word) == 1:
            result.append(word.upper())
            continue

        # If word is all uppercase (acronym), preserve it
        if word.isupper():
            result.append(word)
            continue

        # Split on camelCase boundaries, preserving acronyms
        # This regex captures:
        # - Sequences of uppercase letters followed by lowercase (e.g., "HTTP" in "HTTPClient")
        # - Single uppercase followed by lowercase letters (e.g., "Client")
        # - Sequences of lowercase letters (e.g., "user")
        # - Digits
        parts = re.findall(r"[A-Z]+(?=[A-Z][a-z]|[0-9]|\b)|[A-Z]?[a-z]+|[A-Z]+|[0-9]+", word)

        if not parts:
            result.append(word.capitalize())
            continue

        for part in parts:
            # Preserve all-uppercase parts (acronyms)
            if part.isupper() and len(part) > 1:
                result.append(part)
            else:
                result.append(part.capitalize())

    return "".join(result)


def to_snake_case(s: str) -> str:
    """
    Convert string to snake_case.

    Examples:
        >>> to_snake_case("userId")
        'user_id'
        >>> to_snake_case("UserID")
        'user_id'
    """
    # Handle camelCase and PascalCase
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", s)
    s2 = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1)
    # Convert to lowercase and replace any remaining spaces with underscores
    return re.sub(r"[-\s]", "_", s2).lower()


def to_kebab_case(s: str) -> str:
    """
    Convert string to kebab-case.

    Examples:
        >>> to_kebab_case("userId")
        'user-id'
        >>> to_kebab_case("user_id")
        'user-id'
    """
    # First convert to snake_case
    snake = to_snake_case(s)
    # Then replace underscores with hyphens
    return snake.replace("_", "-")


# =============================================================================
# ENUM MEMBER NAME CONVERSION FUNCTIONS
# =============================================================================
# These functions convert enum keys to language-specific member names.
# Each language has its own naming convention for enum members.


def to_typescript_enum_member(key: str) -> str:
    """
    Convert enum key to TypeScript enum member name (PascalCase).

    TypeScript convention uses PascalCase for enum members.

    Examples:
        >>> to_typescript_enum_member("ACTIVE")
        'Active'
        >>> to_typescript_enum_member("PENDING_REVIEW")
        'PendingReview'
        >>> to_typescript_enum_member("ORB-AUTH-001")
        'OrbAuth001'
        >>> to_typescript_enum_member("active")
        'Active'

    Args:
        key: The enum key (typically SCREAMING_SNAKE_CASE from schema)

    Returns:
        PascalCase enum member name for TypeScript
    """
    # Normalize: lowercase, replace hyphens with underscores
    normalized = key.lower().replace("-", "_")
    return to_pascal_case(normalized)


def to_python_enum_member(key: str) -> str:
    """
    Convert enum key to Python enum member name (SCREAMING_SNAKE_CASE).

    Python convention uses SCREAMING_SNAKE_CASE for enum members.

    Examples:
        >>> to_python_enum_member("active")
        'ACTIVE'
        >>> to_python_enum_member("pending-review")
        'PENDING_REVIEW'
        >>> to_python_enum_member("ORB-AUTH-001")
        'ORB_AUTH_001'
        >>> to_python_enum_member("ALREADY_SCREAMING")
        'ALREADY_SCREAMING'

    Args:
        key: The enum key from schema

    Returns:
        SCREAMING_SNAKE_CASE enum member name for Python
    """
    return key.upper().replace("-", "_").replace(" ", "_")


def to_dart_enum_member(key: str) -> str:
    """
    Convert enum key to Dart enum member name (camelCase).

    Dart convention uses camelCase for enum values.

    Examples:
        >>> to_dart_enum_member("ACTIVE")
        'active'
        >>> to_dart_enum_member("PENDING_REVIEW")
        'pendingReview'
        >>> to_dart_enum_member("ORB-AUTH-001")
        'orbAuth001'

    Args:
        key: The enum key (typically SCREAMING_SNAKE_CASE from schema)

    Returns:
        camelCase enum member name for Dart
    """
    # Normalize: lowercase, replace hyphens with underscores
    normalized = key.lower().replace("-", "_")
    return to_camel_case(normalized)


def to_graphql_enum_member(key: str) -> str:
    """
    Convert enum key to GraphQL enum value (SCREAMING_SNAKE_CASE).

    GraphQL enum values can only contain [A-Za-z0-9_], so hyphens
    must be converted to underscores.

    Examples:
        >>> to_graphql_enum_member("active")
        'ACTIVE'
        >>> to_graphql_enum_member("ORB-AUTH-001")
        'ORB_AUTH_001'
        >>> to_graphql_enum_member("pending_review")
        'PENDING_REVIEW'

    Args:
        key: The enum key from schema

    Returns:
        SCREAMING_SNAKE_CASE enum value for GraphQL
    """
    return key.upper().replace("-", "_").replace(" ", "_")
