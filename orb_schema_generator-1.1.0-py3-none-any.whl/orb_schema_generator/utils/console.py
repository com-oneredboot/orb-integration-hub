"""Console output utilities for cross-platform compatibility.

This module provides encoding-safe output functions that work correctly
on Windows terminals with cp1252 encoding and Unix terminals with UTF-8.
"""

import sys
from typing import Dict

# Unicode symbols for UTF-8 terminals
UNICODE_SYMBOLS: Dict[str, str] = {
    "success": "✅",
    "error": "❌",
    "warning": "⚠️",
    "info": "ℹ️",
}

# ASCII-safe alternatives for non-UTF-8 terminals (e.g., Windows cp1252)
ASCII_SYMBOLS: Dict[str, str] = {
    "success": "[OK]",
    "error": "[FAIL]",
    "warning": "[WARN]",
    "info": "[INFO]",
}

# Cache the encoding check result
_supports_unicode_cache: bool | None = None


def _supports_unicode() -> bool:
    """
    Check if the terminal supports Unicode output.

    Returns:
        True if terminal encoding supports Unicode (UTF-8), False otherwise.
    """
    global _supports_unicode_cache

    if _supports_unicode_cache is not None:
        return _supports_unicode_cache

    try:
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
        _supports_unicode_cache = encoding.lower().replace("-", "") in ("utf8", "utf16", "utf32")
    except Exception:
        _supports_unicode_cache = False

    return _supports_unicode_cache


def get_symbol(name: str) -> str:
    """
    Get the appropriate symbol based on terminal encoding.

    Args:
        name: Symbol name ('success', 'error', 'warning', 'info')

    Returns:
        Unicode emoji or ASCII alternative based on terminal support.
    """
    symbols = UNICODE_SYMBOLS if _supports_unicode() else ASCII_SYMBOLS
    return symbols.get(name, "")


def success(message: str) -> str:
    """Format a success message with appropriate symbol."""
    return f"{get_symbol('success')} {message}"


def error(message: str) -> str:
    """Format an error message with appropriate symbol."""
    return f"{get_symbol('error')} {message}"


def warning(message: str) -> str:
    """Format a warning message with appropriate symbol."""
    return f"{get_symbol('warning')} {message}"


def info(message: str) -> str:
    """Format an info message with appropriate symbol."""
    return f"{get_symbol('info')} {message}"


def reset_unicode_cache() -> None:
    """Reset the Unicode support cache (useful for testing)."""
    global _supports_unicode_cache
    _supports_unicode_cache = None
