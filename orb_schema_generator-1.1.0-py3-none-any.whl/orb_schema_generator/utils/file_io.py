"""File I/O utilities with atomic writes."""

import os
import tempfile
from pathlib import Path


def write_file(output_path: str | Path, content: str) -> None:
    """
    Write content to file with consistent UTF-8 encoding without BOM.

    Args:
        output_path: Path to write the file to
        content: Content to write
    """
    output_path = Path(output_path)

    # Create directory if it doesn't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Write with explicit UTF-8 encoding
    with open(output_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def atomic_write(output_path: str | Path, content: str) -> None:
    """
    Write content to file atomically to prevent corruption.

    Uses a temporary file and atomic rename to ensure the file is either
    fully written or not written at all.

    Args:
        output_path: Path to write the file to
        content: Content to write
    """
    output_path = Path(output_path)

    # Create directory if it doesn't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Write to temporary file first
    fd, temp_path = tempfile.mkstemp(
        dir=output_path.parent, prefix=f".{output_path.name}.", suffix=".tmp"
    )

    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)

        # Atomic rename (POSIX systems)
        os.replace(temp_path, output_path)
    except Exception:
        # Clean up temp file on error
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise
