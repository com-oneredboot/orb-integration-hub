"""Command-line interface for orb-schema-generator."""

import click
import logging
import time
from pathlib import Path

from .core.config import GeneratorConfig
from .generator import SchemaGenerator


def _get_package_name() -> str:
    """Get package name from metadata or fallback."""
    try:
        from importlib.metadata import metadata

        return metadata("orb-schema-generator")["Name"]
    except Exception:
        return "orb-schema-generator"


def _format_generated_code(config: GeneratorConfig) -> None:
    """Format generated code using black for Python and prettier for TypeScript/Dart."""
    import subprocess  # nosec B404 - subprocess needed for running formatters

    # Format Python files with black
    python_dir = config.python_output.base_dir
    if python_dir.exists():
        try:
            result = subprocess.run(  # nosec B603, B607 - trusted formatter command
                ["black", str(python_dir)],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                click.echo(f"   Formatted Python files in {python_dir}")
            else:
                click.echo(click.style(f"   Black formatting failed: {result.stderr}", fg="yellow"))
        except FileNotFoundError:
            click.echo(
                click.style("   black not found - install with: pip install black", fg="yellow")
            )

    # Format TypeScript files with prettier
    ts_dir = config.typescript_output.base_dir
    if ts_dir.exists():
        try:
            result = subprocess.run(  # nosec B603, B607 - trusted formatter command
                ["prettier", "--write", str(ts_dir / "**/*.ts")],
                capture_output=True,
                text=True,
                shell=False,
            )
            if result.returncode == 0:
                click.echo(f"   Formatted TypeScript files in {ts_dir}")
            else:
                click.echo(
                    click.style(f"   Prettier formatting skipped: {result.stderr}", fg="yellow")
                )
        except FileNotFoundError:
            click.echo(
                click.style(
                    "   prettier not found - install with: npm install -g prettier", fg="yellow"
                )
            )


def _lint_generated_code(config: GeneratorConfig) -> None:
    """Lint generated code using ruff for Python and eslint for TypeScript."""
    import subprocess  # nosec B404 - subprocess needed for running linters

    # Lint Python files with ruff
    python_dir = config.python_output.base_dir
    if python_dir.exists():
        try:
            result = subprocess.run(  # nosec B603, B607 - trusted linter command
                ["ruff", "check", str(python_dir), "--fix"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                click.echo(f"   Linted Python files in {python_dir}")
            else:
                click.echo(click.style(f"   Ruff linting issues: {result.stdout}", fg="yellow"))
        except FileNotFoundError:
            click.echo(
                click.style("   ruff not found - install with: pip install ruff", fg="yellow")
            )

    # Lint TypeScript files with eslint
    ts_dir = config.typescript_output.base_dir
    if ts_dir.exists():
        try:
            result = subprocess.run(  # nosec B603, B607 - trusted linter command
                ["eslint", "--fix", str(ts_dir)],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                click.echo(f"   Linted TypeScript files in {ts_dir}")
            else:
                click.echo(click.style(f"   ESLint issues: {result.stdout}", fg="yellow"))
        except FileNotFoundError:
            click.echo(
                click.style(
                    "   eslint not found - install with: npm install -g eslint", fg="yellow"
                )
            )


@click.group()
@click.version_option()
def main():
    f"""ORB Schema Generator ({_get_package_name()}) - Generate code from YAML schemas."""
    pass


@main.command()
@click.option("--config", "-c", type=click.Path(exists=True), help="Path to configuration file")
@click.option(
    "--schema-dir", type=click.Path(exists=True), help="Directory containing schema files"
)
@click.option("--output-dir", type=click.Path(), help="Output directory for generated files")
@click.option(
    "--format",
    type=click.Choice(["cloudformation", "cdk", "both"]),
    default="cloudformation",
    help="Infrastructure format to generate",
)
@click.option(
    "--log-level",
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"]),
    default="INFO",
    help="Logging level",
)
@click.option("--dry-run", is_flag=True, help="Show what would be generated without writing files")
@click.option("--diff", is_flag=True, help="Show differences with existing files")
@click.option(
    "--interactive", "-i", is_flag=True, help="Prompt for confirmation before writing each file"
)
@click.option(
    "--only", multiple=True, help="Generate only specific schemas (can be used multiple times)"
)
@click.option(
    "--exclude", multiple=True, help="Exclude specific schemas (can be used multiple times)"
)
@click.option("--python-only", is_flag=True, help="Generate only Python code")
@click.option("--typescript-only", is_flag=True, help="Generate only TypeScript code")
@click.option("--graphql-only", is_flag=True, help="Generate only GraphQL schema")
@click.option("--cdk-only", is_flag=True, help="Generate only CDK constructs")
@click.option("--skip-python", is_flag=True, help="Skip Python generation")
@click.option("--skip-typescript", is_flag=True, help="Skip TypeScript generation")
@click.option("--skip-graphql", is_flag=True, help="Skip GraphQL generation")
@click.option("--skip-cdk", is_flag=True, help="Skip CDK generation")
@click.option("--format-code", is_flag=True, help="Format generated code (requires black/prettier)")
@click.option("--lint", is_flag=True, help="Lint generated code (requires ruff/eslint)")
@click.option("--profile", is_flag=True, help="Show performance profiling information")
@click.option("--skip-validation", is_flag=True, help="Skip configuration validation")
@click.option("--no-version-check", is_flag=True, help="Skip checking for newer versions")
def generate(
    config,
    schema_dir,
    output_dir,
    format,
    log_level,
    dry_run,
    diff,
    interactive,
    only,
    exclude,
    python_only,
    typescript_only,
    graphql_only,
    cdk_only,
    skip_python,
    skip_typescript,
    skip_graphql,
    skip_cdk,
    format_code,
    lint,
    profile,
    skip_validation,
    no_version_check,
):
    """Generate code from schemas."""
    # Set up logging
    logging.basicConfig(
        level=getattr(logging, log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Check for updates (unless disabled)
    if not no_version_check:
        from .core.version_checker import VersionChecker

        checker = VersionChecker()
        update_message = checker.check_for_update(silent=True)
        if update_message:
            click.echo(click.style(f"⚠️  {update_message}\n", fg="yellow"))

    # Validate configuration first (unless skipped)
    config_path = config or "schema-generator.yml"
    if not skip_validation and Path(config_path).exists():
        from .core.validator import ConfigValidator

        validator = ConfigValidator(config_path)
        result = validator.validate()

        # Display warnings (don't block)
        for issue in result.warnings:
            click.echo(click.style(f"WARNING: {issue.message}", fg="yellow"))

        # Block on errors
        if result.has_errors:
            click.echo(click.style("\nConfiguration errors found:", fg="red"))
            for issue in result.errors:
                click.echo(f"  • {issue.field_path}: {issue.message}")
            click.echo("\nTo proceed:")
            click.echo("  1. Run: orb-schema validate-config --fix")
            click.echo("  2. Or: orb-schema generate --skip-validation")
            raise SystemExit(1)

    # Load configuration
    if config:
        gen_config = GeneratorConfig.from_file(config)
    else:
        # Try to load default config file
        default_config = Path("schema-generator.yml")
        if default_config.exists():
            gen_config = GeneratorConfig.from_file(str(default_config))
        else:
            gen_config = GeneratorConfig()
            if schema_dir:
                gen_config.schema_dir = Path(schema_dir)
            if output_dir:
                gen_config.backend_models_dir = Path(output_dir) / "backend" / "models"
                gen_config.frontend_models_dir = Path(output_dir) / "frontend" / "models"
            gen_config.infrastructure_format = format
            gen_config.log_level = log_level

    # Handle dry-run mode
    if dry_run:
        click.echo(click.style("DRY RUN MODE - No files will be written\n", fg="yellow"))

        # Load configuration
        if config:
            gen_config = GeneratorConfig.from_file(config)
        else:
            default_config = Path("schema-generator.yml")
            if default_config.exists():
                gen_config = GeneratorConfig.from_file(str(default_config))
            else:
                click.echo(click.style("No configuration file found", fg="red"))
                return

        # Load schemas
        from .core.loaders import SchemaLoader

        loader = SchemaLoader(gen_config)
        schemas = loader.load_all_schemas()

        # Apply filters
        if only:
            schemas = {name: schema for name, schema in schemas.items() if name in only}
        if exclude:
            schemas = {name: schema for name, schema in schemas.items() if name not in exclude}

        click.echo(f"Would process {len(schemas)} schema(s):")
        for name in schemas.keys():
            click.echo(f"   - {name}")

        click.echo("\nWould generate files:")

        # Determine what to generate
        generate_python = not skip_python and (
            not any([typescript_only, graphql_only, cdk_only]) or python_only
        )
        generate_typescript = not skip_typescript and (
            not any([python_only, graphql_only, cdk_only]) or typescript_only
        )
        generate_graphql = not skip_graphql and (
            not any([python_only, typescript_only, cdk_only]) or graphql_only
        )
        generate_cdk = not skip_cdk and (
            not any([python_only, typescript_only, graphql_only]) or cdk_only
        )

        if generate_python:
            click.echo(f"\n   Python Models ({gen_config.backend_models_dir}):")
            for name in schemas.keys():
                click.echo(f"      - {name.lower()}.py")
            click.echo("      - enums.py")

        if generate_typescript:
            click.echo(f"\n   TypeScript Models ({gen_config.frontend_models_dir}):")
            for name in schemas.keys():
                click.echo(f"      - {name}.ts")
            click.echo("      - enums.ts")

        if generate_graphql:
            click.echo(f"\n   GraphQL Schema ({gen_config.frontend_graphql_dir}):")
            click.echo("      - schema.graphql")

        if generate_cdk:
            click.echo(f"\n   CDK Constructs ({gen_config.cdk_output_dir}):")
            for name in schemas.keys():
                click.echo(f"      - {name.lower()}_table.py")

        click.echo(click.style("\nDry run complete - no files were written", fg="green"))
        return

    # Handle diff mode
    if diff:
        click.echo(click.style("DIFF MODE - Showing changes\n", fg="cyan"))

        # Load configuration
        if config:
            gen_config = GeneratorConfig.from_file(config)
        else:
            default_config = Path("schema-generator.yml")
            if default_config.exists():
                gen_config = GeneratorConfig.from_file(str(default_config))
            else:
                click.echo(click.style("No configuration file found", fg="red"))
                return

        # Generate to temporary location
        import tempfile
        import difflib

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create temporary config with temp output paths
            temp_config = GeneratorConfig()
            temp_config.schema_dir = gen_config.schema_dir
            temp_config.schema_subdirectories = gen_config.schema_subdirectories
            temp_config.backend_models_dir = temp_path / "backend" / "models"
            temp_config.backend_enums_file = temp_path / "backend" / "enums.py"
            temp_config.frontend_models_dir = temp_path / "frontend" / "models"
            temp_config.frontend_enums_file = temp_path / "frontend" / "enums.ts"
            temp_config.frontend_graphql_dir = temp_path / "frontend" / "graphql"
            temp_config.cdk_output_dir = temp_path / "infrastructure" / "cdk"

            # Generate to temp location
            from .fluent_api import Generator

            gen = Generator.from_config_object(temp_config)

            if only:
                gen = gen.only(*only)
            if exclude:
                gen = gen.exclude(*exclude)
            if python_only:
                gen = gen.python_only()
            elif typescript_only:
                gen = gen.typescript_only()
            elif graphql_only:
                gen = gen.graphql_only()
            elif cdk_only:
                gen = gen.cdk_only()

            gen.generate()

            # Compare files
            has_differences = False

            def compare_files(temp_file: Path, real_file: Path, label: str):
                nonlocal has_differences

                if not real_file.exists():
                    click.echo(click.style(f"\n[NEW] {label}", fg="green"))
                    has_differences = True
                    return

                with open(temp_file, "r") as f:
                    temp_content = f.readlines()
                with open(real_file, "r") as f:
                    real_content = f.readlines()

                diff = list(
                    difflib.unified_diff(
                        real_content,
                        temp_content,
                        fromfile=f"current/{label}",
                        tofile=f"generated/{label}",
                        lineterm="",
                    )
                )

                if diff:
                    has_differences = True
                    click.echo(click.style(f"\n[MODIFIED] {label}", fg="yellow"))
                    for line in diff[:50]:  # Limit to first 50 lines
                        if line.startswith("+"):
                            click.echo(click.style(line, fg="green"))
                        elif line.startswith("-"):
                            click.echo(click.style(line, fg="red"))
                        elif line.startswith("@@"):
                            click.echo(click.style(line, fg="cyan"))
                        else:
                            click.echo(line)

                    if len(diff) > 50:
                        click.echo(
                            click.style(f"   ... ({len(diff) - 50} more lines)", fg="yellow")
                        )

            # Compare Python files
            if (temp_path / "backend" / "models").exists():
                for temp_file in (temp_path / "backend" / "models").glob("*.py"):
                    real_file = gen_config.backend_models_dir / temp_file.name
                    compare_files(temp_file, real_file, f"backend/models/{temp_file.name}")

            # Compare TypeScript files
            if (temp_path / "frontend" / "models").exists():
                for temp_file in (temp_path / "frontend" / "models").glob("*.ts"):
                    real_file = gen_config.frontend_models_dir / temp_file.name
                    compare_files(temp_file, real_file, f"frontend/models/{temp_file.name}")

            # Compare GraphQL
            graphql_temp = temp_path / "frontend" / "graphql" / "schema.graphql"
            if graphql_temp.exists():
                compare_files(
                    graphql_temp,
                    gen_config.frontend_graphql_dir / "schema.graphql",
                    "schema.graphql",
                )

            # Compare CDK files
            if (temp_path / "infrastructure" / "cdk").exists():
                for temp_file in (temp_path / "infrastructure" / "cdk").glob("*.py"):
                    real_file = gen_config.cdk_output_dir / temp_file.name
                    compare_files(temp_file, real_file, f"infrastructure/cdk/{temp_file.name}")

            if not has_differences:
                click.echo(
                    click.style(
                        "No differences detected - generated files match existing files", fg="green"
                    )
                )
            else:
                click.echo(click.style("\nDiff complete", fg="cyan"))

        return

    # Handle interactive mode - will be handled during generation
    interactive_mode = interactive

    # Handle selective generation
    if only:
        click.echo(f'Generating only: {", ".join(only)}')
    if exclude:
        click.echo(f'Excluding: {", ".join(exclude)}')

    # Determine what to generate
    generate_python = not skip_python and (
        not any([typescript_only, graphql_only, cdk_only]) or python_only
    )
    generate_typescript = not skip_typescript and (
        not any([python_only, graphql_only, cdk_only]) or typescript_only
    )
    generate_graphql = not skip_graphql and (
        not any([python_only, typescript_only, cdk_only]) or graphql_only
    )
    generate_cdk = not skip_cdk and (
        not any([python_only, typescript_only, graphql_only]) or cdk_only
    )

    if python_only or typescript_only or graphql_only or cdk_only:
        formats = []
        if generate_python:
            formats.append("Python")
        if generate_typescript:
            formats.append("TypeScript")
        if generate_graphql:
            formats.append("GraphQL")
        if generate_cdk:
            formats.append("CDK")
        click.echo(f'Generating: {", ".join(formats)}\n')

    # Generate
    start_time = time.time() if profile else None

    try:
        # Use fluent API for selective generation
        from .fluent_api import Generator

        gen = Generator.from_config(str(config) if config else "schema-generator.yml")

        # Apply schema filters
        if only:
            gen = gen.only(*only)
        if exclude:
            gen = gen.exclude(*exclude)

        # Apply format filters
        if python_only:
            gen = gen.python_only()
        elif typescript_only:
            gen = gen.typescript_only()
        elif graphql_only:
            gen = gen.graphql_only()
        elif cdk_only:
            gen = gen.cdk_only()
        else:
            # Apply skip flags
            if skip_python:
                gen = gen.skip_python()
            if skip_typescript:
                gen = gen.skip_typescript()
            if skip_graphql:
                gen = gen.skip_graphql()
            if skip_cdk:
                gen = gen.skip_cdk()

        # Interactive mode - prompt for each file
        if interactive_mode:
            click.echo(click.style("INTERACTIVE MODE\n", fg="cyan"))

            files_to_generate = []
            files_to_skip = []

            def file_callback(event):
                file_path = event.data.get("file")
                if file_path:
                    response = click.confirm(f"Generate {file_path}?", default=True)
                    if response:
                        files_to_generate.append(file_path)
                        click.echo(click.style(f"  OK: {file_path}", fg="green"))
                    else:
                        files_to_skip.append(file_path)
                        click.echo(click.style(f"  SKIP: {file_path}", fg="yellow"))

            gen = gen.on_file_generated(file_callback)
            click.echo("You will be prompted for each file...\n")

        result = gen.generate()

        if profile:
            elapsed = time.time() - start_time
            click.echo(click.style("\nPerformance Profile:", fg="cyan"))
            click.echo(f"   Total time: {elapsed:.2f}s")
            click.echo(f'   Schemas processed: {result.get("schemas_processed", 0)}')
            if result.get("schemas_processed", 0) > 0:
                click.echo(f'   Avg time per schema: {elapsed/result["schemas_processed"]:.2f}s')

            if result.get("stage_times"):
                click.echo("\n   Stage times:")
                for stage, duration in result["stage_times"].items():
                    click.echo(f"     {stage}: {duration:.2f}s")

        if format_code:
            click.echo(click.style("\nFormatting code...", fg="cyan"))
            _format_generated_code(gen_config)

        if lint:
            click.echo(click.style("\nLinting code...", fg="cyan"))
            _lint_generated_code(gen_config)

        click.echo(click.style("\nGeneration completed successfully!", fg="green"))
    except Exception as e:
        click.echo(click.style(f"Generation failed: {str(e)}", fg="red"))
        import sys

        sys.exit(1)


@main.command()
@click.option("--config", "-c", type=click.Path(exists=True), help="Path to configuration file")
@click.option(
    "--schema-dir", type=click.Path(exists=True), help="Directory containing schema files"
)
def validate(config, schema_dir):
    """Validate schema files."""
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    if config:
        gen_config = GeneratorConfig.from_file(config)
    else:
        gen_config = GeneratorConfig()
        if schema_dir:
            gen_config.schema_dir = Path(schema_dir)

    generator = SchemaGenerator(gen_config)
    try:
        generator.validate_schemas()
        click.echo(click.style("All schemas are valid!", fg="green"))
    except Exception as e:
        click.echo(click.style(f"Validation failed: {str(e)}", fg="red"))
        raise click.Abort()


@main.command()
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default="schema-generator.yml",
    help="Output configuration file path",
)
def init(output):
    """Initialize a new configuration file."""
    config = GeneratorConfig()
    config.save(output)
    click.echo(click.style(f"Created configuration file: {output}", fg="green"))
    click.echo("\nNext steps:")
    click.echo("1. Edit the configuration file to match your project structure")
    click.echo("2. Create schema files in the schemas directory")
    click.echo("3. Run: orb-schema generate")


@main.command()
@click.argument("schema_file", type=click.Path(exists=True))
def inspect(schema_file):
    """Inspect a schema file and show what would be generated."""
    from .core.loaders import SchemaLoader
    from .core.builders import OperationBuilder
    from .core.models import TableSchema

    loader = SchemaLoader(Path(schema_file).parent)
    schema_dict = loader._load_schema_file(schema_file)

    click.echo(f"\nSchema: {schema_dict['name']}")
    click.echo(f"   Type: {schema_dict['type']}")

    if schema_dict["type"] in ["dynamodb", "lambda-dynamodb"]:
        # Parse and build operations
        schemas = loader.load_all_schemas()
        schema = schemas.get(schema_dict["name"])

        if isinstance(schema, TableSchema):
            builder = OperationBuilder(schema)
            operations = builder.build_all_operations()

            click.echo(f"\nOperations ({len(operations)}):")
            for op in operations:
                click.echo(f"   • {op.type}: {op.field}")
                if op.response_auth_directives:
                    click.echo(f"     Auth: {', '.join(op.response_auth_directives)}")


@main.command()
@click.option(
    "--from-structure",
    type=click.Choice(["flat", "typed"]),
    default="flat",
    help="Source structure type",
)
@click.option(
    "--to-structure",
    type=click.Choice(["flat", "typed"]),
    default="typed",
    help="Target structure type",
)
@click.option(
    "--schema-dir",
    type=click.Path(exists=True),
    default="./schemas",
    help="Schema directory to migrate",
)
@click.option("--dry-run", is_flag=True, help="Show what would be done without making changes")
@click.option(
    "--config", "-c", type=click.Path(exists=True), help="Path to configuration file to update"
)
def migrate(from_structure, to_structure, schema_dir, dry_run, config):
    """Migrate schema organization structure."""
    import shutil
    import glob
    from .core.loaders import SchemaLoader

    schema_path = Path(schema_dir)

    if not schema_path.exists():
        click.echo(click.style(f"Schema directory not found: {schema_dir}", fg="red"))
        raise click.Abort()

    if from_structure == to_structure:
        click.echo(
            click.style("Source and target structures are the same. Nothing to do.", fg="yellow")
        )
        return

    click.echo(f"\nMigrating schemas from '{from_structure}' to '{to_structure}' structure...")
    click.echo(f"   Directory: {schema_path}")

    if dry_run:
        click.echo(click.style("   Mode: DRY RUN (no changes will be made)", fg="yellow"))

    # Load schemas to determine their types
    temp_config = GeneratorConfig()
    temp_config.schema_dir = schema_path
    temp_config.schema_subdirectories = None  # Start with flat

    loader = SchemaLoader(temp_config)

    try:
        schemas = loader.load_all_schemas()
        click.echo(f"\nFound {len(schemas)} schemas")

        # Group schemas by type
        schema_groups = {
            "tables": [],
            "models": [],
            "registries": [],
            "graphql": [],
            "lambdas": [],
        }

        for schema in schemas.values():
            schema_type = schema.type
            if schema_type in ["dynamodb", "lambda-dynamodb"]:
                schema_groups["tables"].append(schema.name)
            elif schema_type == "standard":
                schema_groups["models"].append(schema.name)
            elif schema_type == "registry":
                schema_groups["registries"].append(schema.name)
            elif schema_type == "graphql":
                schema_groups["graphql"].append(schema.name)
            elif schema_type == "lambda":
                schema_groups["lambdas"].append(schema.name)

        # Show migration plan
        click.echo("\nMigration Plan:")
        for group_name, schema_names in schema_groups.items():
            if schema_names:
                click.echo(f"   {group_name}/: {len(schema_names)} schemas")
                if dry_run:
                    for name in schema_names:
                        click.echo(f"      • {name}.yml")

        if to_structure == "typed":
            # Migrate from flat to typed structure
            click.echo("\nCreating subdirectories...")

            for group_name, schema_names in schema_groups.items():
                if not schema_names:
                    continue

                target_dir = schema_path / group_name

                if not dry_run:
                    target_dir.mkdir(exist_ok=True)
                    click.echo(f"   Created {group_name}/")
                else:
                    click.echo(f"   Would create {group_name}/")

                # Move schema files
                for schema_name in schema_names:
                    source_file = schema_path / f"{schema_name}.yml"
                    target_file = target_dir / f"{schema_name}.yml"

                    if source_file.exists():
                        if not dry_run:
                            shutil.move(str(source_file), str(target_file))
                            click.echo(f"      Moved {schema_name}.yml → {group_name}/")
                        else:
                            click.echo(f"      Would move {schema_name}.yml → {group_name}/")

        elif to_structure == "flat":
            # Migrate from typed to flat structure
            click.echo("\nMoving schemas to root...")

            for group_name in schema_groups.keys():
                group_dir = schema_path / group_name
                if group_dir.exists() and group_dir.is_dir():
                    schema_files = glob.glob(str(group_dir / "*.yml"))

                    for schema_file in schema_files:
                        source_file = Path(schema_file)
                        target_file = schema_path / source_file.name

                        if not dry_run:
                            shutil.move(str(source_file), str(target_file))
                            click.echo(
                                f"   Moved {group_name}/{source_file.name} → {source_file.name}"
                            )
                        else:
                            click.echo(
                                f"   Would move {group_name}/{source_file.name} → {source_file.name}"
                            )

                    # Remove empty directory
                    if not dry_run and not list(group_dir.iterdir()):
                        group_dir.rmdir()
                        click.echo(f"   Removed empty directory: {group_name}/")

        # Update config file if provided
        if config and not dry_run:
            click.echo(f"\n⚙️  Updating configuration file: {config}")
            gen_config = GeneratorConfig.from_file(config)

            if to_structure == "typed":
                gen_config.schema_subdirectories = {
                    "core": "core",
                    "tables": "tables",
                    "models": "models",
                    "registries": "registries",
                    "graphql": "graphql",
                    "lambdas": "lambdas",
                }
            else:
                gen_config.schema_subdirectories = None

            gen_config.save(config)
            click.echo("   Configuration updated")

        if dry_run:
            click.echo(
                click.style(
                    "\nDry run complete. Run without --dry-run to apply changes.", fg="green"
                )
            )
        else:
            click.echo(
                click.style(f"\nMigration to {to_structure} structure complete!", fg="green")
            )

            if not config:
                click.echo("\nTip: Update your schema-generator.yml configuration:")
                if to_structure == "typed":
                    click.echo("   paths:")
                    click.echo("     subdirectories:")
                    click.echo("       core: core")
                    click.echo("       tables: tables")
                    click.echo("       models: models")
                    click.echo("       registries: registries")
                    click.echo("       graphql: graphql")
                    click.echo("       lambdas: lambdas")
                else:
                    click.echo("   paths:")
                    click.echo("     subdirectories: null")

    except Exception as e:
        click.echo(click.style(f"Migration failed: {str(e)}", fg="red"))
        raise click.Abort()


@main.command()
@click.option("--config", "-c", type=click.Path(exists=True), help="Path to configuration file")
@click.option("--schema-dir", type=click.Path(exists=True), help="Directory to watch for changes")
@click.option(
    "--debounce", type=float, default=2.0, help="Seconds to wait before regenerating (default: 2.0)"
)
def watch(config, schema_dir, debounce):
    """Watch schema files and regenerate on changes."""
    from .watcher import FileWatcher
    from .core.config import GeneratorConfig
    from .generator import SchemaGenerator

    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    # Load configuration
    if config:
        gen_config = GeneratorConfig.from_file(config)
    else:
        default_config = Path("schema-generator.yml")
        if default_config.exists():
            gen_config = GeneratorConfig.from_file(str(default_config))
        else:
            gen_config = GeneratorConfig()
            if schema_dir:
                gen_config.schema_dir = Path(schema_dir)

    watch_path = Path(schema_dir) if schema_dir else gen_config.schema_dir

    click.echo(f"\nWatching for changes in: {watch_path}")
    click.echo(f"   Debounce: {debounce}s")
    click.echo("   Press Ctrl+C to stop\n")

    # Define regeneration callback
    def regenerate():
        click.echo(click.style("\nChanges detected, regenerating...", fg="yellow"))
        generator = SchemaGenerator(gen_config)
        try:
            generator.generate_all()
            click.echo(click.style("Regeneration complete!\n", fg="green"))
        except Exception as e:
            click.echo(click.style(f"Regeneration failed: {str(e)}\n", fg="red"))

    # Initial generation
    click.echo(click.style("Running initial generation...", fg="cyan"))
    regenerate()

    # Start watching
    try:
        watcher = FileWatcher(
            watch_path=watch_path, callback=regenerate, debounce_seconds=debounce, recursive=True
        )

        watcher.start()

        # Keep running until interrupted
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            click.echo(click.style("\n\nStopping watcher...", fg="yellow"))
            watcher.stop()
            click.echo(click.style("Watcher stopped", fg="green"))

    except FileNotFoundError as e:
        click.echo(click.style(f"{str(e)}", fg="red"))
        raise click.Abort()
    except Exception as e:
        click.echo(click.style(f"Watch failed: {str(e)}", fg="red"))
        raise click.Abort()


@main.command("validate-config")
@click.option(
    "--config",
    "-c",
    type=click.Path(),
    default="schema-generator.yml",
    help="Path to configuration file",
)
@click.option("--fix", is_flag=True, help="Auto-fix common issues")
@click.option("--schema", is_flag=True, help="Output JSON schema")
def validate_config(config, fix, schema):
    """Validate schema-generator.yml configuration."""
    import json
    from .core.validator import ConfigValidator

    validator = ConfigValidator(config)

    if schema:
        click.echo(json.dumps(validator.get_schema(), indent=2))
        return

    result = validator.validate()

    # Display version
    try:
        from importlib.metadata import version

        pkg_version = version("orb-schema-generator")
    except Exception:
        pkg_version = "unknown"
    click.echo(f"orb-schema-generator v{pkg_version}\n")

    # Display errors
    for issue in result.errors:
        click.echo(click.style(f"ERROR [{issue.field_path}]: {issue.message}", fg="red"))
        if issue.suggestion:
            click.echo(f"       Suggestion: {issue.suggestion}")

    # Display warnings
    for issue in result.warnings:
        click.echo(click.style(f"WARNING [{issue.field_path}]: {issue.message}", fg="yellow"))
        if issue.suggestion:
            click.echo(f"         Suggestion: {issue.suggestion}")

    if fix and (result.errors or result.warnings):
        click.echo("\nAttempting auto-fix...")
        fix_result = validator.fix()
        for change in fix_result.changes:
            click.echo(click.style(f"  FIXED: {change}", fg="green"))
        if fix_result.remaining_issues:
            click.echo("\nRemaining issues (manual fix required):")
            for issue in fix_result.remaining_issues:
                click.echo(f"  - {issue.message}")

    # Validate targets if config is valid
    target_errors = []
    if result.valid:
        try:
            from .core.target_validator import TargetValidator
            from .core.loaders import SchemaLoader

            gen_config = GeneratorConfig.from_file(config)
            loader = SchemaLoader(gen_config)
            schemas = loader.load_all_schemas()

            target_validator = TargetValidator()
            target_result = target_validator.validate(schemas, gen_config)

            if not target_result.is_valid:
                click.echo(click.style("\nTarget validation errors:", fg="red"))
                for error in target_result.errors:
                    click.echo(click.style(f"  ERROR: {error.message}", fg="red"))
                    target_errors.append(error)
        except Exception as e:
            click.echo(click.style(f"\nTarget validation failed: {str(e)}", fg="red"))
            target_errors.append(str(e))

    if result.valid and not target_errors:
        click.echo(click.style("\n✓ Configuration is valid", fg="green"))
    elif target_errors:
        click.echo(click.style("\n✗ Target validation has errors", fg="red"))
        raise SystemExit(1)
    else:
        click.echo(click.style("\n✗ Configuration has errors", fg="red"))
        click.echo("  Run with --fix to auto-correct common issues")
        raise SystemExit(1)


@main.command()
@click.option("--since", required=True, help="Show changes since this version (e.g., 0.8.0)")
def whatsnew(since):
    """Show what's new since a specified version."""
    import re
    from importlib.resources import files

    content = None

    # Try 1: Read from package resources (works when installed from CodeArtifact)
    try:
        changelog_resource = files("orb_schema_generator").joinpath("CHANGELOG.md")
        content = changelog_resource.read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError, ModuleNotFoundError, OSError):
        pass

    # Try 2: Read from repo root (development mode)
    if content is None:
        changelog_path = Path(__file__).parent.parent / "CHANGELOG.md"
        if changelog_path.exists():
            content = changelog_path.read_text(encoding="utf-8")

    # Try 3: Read from current directory (fallback)
    if content is None:
        changelog_path = Path("CHANGELOG.md")
        if changelog_path.exists():
            content = changelog_path.read_text(encoding="utf-8")

    if content is None:
        click.echo(click.style("CHANGELOG.md not found", fg="red"))
        raise SystemExit(1)

    # Parse changelog sections
    version_pattern = r"\[(\d+\.\d+\.\d+)\]"
    sections = re.split(r"(?=## \[\d+\.\d+\.\d+\])", content)

    def version_greater_than(v1: str, v2: str) -> bool:
        """Compare semantic versions."""

        def parse(v):
            return tuple(int(x) for x in v.split("."))

        return parse(v1) > parse(v2)

    # Find versions >= since
    found_since = False
    output_sections = []

    for section in sections:
        match = re.search(version_pattern, section)
        if match:
            version = match.group(1)
            if version == since:
                found_since = True
                continue  # Don't include the 'since' version itself
            if found_since or version_greater_than(version, since):
                output_sections.append(section.strip())

    if not found_since and not output_sections:
        # List available versions
        available = re.findall(version_pattern, content)
        click.echo(click.style(f"Version {since} not found in CHANGELOG.md", fg="red"))
        if available:
            click.echo(f"Available versions: {', '.join(available[:10])}")
        raise SystemExit(1)

    if not output_sections:
        click.echo(f"No changes since {since}")
        return

    click.echo(f"Changes since {since}:\n")
    for section in output_sections:
        click.echo(section)
        click.echo()


@main.command("validate-graphql")
@click.option(
    "--schema",
    "-s",
    type=click.Path(exists=True),
    required=True,
    help="Path to GraphQL schema file",
)
@click.option(
    "--strict/--no-strict",
    default=True,
    help="Exit with error code on validation failure (default: strict)",
)
def validate_graphql(schema, strict):
    """Validate a GraphQL schema file.

    Performs comprehensive validation including:
    - GraphQL syntax validation
    - Duplicate type detection
    - Unknown type reference detection
    - AppSync-specific checks
    """
    from .core.validators import SchemaValidator
    from .core.models import SchemaValidationError

    try:
        errors = SchemaValidator.validate_graphql_sdl(schema, strict=strict)

        if errors:
            click.echo(click.style("GraphQL validation issues:", fg="yellow"))
            for error in errors:
                click.echo(f"  • {error}")
            if strict:
                raise SystemExit(1)
        else:
            click.echo(click.style(f"✓ GraphQL schema is valid: {schema}", fg="green"))

    except SchemaValidationError as e:
        click.echo(click.style("✗ GraphQL validation failed:", fg="red"))
        click.echo(str(e))
        raise SystemExit(1)
    except Exception as e:
        click.echo(click.style(f"✗ Validation error: {str(e)}", fg="red"))
        raise SystemExit(1)


@main.command("check-update")
def check_update():
    """Check for newer versions of orb-schema-generator.

    Queries PyPI to see if a newer version is available and displays
    the upgrade command if an update is found.
    """
    from .core.version_checker import VersionChecker

    checker = VersionChecker()

    # Get current version
    current_version = checker.get_current_version()
    click.echo(f"Current version: {current_version}")

    # Get latest version (force network check, don't use cache)
    click.echo("Checking for updates...")
    latest_version = checker.get_latest_version(use_cache=False)

    if latest_version is None:
        click.echo(click.style("✗ Unable to check for updates (network unavailable)", fg="red"))
        raise SystemExit(1)

    click.echo(f"Latest version:  {latest_version}")

    # Compare versions
    if checker._is_newer(latest_version, current_version):
        click.echo(click.style("\n⚠️  A newer version is available!", fg="yellow"))
        click.echo("\nTo upgrade, run:")
        click.echo(click.style(f"  pip install --upgrade {checker.PACKAGE_NAME}", fg="cyan"))
    else:
        click.echo(click.style("\n✓ You are running the latest version", fg="green"))


if __name__ == "__main__":
    main()
