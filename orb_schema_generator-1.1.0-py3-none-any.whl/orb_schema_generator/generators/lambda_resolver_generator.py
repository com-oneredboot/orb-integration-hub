"""Lambda resolver template generator for AWS AppSync Lambda-backed operations."""

import re
from pathlib import Path
from typing import Any, Dict, List, Union
import logging

from .base import BaseGenerator
from ..core.models import TableSchema, LambdaType
from ..utils.case_conversion import to_pascal_case
from ..utils.vtl_builder import VTLTemplateBuilder, validate_vtl_syntax
from ..utils.console import success

logger = logging.getLogger(__name__)


class LambdaResolverGenerator(BaseGenerator):
    """Generates VTL resolver templates for AppSync Lambda-backed resolvers.

    Supports two schema types:
    - 'lambda': Pure Lambda resolvers (simple invoke with $ctx.args)
    - 'lambda-dynamodb': Lambda resolvers with DynamoDB backend (rich payload)
    """

    # Operation type mapping
    MUTATION_OPERATIONS = {"Create", "Update", "Delete", "Disable"}
    QUERY_OPERATIONS = {"Get", "List", "QueryBy"}

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate VTL templates for all Lambda and Lambda-DynamoDB schemas.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info("Generating Lambda resolver templates...")

        template_count = 0
        for name, schema in schemas.items():
            schema_type = getattr(schema, "type", None)
            if schema_type in ("lambda", "lambda-dynamodb"):
                count = self._generate_schema_templates(schema)
                template_count += count

        logger.info(success(f"Generated {template_count} Lambda resolver templates"))

    def _generate_schema_templates(self, schema: Union[TableSchema, LambdaType]) -> int:
        """
        Generate all VTL templates for a single schema.

        Args:
            schema: Schema to generate templates for

        Returns:
            Number of templates generated
        """
        count = 0
        schema_type = getattr(schema, "type", "lambda")

        if schema_type == "lambda" and isinstance(schema, LambdaType):
            # Pure Lambda - single operation
            operations = self._get_pure_lambda_operations(schema)
        elif isinstance(schema, TableSchema):
            # Lambda-DynamoDB - CRUD + GSI operations
            operations = self._get_lambda_dynamodb_operations(schema)
        else:
            operations = []

        for operation in operations:
            try:
                # Generate request template
                request_content = self._generate_request_template(schema, operation)
                is_valid, errors = validate_vtl_syntax(request_content)
                if not is_valid:
                    logger.warning(
                        f"VTL syntax issues in {schema.name} {operation['name']} request: {errors}"
                    )

                request_path = self._get_output_path(schema.name, operation, "request")
                self._write_file(request_path, request_content)
                count += 1

                # Generate response template
                response_content = self._generate_response_template(schema, operation)
                is_valid, errors = validate_vtl_syntax(response_content)
                if not is_valid:
                    logger.warning(
                        f"VTL syntax issues in {schema.name} {operation['name']} response: {errors}"
                    )

                response_path = self._get_output_path(schema.name, operation, "response")
                self._write_file(response_path, response_content)
                count += 1

            except Exception as e:
                logger.error(
                    f"Error generating templates for {schema.name} {operation['name']}: {e}"
                )
                continue

        logger.debug(f"Generated {count} Lambda templates for {schema.name}")
        return count

    def _get_pure_lambda_operations(self, schema: LambdaType) -> List[Dict[str, Any]]:
        """
        Get operations for a pure Lambda schema.

        Args:
            schema: Lambda schema

        Returns:
            List with single operation definition
        """
        # Pure Lambda schemas have a single operation
        # Default to Mutation, but could be Query based on naming convention
        op_type = "Mutation"
        if (
            schema.name.startswith("Get")
            or schema.name.startswith("List")
            or schema.name.startswith("Query")
        ):
            op_type = "Query"

        return [{"name": schema.name, "type": op_type, "field": schema.name}]

    def _get_lambda_dynamodb_operations(self, schema: TableSchema) -> List[Dict[str, Any]]:
        """
        Get operations for a Lambda-DynamoDB schema.

        Args:
            schema: Table schema with lambda-dynamodb type

        Returns:
            List of operation definitions
        """
        # Check if schema has explicit operations defined
        if hasattr(schema, "operations") and schema.operations:
            # Convert Operation objects to dicts
            return [
                {
                    "name": op.name,
                    "type": op.type,
                    "field": op.field,
                    "index_name": op.index_name,
                    "index_partition": op.index_partition,
                }
                for op in schema.operations
            ]

        # Generate default CRUD operations
        operations = [
            {"name": "Create", "type": "Mutation", "field": f"{schema.name}Create"},
            {"name": "Update", "type": "Mutation", "field": f"{schema.name}Update"},
            {"name": "Delete", "type": "Mutation", "field": f"{schema.name}Delete"},
            {"name": "Disable", "type": "Mutation", "field": f"{schema.name}Disable"},
        ]

        # Add QueryBy for partition key
        pk = schema.partition_key
        pk_pascal = self._to_pascal_case(pk)
        operations.append(
            {
                "name": f"QueryBy{pk_pascal}",
                "type": "Query",
                "field": f"{schema.name}QueryBy{pk_pascal}",
            }
        )

        # Add QueryBy operations for secondary indexes
        if schema.secondary_indexes:
            for index in schema.secondary_indexes:
                if index.get("type") == "GSI":
                    partition = index.get("partition", "")
                    partition_pascal = self._to_pascal_case(partition)
                    operations.append(
                        {
                            "name": f"QueryBy{partition_pascal}",
                            "type": "Query",
                            "field": f"{schema.name}QueryBy{partition_pascal}",
                            "index_name": index.get("name", ""),
                            "index_partition": partition,
                        }
                    )

        return operations

    def _generate_request_template(
        self, schema: Union[TableSchema, LambdaType], operation: Dict[str, Any]
    ) -> str:
        """
        Generate request mapping template for a Lambda operation.

        Args:
            schema: Schema definition
            operation: Operation definition

        Returns:
            VTL request template content
        """
        schema_type = getattr(schema, "type", "lambda")

        if schema_type == "lambda" and isinstance(schema, LambdaType):
            return self._generate_pure_lambda_request(schema)
        elif isinstance(schema, TableSchema):
            return self._generate_lambda_dynamodb_request(schema, operation)
        else:
            return ""

    def _generate_response_template(
        self, schema: Union[TableSchema, LambdaType], operation: Dict[str, Any]
    ) -> str:
        """
        Generate response mapping template for a Lambda operation.

        Args:
            schema: Schema definition
            operation: Operation definition

        Returns:
            VTL response template content
        """
        schema_type = getattr(schema, "type", "lambda")

        if schema_type == "lambda" and isinstance(schema, LambdaType):
            return self._generate_pure_lambda_response(schema)
        else:
            return self._generate_lambda_dynamodb_response(operation)

    def _generate_pure_lambda_request(self, schema: LambdaType) -> str:
        """
        Generate request template for pure Lambda schema.

        Invokes Lambda with input from GraphQL arguments.
        """
        builder = VTLTemplateBuilder()

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"Invoke"')
        builder.add_vtl_property("payload", "$util.toJson($ctx.arguments.input)", is_last=True)
        builder.add_vtl_json_end()

        return builder.build()

    def _generate_pure_lambda_response(self, schema: LambdaType) -> str:
        """
        Generate response template for pure Lambda schema.

        Includes error handling and result serialization.
        """
        builder = VTLTemplateBuilder()
        # Add error handling
        builder.add_line("#if($ctx.error)")
        builder.add_line("    $util.error($ctx.error.message, $ctx.error.type)")
        builder.add_line("#end")
        builder.add_line("$util.toJson($ctx.result)")
        return builder.build()

    def _generate_lambda_dynamodb_request(
        self, schema: TableSchema, operation: Dict[str, Any]
    ) -> str:
        """
        Generate request template for Lambda-DynamoDB schema.

        Rich payload with info, arguments, identity, source, request, prev, stash.
        """
        builder = VTLTemplateBuilder()
        field_name = operation.get("field", f"{schema.name}{operation['name']}")
        type_name = operation.get("type", "Mutation")

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"Invoke"')
        builder.add_line('"payload": {')
        builder.indent()

        # Info field with GraphQL context
        builder.add_line('"info": {')
        builder.indent()
        builder.add_vtl_property("fieldName", f'"{field_name}"')
        builder.add_vtl_property("parentTypeName", f'"{type_name}"')
        builder.add_vtl_property("selectionSetList", "$util.toJson($ctx.info.selectionSetList)")
        builder.add_vtl_property(
            "selectionSetGraphQL", "$util.toJson($ctx.info.selectionSetGraphQL)", is_last=True
        )
        builder.dedent()
        builder.add_line("},")

        # Other context fields
        builder.add_vtl_property("arguments", "$util.toJson($ctx.args)")
        builder.add_vtl_property("identity", "$util.toJson($ctx.identity)")
        builder.add_vtl_property("source", "$util.toJson($ctx.source)")
        builder.add_vtl_property("request", "$util.toJson($ctx.request)")
        builder.add_vtl_property("prev", "$util.toJson($ctx.prev)")
        builder.add_vtl_property("stash", "$util.toJson($ctx.stash)", is_last=True)

        builder.dedent()
        builder.add_line("}")
        builder.add_vtl_json_end()

        return builder.build()

    def _generate_lambda_dynamodb_response(self, operation: Dict[str, Any]) -> str:
        """
        Generate response template for Lambda-DynamoDB schema.

        Includes status code checking and error handling.
        """
        builder = VTLTemplateBuilder()
        returns = operation.get("returns", "")
        is_array = returns.startswith("[") if returns else False

        # Status code checking for Lambda-DynamoDB
        builder.add_line("#if($ctx.result.StatusCode == 200)")
        builder.indent()
        if is_array:
            builder.add_line("$util.toJson($ctx.result.Data)")
        else:
            builder.add_line("$util.toJson($ctx.result)")
        builder.dedent()
        builder.add_line("#else")
        builder.indent()
        builder.add_line("$util.error($ctx.result.Message)")
        builder.dedent()
        builder.add_line("#end")

        return builder.build()

    def _get_output_path(
        self, schema_name: str, operation: Dict[str, Any], template_type: str
    ) -> Path:
        """
        Get output file path for a VTL template.

        Args:
            schema_name: Name of the schema
            operation: Operation definition
            template_type: 'request' or 'response'

        Returns:
            Path to output file
        """
        type_name = operation.get("type", "Mutation")
        field_name = operation.get("field", f"{schema_name}{operation['name']}")
        filename = f"{type_name}.{field_name}.{template_type}.vtl"

        output_dir = self._get_resolver_output_dir()
        return output_dir / filename

    def _get_resolver_output_dir(self) -> Path:
        """Get the resolver output directory from config."""
        # Use lambda config if available
        if hasattr(self.config, "lambda_config") and self.config.lambda_config:
            if self.config.lambda_config.resolver_output_dir:
                return Path(self.config.lambda_config.resolver_output_dir)

        # Fall back to appsync config
        if hasattr(self.config, "appsync") and self.config.appsync:
            if self.config.appsync.resolver_output_dir:
                return Path(self.config.appsync.resolver_output_dir)

        # Default to CDK output dir / appsync / resolvers
        return Path(self.config.cdk_output_dir) / "appsync" / "resolvers"

    def _get_lambda_arn_reference(self, schema_name: str) -> str:
        """
        Get Lambda ARN reference for a schema.

        Args:
            schema_name: Name of the schema

        Returns:
            Lambda ARN reference (SSM parameter or direct ARN)
        """
        kebab_name = self._to_kebab_case(schema_name)

        # Check for custom ARN pattern
        if hasattr(self.config, "lambda_config") and self.config.lambda_config:
            if self.config.lambda_config.lambda_arn_pattern:
                pattern = self.config.lambda_config.lambda_arn_pattern
                return pattern.replace("${name}", kebab_name)

            if not self.config.lambda_config.use_ssm_parameters:
                # Direct ARN reference (placeholder)
                return f"arn:aws:lambda:${{AWS::Region}}:${{AWS::AccountId}}:function:{kebab_name}"

        # Default: SSM parameter pattern
        customer_id = getattr(self.config, "customer_id", "${CustomerId}")
        project_id = getattr(self.config, "project_id", "${ProjectId}")
        environment = getattr(self.config, "environment", "${Environment}")

        return (
            f"{{{{resolve:ssm:{customer_id}-{project_id}-{environment}-{kebab_name}-lambda-arn}}}}"
        )

    def _to_kebab_case(self, text: str) -> str:
        """
        Convert PascalCase/camelCase to kebab-case.

        Args:
            text: Text to convert

        Returns:
            kebab-case string
        """
        if not text:
            return ""

        # Insert hyphen before uppercase letters (except at start)
        result = re.sub(r"(?<!^)(?=[A-Z])", "-", text)
        return result.lower()

    def _to_pascal_case(self, text: str) -> str:
        """Convert text to PascalCase, preserving acronyms."""
        return to_pascal_case(text)
