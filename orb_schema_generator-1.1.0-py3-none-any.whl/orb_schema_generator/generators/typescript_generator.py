"""TypeScript model generator."""

from typing import Dict, Any, Optional
import logging

from .base import BaseGenerator
from ..core.models import TableSchema, StandardType, LambdaType, RegistryType, Attribute
from ..utils.type_mapping import EnhancedTypeMapper
from ..utils.case_conversion import to_pascal_case, to_typescript_enum_member
from ..utils.console import success

logger = logging.getLogger(__name__)


class TypeScriptGenerator(BaseGenerator):
    """Generates TypeScript models and enums from schemas."""

    def __init__(self, config):
        """Initialize the TypeScript generator with enhanced type mapping."""
        super().__init__(config)
        self.type_mapper = EnhancedTypeMapper()

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate TypeScript models and enums for all schemas.

        Handles all schema types in a unified manner:
        - RegistryType → TypeScript enum with toJson()/fromJson() helpers
        - StandardType, TableSchema, LambdaType → TypeScript classes

        Uses target-based routing to write files to the correct output directories.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info(f"Generating TypeScript code for {len(schemas)} schemas...")

        # Group schemas by target
        schemas_by_target = self._group_by_target(schemas)

        model_count = 0
        enum_count = 0
        query_count = 0

        for target, target_schemas in schemas_by_target.items():
            # Get output config for this target
            output_config = self.config.get_target_config("typescript", target)
            if not output_config:
                # No fallback - missing config is a configuration error
                from ..core.models import ConfigurationError

                raise ConfigurationError(
                    f"No TypeScript output config for target '{target}'. "
                    f"Add it to output.typescript.targets in schema-generator.yml"
                )

            for name, schema in target_schemas.items():
                if isinstance(schema, RegistryType):
                    content = self._generate_enum(schema)
                    # Use to_pascal_case to handle both snake_case and preserve acronyms
                    output_path = output_config.enum_path(to_pascal_case(name) + "Enum", "ts")
                    self._write_file(output_path, content)
                    enum_count += 1
                elif isinstance(schema, (TableSchema, StandardType, LambdaType)):
                    content = self._generate_model(schema, output_config)
                    output_path = output_config.model_path(f"{name}Model", "ts")
                    self._write_file(output_path, content)
                    model_count += 1

            # Generate GraphQL query definition files (Issue #61)
            query_count += self._generate_graphql_queries(
                target_schemas, output_config, all_schemas=schemas
            )

            # Generate GraphQL utility file (Issue #71)
            utils_content = self._generate_graphql_utils()
            utils_path = output_config.base_dir / "graphql-utils.ts"
            self._write_file(utils_path, utils_content)

        logger.info(success(f"Generated {model_count} TypeScript model files"))
        if enum_count > 0:
            logger.info(success(f"Generated {enum_count} TypeScript enum files"))
        if query_count > 0:
            logger.info(success(f"Generated {query_count} TypeScript GraphQL query files"))

    def _generate_enum(self, registry: RegistryType) -> str:
        """
        Generate TypeScript enum from RegistryType with JSON serialization helpers.

        Args:
            registry: RegistryType schema object

        Returns:
            Complete TypeScript enum file content
        """
        lines = []
        # Use to_pascal_case to handle both snake_case and preserve acronyms
        enum_name = to_pascal_case(registry.name)

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("typescript").rstrip())

        # Header comment
        lines.append("/**")
        if registry.description:
            lines.append(f" * {registry.description}")
        else:
            lines.append(f" * Generated TypeScript enum for {enum_name}")
        lines.append(" */")
        lines.append("")

        # Enum declaration
        lines.append(f"export enum {enum_name} {{")

        # Generate enum members with PascalCase names and string values
        for key, item_data in registry.items.items():
            # Convert enum key to PascalCase for TypeScript enum member
            member_name = to_typescript_enum_member(key)

            # Get the JSON value (original value from schema)
            json_value = item_data.get("value", key.lower()) if isinstance(item_data, dict) else key

            # Get description if available
            description = item_data.get("description") if isinstance(item_data, dict) else None

            if description:
                lines.append(f"  /** {description} */")
            lines.append(f'  {member_name} = "{json_value}",')

        lines.append("}")
        lines.append("")

        # Add toJson helper function
        lines.append("/**")
        lines.append(f" * Convert {enum_name} to JSON string value")
        lines.append(" */")
        lines.append(f"export function {enum_name.lower()}ToJson(value: {enum_name}): string {{")
        lines.append("  return value as string;")
        lines.append("}")
        lines.append("")

        # Add fromJson helper function
        lines.append("/**")
        lines.append(f" * Create {enum_name} from JSON string value")
        lines.append(" */")
        lines.append(f"export function {enum_name.lower()}FromJson(json: string): {enum_name} {{")
        lines.append(f"  const values = Object.values({enum_name});")
        lines.append("  const found = values.find((v) => v === json);")
        lines.append("  if (found !== undefined) {")
        lines.append(f"    return found as {enum_name};")
        lines.append("  }")
        lines.append(f"  throw new Error(`Unknown {enum_name} value: ${{json}}`);")
        lines.append("}")

        return "\n".join(lines)

    def _generate_model(self, schema: Any, output_config=None) -> str:
        """
        Generate complete TypeScript model file.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to typescript_output)

        Returns:
            Complete TypeScript model file content
        """
        if output_config is None:
            output_config = self.config.typescript_output

        parts = []
        parts.append(self._generate_imports(schema, output_config))

        # Only generate input types for DynamoDB tables
        if isinstance(schema, TableSchema):
            parts.append(self._generate_input_types(schema))

        parts.append(self._generate_response_types(schema))
        parts.append(self._generate_interface(schema))
        parts.append(self._generate_class(schema))

        return "\n\n".join(parts)

    def _generate_imports(self, schema: Any, output_config=None) -> str:
        """
        Generate import statements using enhanced type mapping.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to typescript_output)

        Returns:
            Import statements
        """
        if output_config is None:
            output_config = self.config.typescript_output

        lines = []
        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("typescript").rstrip())
        lines.append("/**")
        lines.append(f" * Generated TypeScript models for {schema.name}")
        lines.append(" */")
        lines.append("")

        # Collect type mappings for all attributes
        type_mappings = []
        enum_imports = set()
        model_imports = set()

        for attr in schema.attributes:
            if attr.enum_type:
                enum_imports.add(attr.enum_type)

            # Collect model imports from items_ref (array of models)
            if attr.items_ref:
                model_imports.add(attr.items_ref)

            # Collect model imports from object_ref (nested model)
            if attr.object_ref:
                model_imports.add(attr.object_ref)

            # Collect model imports from direct model reference
            if hasattr(attr, "model_reference") and attr.model_reference:
                model_imports.add(attr.model_reference)

            # Get type mapping for standard types
            if not attr.enum_type and not attr.items_ref and not attr.object_ref:
                try:
                    mapping = self.type_mapper.get_type_mapping(attr.type)
                    type_mappings.append(mapping)
                except ValueError:
                    # Fallback for unknown types
                    pass

        # Get required imports from type mappings
        required_imports = self.type_mapper.get_required_imports(type_mappings, "typescript")

        # Add type-specific imports
        if required_imports:
            for import_stmt in sorted(required_imports):
                lines.append(import_stmt)

        # Add enum imports (Issue #19 fix: use relative paths)
        if enum_imports:
            rel_path = output_config.relative_import_path("model", "enum")
            # Remove trailing slash and ensure proper format for TypeScript
            rel_path = rel_path.rstrip("/")
            for enum_name in sorted(enum_imports):
                lines.append(f"import {{ {enum_name} }} from '{rel_path}/{enum_name}Enum';")

        # Add model reference imports (Issue #19 fix: use relative paths)
        # Issue #59: Only import the class, not the interface (which is unused)
        if model_imports:
            rel_path = output_config.relative_import_path("model", "model")
            # Remove trailing slash and ensure proper format for TypeScript
            rel_path = rel_path.rstrip("/")
            for model_name in sorted(model_imports):
                lines.append(f"import {{ {model_name} }} from '{rel_path}/{model_name}Model';")

        return "\n".join(lines)

    def _generate_input_types(self, schema: TableSchema) -> str:
        """
        Generate input types for CRUD and Query operations.

        Issue #84: Refactored to use schema.operations from OperationBuilder
        as the single source of truth, ensuring deduplication when multiple
        GSIs share the same partition key.

        Args:
            schema: Table schema

        Returns:
            Input type definitions
        """
        lines = []
        lines.append("// Input Types")

        # CreateInput
        lines.append(f"export type {schema.name}CreateInput = {{")
        for attr in schema.attributes:
            ts_type = self._typescript_type(attr)
            optional_marker = "?" if not attr.required else ""
            lines.append(f"  {attr.name}{optional_marker}: {ts_type};")
        lines.append("};")

        lines.append("")

        # UpdateInput
        lines.append(f"export type {schema.name}UpdateInput = {{")
        for attr in schema.attributes:
            ts_type = self._typescript_type(attr)
            lines.append(f"  {attr.name}?: {ts_type};")
        lines.append("};")

        lines.append("")

        # Generate query input types from schema.operations (Issue #84 fix)
        # This ensures deduplication when multiple GSIs share the same partition key
        generated_query_inputs: set[str] = set()

        if hasattr(schema, "operations") and schema.operations:
            for op in schema.operations:
                # Only generate for ListBy* operations (queries)
                if op.name.startswith("ListBy") and op.index_partition:
                    # Build input type name using QueryBy* naming for backward compatibility
                    idx_pascal = to_pascal_case(op.index_partition)
                    input_name = f"{schema.name}QueryBy{idx_pascal}Input"

                    # Skip if already generated (deduplication)
                    if input_name in generated_query_inputs:
                        continue
                    generated_query_inputs.add(input_name)

                    lines.append(f"export type {input_name} = {{")
                    lines.append(f"  {op.index_partition}: string;")
                    lines.append("};")
                    lines.append("")

            # Generate QueryByBoth if we have both partition and sort key operations
            pk_pascal = to_pascal_case(schema.partition_key)
            if schema.sort_key and schema.sort_key != "None":
                sk_pascal = to_pascal_case(schema.sort_key)
                lines.append(f"export type {schema.name}QueryByBothInput = {{")
                lines.append(f"  {schema.partition_key}: string;")
                lines.append(f"  {schema.sort_key}: string;")
                lines.append("};")
                lines.append("")
        else:
            # Fallback for schemas without operations (backward compatibility)
            pk_pascal = to_pascal_case(schema.partition_key)
            lines.append(f"export type {schema.name}QueryBy{pk_pascal}Input = {{")
            lines.append(f"  {schema.partition_key}: string;")
            lines.append("};")
            lines.append("")

            if schema.sort_key and schema.sort_key != "None":
                sk_pascal = to_pascal_case(schema.sort_key)
                lines.append(f"export type {schema.name}QueryBy{sk_pascal}Input = {{")
                lines.append(f"  {schema.sort_key}: string;")
                lines.append("};")
                lines.append("")

                lines.append(f"export type {schema.name}QueryByBothInput = {{")
                lines.append(f"  {schema.partition_key}: string;")
                lines.append(f"  {schema.sort_key}: string;")
                lines.append("};")
                lines.append("")

            # Query by secondary indexes (fallback without deduplication)
            if schema.secondary_indexes:
                for index in schema.secondary_indexes:
                    index_partition = index.get("partition")
                    if index_partition:
                        idx_pascal = to_pascal_case(index_partition)
                        lines.append(f"export type {schema.name}QueryBy{idx_pascal}Input = {{")
                        lines.append(f"  {index_partition}: string;")
                        lines.append("};")
                        lines.append("")

        return "\n".join(lines)

    def _generate_response_types(self, schema: Any) -> str:
        """
        Generate response types.

        Issue #78: Updated to match GraphQL response standardization:
        - All responses have envelope: code, success, message
        - Mutation responses have `item` (singular)
        - List responses have `items` (plural) and `nextToken`
        - Get responses have `item` (singular)
        - Renamed QueryBy* to ListBy*

        Issue #84: Refactored to use schema.operations from OperationBuilder
        as the single source of truth, ensuring deduplication when multiple
        GSIs share the same partition key.

        Args:
            schema: Schema object

        Returns:
            Response type definitions
        """
        lines = []
        lines.append("// Response Types")

        # Mutation response types (single item)
        lines.append(f"export type {schema.name}CreateResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  item?: {schema.name};")
        lines.append("};")

        lines.append("")

        lines.append(f"export type {schema.name}UpdateResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  item?: {schema.name};")
        lines.append("};")

        lines.append("")

        lines.append(f"export type {schema.name}DeleteResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  item?: {schema.name};")
        lines.append("};")

        lines.append("")

        lines.append(f"export type {schema.name}DisableResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  item?: {schema.name};")
        lines.append("};")

        lines.append("")

        # Get response type (single item)
        lines.append(f"export type {schema.name}GetResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  item?: {schema.name};")
        lines.append("};")

        lines.append("")

        # List response type (multiple items with pagination)
        lines.append(f"export type {schema.name}ListResponse = {{")
        lines.append("  code: number;")
        lines.append("  success: boolean;")
        lines.append("  message?: string;")
        lines.append(f"  items?: {schema.name}[];")
        lines.append("  nextToken?: string;")
        lines.append("};")

        # GraphQL response wrappers (only for TableSchema)
        if isinstance(schema, TableSchema):
            lines.append("")
            lines.append("")
            lines.append("// GraphQL Response Wrappers")

            lines.append(f"export type {schema.name}CreateMutationResponse = {{")
            lines.append(f"  {schema.name}Create: {schema.name}CreateResponse;")
            lines.append("};")

            lines.append("")

            lines.append(f"export type {schema.name}UpdateMutationResponse = {{")
            lines.append(f"  {schema.name}Update: {schema.name}UpdateResponse;")
            lines.append("};")

            lines.append("")

            lines.append(f"export type {schema.name}DeleteMutationResponse = {{")
            lines.append(f"  {schema.name}Delete: {schema.name}DeleteResponse;")
            lines.append("};")

            lines.append("")

            lines.append(f"export type {schema.name}DisableMutationResponse = {{")
            lines.append(f"  {schema.name}Disable: {schema.name}DisableResponse;")
            lines.append("};")

            lines.append("")

            # Get query response
            lines.append(f"export type {schema.name}GetQueryResponse = {{")
            lines.append(f"  {schema.name}Get: {schema.name}GetResponse;")
            lines.append("};")

            lines.append("")

            # Generate ListBy* response types from schema.operations (Issue #84 fix)
            # This ensures deduplication when multiple GSIs share the same partition key
            generated_list_responses: set[str] = set()

            if hasattr(schema, "operations") and schema.operations:
                for op in schema.operations:
                    # Only generate for ListBy* operations (queries)
                    if op.name.startswith("ListBy") and op.index_partition:
                        idx_pascal = to_pascal_case(op.index_partition)
                        response_name = f"{schema.name}ListBy{idx_pascal}Response"

                        # Skip if already generated (deduplication)
                        if response_name in generated_list_responses:
                            continue
                        generated_list_responses.add(response_name)

                        lines.append(f"export type {response_name} = {{")
                        lines.append(
                            f"  {schema.name}ListBy{idx_pascal}: {schema.name}ListResponse;"
                        )
                        lines.append("};")
                        lines.append("")
            else:
                # Fallback for schemas without operations (backward compatibility)
                pk_pascal = to_pascal_case(schema.partition_key)
                lines.append(f"export type {schema.name}ListBy{pk_pascal}Response = {{")
                lines.append(f"  {schema.name}ListBy{pk_pascal}: {schema.name}ListResponse;")
                lines.append("};")

                # List responses for secondary indexes (fallback without deduplication)
                if schema.secondary_indexes:
                    for index in schema.secondary_indexes:
                        index_partition = index.get("partition")
                        if index_partition:
                            idx_pascal = to_pascal_case(index_partition)
                            lines.append("")
                            lines.append(
                                f"export type {schema.name}ListBy{idx_pascal}Response = {{"
                            )
                            lines.append(
                                f"  {schema.name}ListBy{idx_pascal}: {schema.name}ListResponse;"
                            )
                            lines.append("};")

        return "\n".join(lines)

    def _generate_interface(self, schema: Any) -> str:
        """
        Generate TypeScript interface with proper optional syntax.

        Args:
            schema: Schema object

        Returns:
            Interface definition
        """
        lines = []
        lines.append(f"export interface I{schema.name} {{")

        for attr in schema.attributes:
            ts_type = self._typescript_type(attr)
            # Use proper TypeScript optional syntax
            optional_marker = "?" if not attr.required else ""
            lines.append(f"  {attr.name}{optional_marker}: {ts_type};")

        lines.append("}")

        return "\n".join(lines)

    def _generate_class(self, schema: Any) -> str:
        """
        Generate TypeScript class with proper constructor initialization.

        Args:
            schema: Schema object

        Returns:
            Class definition
        """
        lines = []
        lines.append(f"export class {schema.name} implements I{schema.name} {{")

        # Field declarations without default values (will be set in constructor)
        for attr in schema.attributes:
            ts_type = self._typescript_type(attr)
            optional_marker = "?" if not attr.required else ""
            lines.append(f"  {attr.name}{optional_marker}: {ts_type};")

        lines.append("")
        lines.append(f"  constructor(data: Partial<I{schema.name}> = {{}}) {{")

        # Initialize each field with proper default values or from data
        for attr in schema.attributes:
            ts_type = self._typescript_type(attr)
            default_value = self._get_default_value(attr, ts_type)

            if attr.enum_type:
                # Special handling for enums
                lines.append(f"    this.{attr.name} = data.{attr.name} ?? {default_value};")
            elif attr.required:
                # Required fields get default values if not provided
                lines.append(f"    this.{attr.name} = data.{attr.name} ?? {default_value};")
            else:
                # Optional fields can be undefined
                lines.append(f"    this.{attr.name} = data.{attr.name};")

        lines.append("  }")
        lines.append("}")

        return "\n".join(lines)

    def _get_default_value(self, attr: Attribute, ts_type: str) -> str:
        """
        Get proper default value for TypeScript field.

        Handles schema-defined defaults (Issue #43).

        Args:
            attr: Attribute definition
            ts_type: TypeScript type string

        Returns:
            Default value string
        """
        if attr.enum_type:
            # Use first enum value or Unknown (PascalCase for TypeScript enums)
            # Issue #62: TypeScript enum members use PascalCase, not SCREAMING_CASE
            if hasattr(attr, "enum_values") and attr.enum_values and len(attr.enum_values) > 0:
                # Convert enum value to PascalCase to match generated enum member names
                return f"{attr.enum_type}.{to_typescript_enum_member(attr.enum_values[0])}"
            return f"{attr.enum_type}.Unknown"

        # Issue #43: Use schema-defined default if present
        if attr.default is not None:
            if isinstance(attr.default, str):
                return f"'{attr.default}'"
            elif isinstance(attr.default, bool):
                # TypeScript booleans are lowercase
                return str(attr.default).lower()
            else:
                # Numbers and other types
                return str(attr.default)

        # For optional fields, return undefined
        if not attr.required:
            return "undefined"

        # Provide sensible defaults based on TypeScript type for required fields
        if ts_type == "string":
            return "''"
        elif ts_type == "number":
            return "0"
        elif ts_type == "boolean":
            return "false"
        elif ts_type == "Date":
            return "new Date()"
        elif ts_type.endswith("[]"):
            return "[]"
        elif ts_type.startswith("Record<"):
            return "{}"
        elif ts_type.startswith("Set<"):
            return "new Set()"
        else:
            # For unknown types, use string default
            return "''"

    def _typescript_type(self, attr: Attribute) -> str:
        """
        Convert schema type to TypeScript type using enhanced type mapping.

        Priority:
        1. enum_type - Enum reference
        2. object_ref - Nested model reference
        3. items_ref - Array of model references
        4. model_reference - Direct model type
        5. Standard type mapping

        Args:
            attr: Attribute definition

        Returns:
            TypeScript type string
        """
        if attr.enum_type:
            return attr.enum_type

        # Check for object_ref (nested model)
        if attr.object_ref:
            return attr.object_ref

        # Check for array with items_ref
        if attr.type == "array" and attr.items_ref:
            return f"{attr.items_ref}[]"

        # Check for direct model reference
        if hasattr(attr, "model_reference") and attr.model_reference:
            return attr.model_reference

        try:
            mapping = self.type_mapper.get_type_mapping(attr.type)
            return mapping.typescript_type
        except ValueError:
            # Fallback for unknown types
            logger.warning(
                f"Unknown type '{attr.type}' for attribute '{attr.name}', defaulting to string"
            )
            return "string"

    # =========================================================================
    # GRAPHQL QUERY DEFINITION FILE GENERATION (Issue #61)
    # =========================================================================

    def _has_operations(self, schema: Any) -> bool:
        """
        Check if a schema has operations defined.

        Args:
            schema: Schema object

        Returns:
            True if schema has non-empty operations list or is a LambdaType, False otherwise
        """
        # Issue #63: Lambda types always have an operation
        if isinstance(schema, LambdaType):
            return True
        if not hasattr(schema, "operations"):
            return False
        if schema.operations is None:
            return False
        return len(schema.operations) > 0

    def _generate_gql_attribute_fields(
        self,
        schema: Any,
        indent: int = 6,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL field selection for schema attributes.

        Handles nested objects by expanding their fields when object_ref is present.

        Args:
            schema: Schema object with attributes
            indent: Number of spaces for indentation
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Field selection string with proper indentation
        """
        lines = []
        prefix = " " * indent

        for attr in schema.attributes:
            if attr.object_ref and all_schemas:
                # Nested object - expand its fields
                nested_schema = all_schemas.get(attr.object_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    # Recursively generate nested fields (one level deep to avoid infinite recursion)
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    # Nested type not found, just include the field name
                    lines.append(f"{prefix}{attr.name}")
            elif attr.items_ref and all_schemas:
                # Array of nested objects - expand their fields
                nested_schema = all_schemas.get(attr.items_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    lines.append(f"{prefix}{attr.name}")
            else:
                lines.append(f"{prefix}{attr.name}")

        return "\n".join(lines)

    def _generate_gql_response_fields(
        self,
        schema: Any,
        operation: Any = None,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL response field selection for an operation.

        Issue #79: Updated to match v0.19.0 response format:
        - All responses include envelope: code, success, message
        - Mutations/Get: singular `item` field
        - List: plural `items` field + nextToken

        Args:
            schema: Schema object
            operation: Operation object (required for TableSchema to determine response type)
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Response field selection string
        """
        from ..core.models import classify_operation_response_type

        if isinstance(schema, TableSchema):
            # Determine response type based on operation
            if operation is not None:
                response_type = classify_operation_response_type(operation)
            else:
                # Fallback for backward compatibility
                response_type = "list"

            # Generate attribute fields
            attr_fields = self._generate_gql_attribute_fields(
                schema, indent=8, all_schemas=all_schemas
            )

            # Envelope fields (always present per v0.19.0)
            envelope = """      code
      success
      message"""

            if response_type == "singular":
                # Mutations and Get operations use singular `item`
                return f"""{envelope}
      item {{
{attr_fields}
      }}"""
            else:
                # List operations use plural `items` + nextToken
                return f"""{envelope}
      items {{
{attr_fields}
      }}
      nextToken"""
        else:
            # LambdaType or StandardType returns direct fields (no envelope)
            return self._generate_gql_attribute_fields(schema, indent=6, all_schemas=all_schemas)

    def _generate_gql_operation_export(
        self,
        schema: Any,
        operation: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a single GraphQL operation export constant.

        Args:
            schema: Schema object the operation belongs to
            operation: Operation object with name, type, field
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Export constant string with GraphQL operation
        """
        op_type = "query" if operation.type == "Query" else "mutation"
        response_fields = self._generate_gql_response_fields(schema, operation, all_schemas)

        return f"""export const {operation.field} = /* GraphQL */ `
  {op_type} {operation.field}($input: {operation.field}Input!) {{
    {operation.field}(input: $input) {{
{response_fields}
    }}
  }}
`;"""

    def _generate_gql_query_file(
        self,
        schema: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a complete GraphQL query definition file for an entity.

        Args:
            schema: Schema object with operations or LambdaType
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Complete TypeScript file content with GraphQL operation exports
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("typescript").rstrip())
        lines.append("/**")
        lines.append(f" * GraphQL operations for {schema.name}")
        lines.append(" */")
        lines.append("")

        # Issue #63: Handle LambdaType schemas
        if isinstance(schema, LambdaType):
            lines.append(self._generate_lambda_gql_operation_export(schema, all_schemas))
            lines.append("")
        else:
            # Generate export for each operation (TableSchema)
            for operation in schema.operations:
                lines.append(self._generate_gql_operation_export(schema, operation, all_schemas))
                lines.append("")

        return "\n".join(lines)

    def _generate_lambda_gql_operation_export(
        self,
        schema: LambdaType,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a GraphQL operation export constant for a Lambda type.

        Args:
            schema: LambdaType schema object
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Export constant string with GraphQL operation
        """
        op_type = "query" if schema.operation == "query" else "mutation"
        op_name = schema.name

        # Generate field selection for Lambda response
        fields = self._generate_gql_attribute_fields(schema, indent=6, all_schemas=all_schemas)

        return f"""export const {op_name} = /* GraphQL */ `
  {op_type} {op_name}($input: {op_name}Input!) {{
    {op_name}(input: $input) {{
{fields}
    }}
  }}
`;"""

    def _generate_graphql_queries(
        self,
        schemas: Dict[str, Any],
        output_config,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Generate TypeScript GraphQL query definition files for all schemas with operations.

        Args:
            schemas: Dictionary of schema objects for this target
            output_config: OutputConfig for this target
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Number of query files generated
        """
        # Skip if graphql_queries_subdir not configured
        if not output_config.graphql_queries_subdir:
            return 0

        generated_files = []

        for name, schema in schemas.items():
            if self._has_operations(schema):
                content = self._generate_gql_query_file(schema, all_schemas or schemas)
                filename = f"{schema.name}.graphql.ts"
                output_path = output_config.graphql_queries_path(filename)
                if output_path:
                    self._write_file(output_path, content)
                    generated_files.append(schema.name)

        # Generate barrel file if any files were generated
        if generated_files:
            barrel_content = self._generate_gql_queries_barrel(generated_files)
            barrel_path = output_config.graphql_queries_path("index.ts")
            if barrel_path:
                self._write_file(barrel_path, barrel_content)

        return len(generated_files)

    def _generate_gql_queries_barrel(self, entity_names: list) -> str:
        """
        Generate barrel file (index.ts) re-exporting all GraphQL query files.

        Args:
            entity_names: List of entity names that have query files

        Returns:
            Complete barrel file content
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("typescript").rstrip())
        lines.append("/**")
        lines.append(" * GraphQL operations barrel file")
        lines.append(" * Re-exports all GraphQL query definitions for convenient imports")
        lines.append(" */")
        lines.append("")

        # Export all entity files
        for name in sorted(entity_names):
            lines.append(f"export * from './{name}.graphql';")

        return "\n".join(lines)

    # =========================================================================
    # GRAPHQL UTILITY FILE GENERATION (Issue #71)
    # =========================================================================

    def _generate_graphql_utils(self) -> str:
        """
        Generate GraphQL utility file with timestamp conversion functions.

        AWSTimestamp is a Unix timestamp in seconds, but TypeScript uses Date objects.
        This utility provides functions to convert between the two formats.

        Returns:
            Complete TypeScript utility file content
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("typescript").rstrip())
        lines.append("/**")
        lines.append(" * GraphQL utilities for AWSTimestamp conversion.")
        lines.append(" *")
        lines.append(
            " * AWSTimestamp is a Unix timestamp in seconds, but TypeScript uses Date objects."
        )
        lines.append(" * Use toGraphQLInput() before sending data to GraphQL mutations.")
        lines.append(
            " * Use fromGraphQLTimestamp() when receiving AWSTimestamp from GraphQL responses."
        )
        lines.append(" */")
        lines.append("")

        # toGraphQLInput function
        lines.append("/**")
        lines.append(
            " * Convert Date fields to Unix timestamps for GraphQL AWSTimestamp compatibility."
        )
        lines.append(" * Recursively handles nested objects and arrays.")
        lines.append(" *")
        lines.append(" * @param input - Object with potential Date fields")
        lines.append(" * @returns Object with Date fields converted to Unix epoch seconds")
        lines.append(" *")
        lines.append(" * @example")
        lines.append(" * const input = toGraphQLInput({")
        lines.append(" *   name: 'John',")
        lines.append(" *   createdAt: new Date(),")
        lines.append(" *   metadata: { updatedAt: new Date() }")
        lines.append(" * });")
        lines.append(
            " * // Result: { name: 'John', createdAt: 1705500000, metadata: { updatedAt: 1705500000 } }"
        )
        lines.append(" */")
        lines.append(
            "export function toGraphQLInput<T extends Record<string, unknown>>(input: T): T {"
        )
        lines.append("  const result: Record<string, unknown> = {};")
        lines.append("")
        lines.append("  for (const [key, value] of Object.entries(input)) {")
        lines.append("    if (value instanceof Date) {")
        lines.append("      result[key] = Math.floor(value.getTime() / 1000);")
        lines.append("    } else if (Array.isArray(value)) {")
        lines.append("      result[key] = value.map((item) =>")
        lines.append("        item instanceof Date")
        lines.append("          ? Math.floor(item.getTime() / 1000)")
        lines.append("          : typeof item === 'object' && item !== null")
        lines.append("            ? toGraphQLInput(item as Record<string, unknown>)")
        lines.append("            : item")
        lines.append("      );")
        lines.append("    } else if (typeof value === 'object' && value !== null) {")
        lines.append("      result[key] = toGraphQLInput(value as Record<string, unknown>);")
        lines.append("    } else {")
        lines.append("      result[key] = value;")
        lines.append("    }")
        lines.append("  }")
        lines.append("")
        lines.append("  return result as T;")
        lines.append("}")
        lines.append("")

        # fromGraphQLTimestamp function
        lines.append("/**")
        lines.append(" * Convert Unix timestamp from GraphQL AWSTimestamp to JavaScript Date.")
        lines.append(" *")
        lines.append(" * @param timestamp - Unix timestamp in seconds (from GraphQL AWSTimestamp)")
        lines.append(" * @returns JavaScript Date object, or null if input is null/undefined")
        lines.append(" *")
        lines.append(" * @example")
        lines.append(" * const date = fromGraphQLTimestamp(1705500000);")
        lines.append(" * // Result: Date object representing 2024-01-17T...")
        lines.append(" */")
        lines.append(
            "export function fromGraphQLTimestamp(timestamp: number | null | undefined): Date | null {"
        )
        lines.append("  if (timestamp == null) {")
        lines.append("    return null;")
        lines.append("  }")
        lines.append("  return new Date(timestamp * 1000);")
        lines.append("}")

        return "\n".join(lines)
