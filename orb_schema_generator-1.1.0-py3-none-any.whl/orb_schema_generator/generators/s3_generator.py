"""S3 storage generator.

Generates S3 bucket CDK constructs, Lambda handlers, and related infrastructure
from S3 schema definitions.
"""

from pathlib import Path
from typing import Dict, Any
import logging

from .base import BaseGenerator
from ..core.models import S3Schema
from ..core.config import S3TargetConfig
from ..utils.case_conversion import to_pascal_case, to_snake_case
from ..utils.console import success

logger = logging.getLogger(__name__)


class S3Generator(BaseGenerator):
    """Generates S3 storage infrastructure from schemas."""

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate S3 infrastructure for all S3 schemas.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info("Generating S3 storage infrastructure...")

        s3_count = 0
        for name, schema in schemas.items():
            if isinstance(schema, S3Schema):
                # Get the target configuration
                target = self.config.get_s3_target(schema.target)
                if target is None:
                    logger.warning(
                        f"S3 schema '{name}' references unknown target '{schema.target}'. "
                        f"Available targets: {list(self.config.get_all_s3_targets().keys())}"
                    )
                    continue

                # Generate CDK construct
                construct_content = self._generate_storage_construct(schema, target)
                file_name = to_snake_case(name) + "_storage.py"
                output_path = Path(self.config.cdk_output_dir) / "storage" / file_name
                self._write_file(output_path, construct_content)

                # Generate Lambda handler
                handler_content = self._generate_lambda_handler(schema, target)
                handler_dir = (
                    Path(self.config.cdk_output_dir) / "storage" / "lambdas" / to_snake_case(name)
                )
                handler_path = handler_dir / "handler.py"
                self._write_file(handler_path, handler_content)

                s3_count += 1

        if s3_count > 0:
            # Generate storage __init__.py
            init_content = self._generate_storage_init(schemas)
            init_path = Path(self.config.cdk_output_dir) / "storage" / "__init__.py"
            self._write_file(init_path, init_content)

            logger.info(success(f"Generated {s3_count} S3 storage constructs"))

    def _get_resource_name(self, resource_type: str, name: str) -> str:
        """Generate resource name using config values."""
        return f"{self.config.customer_id}-{self.config.project_id}-{self.config.environment}-{resource_type}-{name}"

    def _generate_storage_construct(self, schema: S3Schema, target: S3TargetConfig) -> str:
        """
        Generate S3 storage CDK construct.

        Args:
            schema: S3 schema definition
            target: S3 target configuration

        Returns:
            Python CDK construct code
        """
        class_name = to_pascal_case(schema.name) + "Storage"
        bucket_name = self._get_resource_name("s3", schema.bucket.name_suffix)
        lambda_name = self._get_resource_name("lambda", f"{schema.bucket.name_suffix}-handler")

        # Determine versioning
        versioning = schema.bucket.versioning
        if versioning is None and target.defaults:
            versioning = target.defaults.versioning
        versioning = versioning or False

        # Determine encryption
        encryption = schema.bucket.encryption
        if encryption is None and target.defaults:
            encryption = target.defaults.encryption
        encryption = encryption or "AES256"

        # Build full access pattern
        full_pattern = f"{target.base_path_pattern}/{schema.access.path_suffix}".replace("//", "/")

        # Generate lifecycle rules
        lifecycle_code = self._generate_lifecycle_rules(schema)

        # Generate CORS configuration
        cors_code = self._generate_cors_config(schema)

        content = f'''{self._get_file_header("python")}

from aws_cdk import (
    aws_s3 as s3,
    aws_lambda as lambda_,
    aws_ssm as ssm,
    Duration,
    RemovalPolicy,
)
from constructs import Construct


class {class_name}(Construct):
    """{schema.description or f"S3 storage construct for {schema.name}."}"""

    def __init__(self, scope: Construct, id: str) -> None:
        super().__init__(scope, id)

        # S3 Bucket
        self.bucket = s3.Bucket(
            self, "Bucket",
            bucket_name="{bucket_name}",
            versioned={versioning},
            encryption=s3.BucketEncryption.{"S3_MANAGED" if encryption == "AES256" else "KMS_MANAGED"},
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,{cors_code}
        )
{lifecycle_code}
        # Lambda for S3 operations
        self.handler = lambda_.Function(
            self, "Handler",
            function_name="{lambda_name}",
            runtime=lambda_.Runtime.PYTHON_3_12,
            handler="handler.lambda_handler",
            code=lambda_.Code.from_asset("infrastructure/cdk/storage/lambdas/{to_snake_case(schema.name)}"),
            memory_size=256,
            timeout=Duration.seconds(30),
            environment={{
                "BUCKET_NAME": self.bucket.bucket_name,
                "USER_ID_SOURCE": "{target.user_id_source}",
                "ACCESS_PATTERN": "{full_pattern}",
            }},
        )

        # Grant Lambda access to bucket
        self.bucket.grant_read_write(self.handler)

        # SSM Parameters
        ssm.StringParameter(
            self, "BucketNameParam",
            parameter_name="/{self.config.customer_id}/{self.config.project_id}/{self.config.environment}/s3/{schema.bucket.name_suffix}/bucket-name",
            string_value=self.bucket.bucket_name,
        )

        ssm.StringParameter(
            self, "BucketArnParam",
            parameter_name="/{self.config.customer_id}/{self.config.project_id}/{self.config.environment}/s3/{schema.bucket.name_suffix}/bucket-arn",
            string_value=self.bucket.bucket_arn,
        )

        ssm.StringParameter(
            self, "LambdaArnParam",
            parameter_name="/{self.config.customer_id}/{self.config.project_id}/{self.config.environment}/s3/{schema.bucket.name_suffix}/lambda-arn",
            string_value=self.handler.function_arn,
        )
'''
        return content

    def _generate_lifecycle_rules(self, schema: S3Schema) -> str:
        """Generate lifecycle rule code for bucket."""
        if not schema.bucket.lifecycle:
            return ""

        rules = []
        for rule in schema.bucket.lifecycle:
            if rule.expiration_days:
                rules.append(
                    f"""
        self.bucket.add_lifecycle_rule(
            prefix="{rule.prefix}",
            expiration=Duration.days({rule.expiration_days}),
        )"""
                )
            if rule.transition_to_ia_days:
                rules.append(
                    f"""
        self.bucket.add_lifecycle_rule(
            prefix="{rule.prefix}",
            transitions=[
                s3.Transition(
                    storage_class=s3.StorageClass.INFREQUENT_ACCESS,
                    transition_after=Duration.days({rule.transition_to_ia_days}),
                ),
            ],
        )"""
                )
            if rule.transition_to_glacier_days:
                rules.append(
                    f"""
        self.bucket.add_lifecycle_rule(
            prefix="{rule.prefix}",
            transitions=[
                s3.Transition(
                    storage_class=s3.StorageClass.GLACIER,
                    transition_after=Duration.days({rule.transition_to_glacier_days}),
                ),
            ],
        )"""
                )

        return "\n".join(rules)

    def _generate_cors_config(self, schema: S3Schema) -> str:
        """Generate CORS configuration code."""
        if not schema.bucket.cors:
            return ""

        cors = schema.bucket.cors
        origins = ", ".join(f'"{o}"' for o in cors.allowed_origins)
        methods = ", ".join(f"s3.HttpMethods.{m}" for m in cors.allowed_methods)
        headers = ", ".join(f'"{h}"' for h in cors.allowed_headers)

        return f"""
            cors=[
                s3.CorsRule(
                    allowed_origins=[{origins}],
                    allowed_methods=[{methods}],
                    allowed_headers=[{headers}],
                    max_age={cors.max_age_seconds},
                )
            ],"""

    def _generate_lambda_handler(self, schema: S3Schema, target: S3TargetConfig) -> str:
        """
        Generate Lambda handler code for S3 operations.

        Args:
            schema: S3 schema definition
            target: S3 target configuration

        Returns:
            Python Lambda handler code
        """
        # Build operation handlers
        handlers = []
        handler_map = []

        if "GetUploadUrl" in schema.operations:
            handlers.append(self._get_upload_url_handler())
            handler_map.append(f'        "{schema.name}GetUploadUrl": _handle_get_upload_url,')

        if "GetDownloadUrl" in schema.operations:
            handlers.append(self._get_download_url_handler())
            handler_map.append(f'        "{schema.name}GetDownloadUrl": _handle_get_download_url,')

        if "ListFiles" in schema.operations:
            handlers.append(self._get_list_files_handler())
            handler_map.append(f'        "{schema.name}ListFiles": _handle_list_files,')

        if "DeleteFile" in schema.operations:
            handlers.append(self._get_delete_file_handler())
            handler_map.append(f'        "{schema.name}DeleteFile": _handle_delete_file,')

        handler_map_str = "\n".join(handler_map)
        handlers_str = "\n\n".join(handlers)

        content = f'''{self._get_file_header("python")}

import os
import json
import boto3
from datetime import datetime, timedelta
from typing import Any, Dict

s3_client = boto3.client("s3")

BUCKET_NAME = os.environ["BUCKET_NAME"]
USER_ID_SOURCE = os.environ["USER_ID_SOURCE"]
ACCESS_PATTERN = os.environ["ACCESS_PATTERN"]


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Handle S3 storage operations."""
    operation = event["info"]["fieldName"]
    identity = event["identity"]
    args = event["arguments"]["input"]

    # Extract user ID from identity
    user_id = _extract_user_id(identity)

    # Route to appropriate handler
    handlers = {{
{handler_map_str}
    }}

    handler = handlers.get(operation)
    if not handler:
        raise ValueError(f"Unknown operation: {{operation}}")

    return handler(user_id, args)


def _extract_user_id(identity: Dict[str, Any]) -> str:
    """Extract user ID from identity based on configured source."""
    parts = USER_ID_SOURCE.split(".")
    value = identity
    for part in parts:
        value = value.get(part)
        if value is None:
            raise ValueError(f"Could not extract user ID from {{USER_ID_SOURCE}}")
    return value


def _build_s3_key(user_id: str, resource_type: str, resource_id: str, file_name: str) -> str:
    """Build S3 key from access pattern and parameters."""
    key = ACCESS_PATTERN.replace("{{userId}}", user_id)
    key = key.replace("{{resourceType}}", resource_type)
    key = key.replace("{{resourceId}}", resource_id)
    key = key.rstrip("/*")
    return f"{{key}}/{{file_name}}"


{handlers_str}
'''
        return content

    def _get_upload_url_handler(self) -> str:
        """Generate GetUploadUrl handler code."""
        return '''def _handle_get_upload_url(user_id: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate pre-signed URL for upload."""
    key = _build_s3_key(
        user_id,
        args.get("resourceType", "default"),
        args["resourceId"],
        args["fileName"],
    )
    expires_in = args.get("expiresIn", 3600)

    url = s3_client.generate_presigned_url(
        "put_object",
        Params={
            "Bucket": BUCKET_NAME,
            "Key": key,
            "ContentType": args["contentType"],
        },
        ExpiresIn=expires_in,
    )

    expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

    return {
        "url": url,
        "key": key,
        "expiresAt": expires_at.isoformat() + "Z",
    }'''

    def _get_download_url_handler(self) -> str:
        """Generate GetDownloadUrl handler code."""
        return '''def _handle_get_download_url(user_id: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate pre-signed URL for download."""
    key = _build_s3_key(
        user_id,
        args.get("resourceType", "default"),
        args["resourceId"],
        args["fileName"],
    )
    expires_in = args.get("expiresIn", 3600)

    url = s3_client.generate_presigned_url(
        "get_object",
        Params={
            "Bucket": BUCKET_NAME,
            "Key": key,
        },
        ExpiresIn=expires_in,
    )

    expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

    return {
        "url": url,
        "key": key,
        "expiresAt": expires_at.isoformat() + "Z",
    }'''

    def _get_list_files_handler(self) -> str:
        """Generate ListFiles handler code."""
        return '''def _handle_list_files(user_id: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """List files for a resource."""
    prefix = _build_s3_key(
        user_id,
        args.get("resourceType", "default"),
        args["resourceId"],
        args.get("prefix", ""),
    )

    params = {
        "Bucket": BUCKET_NAME,
        "Prefix": prefix,
        "MaxKeys": args.get("maxKeys", 100),
    }

    if args.get("continuationToken"):
        params["ContinuationToken"] = args["continuationToken"]

    response = s3_client.list_objects_v2(**params)

    files = [
        {
            "key": obj["Key"],
            "size": obj["Size"],
            "lastModified": obj["LastModified"].isoformat() + "Z",
            "etag": obj.get("ETag", "").strip('"'),
        }
        for obj in response.get("Contents", [])
    ]

    return {
        "files": files,
        "continuationToken": response.get("NextContinuationToken"),
        "isTruncated": response.get("IsTruncated", False),
    }'''

    def _get_delete_file_handler(self) -> str:
        """Generate DeleteFile handler code."""
        return '''def _handle_delete_file(user_id: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a file."""
    key = _build_s3_key(
        user_id,
        args.get("resourceType", "default"),
        args["resourceId"],
        args["fileName"],
    )

    s3_client.delete_object(Bucket=BUCKET_NAME, Key=key)

    return {
        "success": True,
        "key": key,
    }'''

    def _generate_storage_init(self, schemas: Dict[str, Any]) -> str:
        """Generate __init__.py for storage module."""
        imports = []
        exports = []

        for name, schema in schemas.items():
            if isinstance(schema, S3Schema):
                class_name = to_pascal_case(name) + "Storage"
                file_name = to_snake_case(name) + "_storage"
                imports.append(f"from .{file_name} import {class_name}")
                exports.append(f'    "{class_name}",')

        imports_str = "\n".join(imports)
        exports_str = "\n".join(exports)

        return f"""{self._get_file_header("python")}
{imports_str}

__all__ = [
{exports_str}
]
"""
