"""GraphQL schema generator."""

from typing import Dict, Any, Set, List, TYPE_CHECKING
import logging

from .base import BaseGenerator
from ..core.models import (
    TableSchema,
    StandardType,
    LambdaType,
    RegistryType,
    Attribute,
    Operation,
    S3Schema,
    get_auth_directives_from_config,
)
from ..utils.type_mapping import to_graphql_type, EnhancedTypeMapper
from ..utils.case_conversion import to_graphql_enum_member
from ..utils.console import success
from ..utils.glob_matcher import matches_any_pattern

if TYPE_CHECKING:
    from ..core.config import GeneratorConfig, ApiDefinition

logger = logging.getLogger(__name__)

# Global type mapper instance for scalar collection
_type_mapper = EnhancedTypeMapper()

# AppSync directive definitions for schema validation
APPSYNC_DIRECTIVES = """# AppSync Directives
directive @aws_auth(cognito_groups: [String!]!) on FIELD_DEFINITION
directive @aws_cognito_user_pools(cognito_groups: [String!]) on FIELD_DEFINITION
directive @aws_api_key on FIELD_DEFINITION
directive @aws_iam on FIELD_DEFINITION
"""


class GraphQLGenerator(BaseGenerator):
    """Generates GraphQL schema from schemas."""

    def __init__(self, config: "GeneratorConfig") -> None:
        """
        Initialize GraphQL generator with configuration.

        Args:
            config: Generator configuration
        """
        super().__init__(config)
        self._generated_types: Set[str] = set()

    def _clear_registry(self) -> None:
        """Clear the type registry at the start of generation."""
        self._generated_types.clear()

    def _register_type(self, type_name: str) -> bool:
        """
        Register a type name and check for duplicates.

        Args:
            type_name: The GraphQL type name to register

        Returns:
            True if type was registered (not a duplicate)
            False if type was already registered (duplicate)
        """
        if type_name in self._generated_types:
            logger.warning(f"Duplicate type detected: {type_name}")
            return False
        self._generated_types.add(type_name)
        return True

    # =========================================================================
    # MULTI-API FILTERING METHODS (Issue #83)
    # =========================================================================

    def _filter_schemas_by_tables(
        self, schemas: Dict[str, Any], table_names: List[str]
    ) -> Dict[str, Any]:
        """Filter schemas to only those in the specified table list.

        Args:
            schemas: Dictionary of all schema objects
            table_names: List of table/schema names to include

        Returns:
            Dictionary containing only schemas whose names are in table_names
        """
        return {name: schema for name, schema in schemas.items() if name in table_names}

    def _filter_operations_by_patterns(
        self, operations: List[Operation], patterns: List[str]
    ) -> List[Operation]:
        """Filter operations to only those matching include patterns.

        Args:
            operations: List of Operation objects
            patterns: List of glob patterns to match against operation field names

        Returns:
            List of operations whose field names match at least one pattern
        """
        if not patterns:
            return []
        return [op for op in operations if matches_any_pattern(op.field, patterns)]

    def _should_include_lambda_operation(self, schema: LambdaType, patterns: List[str]) -> bool:
        """Check if a Lambda schema's operation should be included.

        Lambda schemas use their name as the operation field name.

        Args:
            schema: LambdaType schema
            patterns: List of glob patterns to match

        Returns:
            True if the Lambda operation matches at least one pattern
        """
        if not patterns:
            return False
        return matches_any_pattern(schema.name, patterns)

    def _collect_required_scalars(self, schemas: Dict[str, Any]) -> Set[str]:
        """
        Collect all required custom scalar definitions from schemas.

        Note: AWS AppSync built-in scalars (AWSDateTime, AWSDate, AWSTime,
        AWSTimestamp, AWSEmail, AWSJSON, AWSURL, AWSPhone, AWSIPAddress)
        do NOT require scalar definitions - they are built-in.

        This method only collects truly custom scalars that need explicit
        definition in the schema.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Set of scalar definition strings (empty for AppSync built-in types)
        """
        scalars: Set[str] = set()

        for name, schema in schemas.items():
            if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                for attr in schema.attributes:
                    # Skip enum types and references
                    if attr.enum_type or attr.object_ref or attr.items_ref:
                        continue

                    try:
                        mapping = _type_mapper.get_type_mapping(attr.type)
                        # Only add if there's a custom scalar definition needed
                        # (AppSync built-in scalars don't need definitions)
                        if mapping.graphql_scalar_def:
                            scalars.add(mapping.graphql_scalar_def)
                    except ValueError:
                        # Unknown type, skip scalar collection
                        pass

        return scalars

    def _collect_nested_types(self, schemas: Dict[str, Any]) -> Set[str]:
        """
        Collect all nested type names referenced via object_ref or items_ref.

        These types need Input variants generated for use in input types.
        Handles recursive nested types by scanning all schema types.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Set of type names that need Input variants (e.g., {"GPSPoint", "AreaMeasurement"})
        """
        nested_types: Set[str] = set()

        for name, schema in schemas.items():
            if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                for attr in schema.attributes:
                    if attr.object_ref:
                        nested_types.add(attr.object_ref)
                    if attr.items_ref:
                        nested_types.add(attr.items_ref)

        return nested_types

    def _collect_referenced_schemas(
        self, target_schemas: Dict[str, Any], all_schemas: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Collect schemas referenced by target schemas from other targets.

        When a schema in the target references types via object_ref or items_ref,
        those referenced types must be included in the GraphQL schema even if
        they belong to a different target (e.g., package types referenced by api types).

        This method recursively collects all referenced schemas to handle
        nested references (e.g., A -> B -> C).

        Args:
            target_schemas: Schemas belonging to the current target
            all_schemas: All schemas from all targets

        Returns:
            Dictionary of referenced schemas not already in target_schemas
        """
        referenced: Dict[str, Any] = {}
        to_process: Set[str] = set()

        # Collect initial references from target schemas
        for name, schema in target_schemas.items():
            if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                for attr in schema.attributes:
                    if attr.object_ref and attr.object_ref not in target_schemas:
                        to_process.add(attr.object_ref)
                    if attr.items_ref and attr.items_ref not in target_schemas:
                        to_process.add(attr.items_ref)

        # Recursively collect referenced schemas and their dependencies
        processed: Set[str] = set()
        while to_process:
            ref_name = to_process.pop()
            if ref_name in processed or ref_name in target_schemas:
                continue
            processed.add(ref_name)

            # Find the referenced schema in all_schemas
            if ref_name in all_schemas:
                ref_schema = all_schemas[ref_name]
                referenced[ref_name] = ref_schema

                # Check for nested references in the referenced schema
                if isinstance(ref_schema, (TableSchema, StandardType, LambdaType)):
                    for attr in ref_schema.attributes:
                        if attr.object_ref and attr.object_ref not in processed:
                            to_process.add(attr.object_ref)
                        if attr.items_ref and attr.items_ref not in processed:
                            to_process.add(attr.items_ref)
            else:
                logger.warning(f"Referenced type '{ref_name}' not found in schemas")

        return referenced

    def _generate_nested_input_types(self, schemas: Dict[str, Any], nested_types: Set[str]) -> str:
        """
        Generate input type variants for nested types.

        For each type in nested_types, generates a corresponding {TypeName}Input
        with the same fields. Uses for_input=True for recursive nested types.

        Args:
            schemas: Dictionary of schema objects
            nested_types: Set of type names that need Input variants

        Returns:
            Input type definitions (e.g., "input GPSPointInput { ... }")
        """
        if not nested_types:
            return ""

        lines = ["# Nested Input Types"]

        for name, schema in schemas.items():
            if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                if schema.name in nested_types:
                    input_type_name = f"{schema.name}Input"

                    # Check registry before generating - skip duplicates
                    if not self._register_type(input_type_name):
                        continue

                    lines.append("")
                    lines.append(f"input {input_type_name} {{")

                    for attr in schema.attributes:
                        # Use for_input=True to get Input variants for nested types
                        gql_type = self._graphql_type(attr, for_input=True)
                        lines.append(f"  {attr.name}: {gql_type}")

                    lines.append("}")

        return "\n".join(lines)

    def _generate_scalars(self, schemas: Dict[str, Any]) -> str:
        """
        Generate custom scalar definitions.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Scalar definitions section or empty string if none needed
        """
        scalars = self._collect_required_scalars(schemas)

        if not scalars:
            return ""

        lines = ["# Custom Scalars"]
        for scalar in sorted(scalars):
            lines.append(scalar)

        return "\n".join(lines)

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate GraphQL schema from all schemas.

        Handles all schema types in a unified manner:
        - RegistryType → GraphQL enum
        - StandardType, TableSchema, LambdaType → GraphQL types, inputs, queries, mutations

        Uses target-based routing to write files to the correct output directories.
        For GraphQL, schemas are grouped by target and a separate schema.graphql
        is generated for each target.

        Cross-target references (Issue #49): When schemas reference types from other
        targets via object_ref or items_ref, those referenced types are automatically
        included in the generated schema.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info("Generating GraphQL schema...")

        # Group schemas by target
        schemas_by_target = self._group_by_target(schemas)

        for target, target_schemas in schemas_by_target.items():
            # Get output config for this target
            output_config = self.config.get_target_config("graphql", target)
            if not output_config:
                # Issue #54: No fallback - missing config is a configuration error
                from ..core.models import ConfigurationError

                raise ConfigurationError(
                    f"No GraphQL output config for target '{target}'. "
                    f"Add it to output.graphql.targets in schema-generator.yml"
                )

            # Clear type registry at start of generation for each target
            self._clear_registry()

            # Issue #49: Collect referenced schemas from other targets
            referenced_schemas = self._collect_referenced_schemas(target_schemas, schemas)
            if referenced_schemas:
                logger.info(
                    f"Including {len(referenced_schemas)} cross-target referenced types: "
                    f"{', '.join(referenced_schemas.keys())}"
                )

            # Merge target schemas with referenced schemas for generation
            # Target schemas take precedence (they're the primary schemas)
            merged_schemas = {**referenced_schemas, **target_schemas}

            parts = []
            parts.append(self._generate_header())

            # Add custom scalars if needed (e.g., DateTime)
            scalars = self._generate_scalars(merged_schemas)
            if scalars:
                parts.append(scalars)

            parts.append(self._generate_types(merged_schemas))
            parts.append(self._generate_response_types(merged_schemas))

            # Generate S3 types if any S3 schemas exist
            s3_types = self._generate_s3_types(merged_schemas)
            if s3_types:
                parts.append(s3_types)

            # Collect and generate nested input types before operation inputs
            nested_types = self._collect_nested_types(merged_schemas)
            nested_inputs = self._generate_nested_input_types(merged_schemas, nested_types)
            if nested_inputs:
                parts.append(nested_inputs)

            parts.append(self._generate_all_inputs(merged_schemas))

            # Generate S3 inputs if any S3 schemas exist
            s3_inputs = self._generate_s3_inputs(merged_schemas)
            if s3_inputs:
                parts.append(s3_inputs)

            parts.append(self._generate_queries(merged_schemas))

            # Generate S3 queries if any S3 schemas exist
            s3_queries = self._generate_s3_queries(merged_schemas)
            if s3_queries:
                parts.append(s3_queries)

            parts.append(self._generate_mutations(merged_schemas))

            # Generate S3 mutations if any S3 schemas exist
            s3_mutations = self._generate_s3_mutations(merged_schemas)
            if s3_mutations:
                parts.append(s3_mutations)

            parts.append(self._generate_enums(merged_schemas))

            content = "\n\n".join(filter(None, parts))
            # Use OutputConfig - GraphQL outputs to base_dir directly (no subdirs)
            output_path = output_config.base_dir / "schema.graphql"
            self._write_file(output_path, content)

            # Post-generation validation if enabled
            if self.config.validate_graphql:
                from ..core.validators import SchemaValidator

                # Use non-strict mode to collect errors without raising
                # This allows generation to complete while still reporting issues
                errors = SchemaValidator.validate_graphql_sdl(str(output_path), strict=False)
                if errors:
                    logger.warning(
                        f"GraphQL validation warnings for {output_path}:\n"
                        + "\n".join(f"  • {error}" for error in errors)
                    )

        logger.info(success("Generated GraphQL schema"))

    def generate_for_api(self, schemas: Dict[str, Any], api_def: "ApiDefinition") -> str:
        """Generate GraphQL schema for a specific API definition.

        Filters schemas to only those in api_def.tables and filters
        operations to only those matching api_def.include_operations patterns.

        Args:
            schemas: Dictionary of all schema objects
            api_def: API definition with tables and include_operations filters

        Returns:
            Generated GraphQL schema content as string
        """
        # Clear type registry for this API
        self._clear_registry()

        # Filter schemas to only those in the API's tables list
        filtered_schemas = self._filter_schemas_by_tables(schemas, api_def.tables)

        logger.info(
            f"Generating GraphQL for API '{api_def.name}' with "
            f"{len(filtered_schemas)} tables: {', '.join(filtered_schemas.keys())}"
        )

        # Collect referenced schemas (for nested types)
        referenced_schemas = self._collect_referenced_schemas(filtered_schemas, schemas)
        if referenced_schemas:
            logger.info(
                f"Including {len(referenced_schemas)} referenced types: "
                f"{', '.join(referenced_schemas.keys())}"
            )

        # Merge filtered schemas with referenced schemas
        merged_schemas = {**referenced_schemas, **filtered_schemas}

        parts = []
        parts.append(self._generate_header())

        # Add custom scalars if needed
        scalars = self._generate_scalars(merged_schemas)
        if scalars:
            parts.append(scalars)

        parts.append(self._generate_types(merged_schemas))
        parts.append(self._generate_response_types(merged_schemas))

        # Generate S3 types if any S3 schemas exist
        s3_types = self._generate_s3_types(merged_schemas)
        if s3_types:
            parts.append(s3_types)

        # Collect and generate nested input types
        nested_types = self._collect_nested_types(merged_schemas)
        nested_inputs = self._generate_nested_input_types(merged_schemas, nested_types)
        if nested_inputs:
            parts.append(nested_inputs)

        # Generate inputs with operation filtering
        parts.append(self._generate_all_inputs_filtered(merged_schemas, api_def.include_operations))

        # Generate S3 inputs if any S3 schemas exist
        s3_inputs = self._generate_s3_inputs(merged_schemas)
        if s3_inputs:
            parts.append(s3_inputs)

        # Generate queries with operation filtering
        parts.append(self._generate_queries_filtered(merged_schemas, api_def.include_operations))

        # Generate S3 queries if any S3 schemas exist
        s3_queries = self._generate_s3_queries(merged_schemas)
        if s3_queries:
            parts.append(s3_queries)

        # Generate mutations with operation filtering
        parts.append(self._generate_mutations_filtered(merged_schemas, api_def.include_operations))

        # Generate S3 mutations if any S3 schemas exist
        s3_mutations = self._generate_s3_mutations(merged_schemas)
        if s3_mutations:
            parts.append(s3_mutations)

        parts.append(self._generate_enums(merged_schemas))

        return "\n\n".join(filter(None, parts))

    def generate_multi_api(self, schemas: Dict[str, Any]) -> None:
        """Generate GraphQL schemas for all API definitions.

        This method is called when api_definitions are configured.
        Each API definition gets its own schema file at the specified output path.

        Args:
            schemas: Dictionary of all schema objects
        """
        from ..core.validators import validate_all_api_definitions

        api_definitions = self.config.api_definitions
        if not api_definitions:
            logger.warning("No API definitions configured for multi-API generation")
            return

        # Validate all API definitions against available schemas
        validate_all_api_definitions(api_definitions, schemas)

        for api_def in api_definitions:
            logger.info(f"Generating GraphQL schema for API: {api_def.name}")

            content = self.generate_for_api(schemas, api_def)

            # Write to API-specific output path
            output_path = api_def.schema_output
            self._write_file(output_path, content)

            # Post-generation validation if enabled
            if self.config.validate_graphql:
                from ..core.validators import SchemaValidator

                errors = SchemaValidator.validate_graphql_sdl(str(output_path), strict=False)
                if errors:
                    logger.warning(
                        f"GraphQL validation warnings for {output_path}:\n"
                        + "\n".join(f"  • {error}" for error in errors)
                    )

        logger.info(success(f"Generated {len(api_definitions)} GraphQL schemas"))

    def _generate_header(self) -> str:
        """Generate schema header with AUTO-GENERATED marker and AppSync directives."""
        header = self._get_file_header("graphql")
        return f"{header}# Generated GraphQL Schema\n\n{APPSYNC_DIRECTIVES}"

    def _generate_types(self, schemas: Dict[str, Any]) -> str:
        """
        Generate GraphQL type definitions.

        Uses type registry to prevent duplicate type definitions.
        For Lambda types, excludes input_only attributes from the output type (Issue #70).
        For Lambda types with auth_config, adds auth directives to type definition (Issue #75).

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Type definitions
        """
        lines = []
        lines.append("# Types")

        for name, schema in schemas.items():
            if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                type_name = schema.name

                # Check registry before generating - skip duplicates
                if not self._register_type(type_name):
                    continue

                lines.append("")

                # Issue #75: Add auth directives to Lambda type definitions
                if isinstance(schema, LambdaType):
                    auth_directive = self._get_lambda_auth_directives(schema)
                    if auth_directive:
                        lines.append(f"type {type_name} {auth_directive} {{")
                    else:
                        lines.append(f"type {type_name} {{")
                else:
                    lines.append(f"type {type_name} {{")

                for attr in schema.attributes:
                    # Issue #70: For Lambda types, skip input_only attributes in output type
                    if isinstance(schema, LambdaType) and attr.input_only:
                        continue
                    gql_type = self._graphql_type(attr)
                    lines.append(f"  {attr.name}: {gql_type}")

                lines.append("}")

        return "\n".join(lines)

    def _generate_response_types(self, schemas: Dict[str, Any]) -> str:
        """
        Generate all response types for TableSchema objects.

        For each TableSchema, generates:
        - {SchemaName}CreateResponse (mutation - single item)
        - {SchemaName}UpdateResponse (mutation - single item)
        - {SchemaName}DeleteResponse (mutation - single item)
        - {SchemaName}DisableResponse (mutation - single item)
        - {SchemaName}GetResponse (query - single item)
        - {SchemaName}ListResponse (query - multiple items with pagination)

        All response types include the standard envelope:
        - code: Int! (HTTP-style status code)
        - success: Boolean! (operation success indicator)
        - message: String (optional message, typically for errors)

        Uses type registry to prevent duplicate Response types.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Response type definitions
        """
        lines = []
        lines.append("# Response Types")

        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                # Generate mutation response types (single item)
                for op in ["Create", "Update", "Delete", "Disable"]:
                    response_type_name = f"{schema.name}{op}Response"

                    # Check registry before generating - skip duplicates
                    if not self._register_type(response_type_name):
                        continue

                    lines.append("")
                    lines.append(f"type {response_type_name} {{")
                    lines.append("  code: Int!")
                    lines.append("  success: Boolean!")
                    lines.append("  message: String")
                    lines.append(f"  item: {schema.name}")
                    lines.append("}")

                # Generate Get response type (single item)
                get_response_type_name = f"{schema.name}GetResponse"
                if self._register_type(get_response_type_name):
                    lines.append("")
                    lines.append(f"type {get_response_type_name} {{")
                    lines.append("  code: Int!")
                    lines.append("  success: Boolean!")
                    lines.append("  message: String")
                    lines.append(f"  item: {schema.name}")
                    lines.append("}")

                # Generate List response type (multiple items with pagination)
                list_response_type_name = f"{schema.name}ListResponse"
                if self._register_type(list_response_type_name):
                    lines.append("")
                    lines.append(f"type {list_response_type_name} {{")
                    lines.append("  code: Int!")
                    lines.append("  success: Boolean!")
                    lines.append("  message: String")
                    lines.append(f"  items: [{schema.name}!]")
                    lines.append("  nextToken: String")
                    lines.append("}")

        return "\n".join(lines)

    def _graphql_type(self, attr: Attribute, for_input: bool = False) -> str:
        """
        Convert schema type to GraphQL type.

        Priority:
        1. enum_type - Enum reference
        2. object_ref - Nested model reference (returns Input variant if for_input=True)
        3. items_ref - Array of model references (returns Input variant if for_input=True)
        4. model_reference - Direct model type
        5. Standard type mapping

        Args:
            attr: Attribute definition
            for_input: If True, return input type variants for nested types
                       (e.g., "AreaMeasurementInput" instead of "AreaMeasurement")

        Returns:
            GraphQL type string
        """
        if attr.enum_type:
            # Enums are valid in both output and input types
            base_type = attr.enum_type
        elif attr.object_ref:
            # Nested model reference - use Input variant for input types
            if for_input:
                base_type = f"{attr.object_ref}Input"
            else:
                base_type = attr.object_ref
        elif attr.type == "array" and attr.items_ref:
            # Array of model references - use Input variant for input types
            if for_input:
                item_type = f"{attr.items_ref}Input"
            else:
                item_type = attr.items_ref
            if attr.required:
                return f"[{item_type}!]!"
            return f"[{item_type}!]"
        elif hasattr(attr, "model_reference") and attr.model_reference:
            base_type = attr.model_reference
        else:
            base_type = to_graphql_type(attr.type)

        # Add required marker
        if attr.required:
            return f"{base_type}!"
        return base_type

    def _generate_all_inputs(self, schemas: Dict[str, Any]) -> str:
        """
        Generate all input types from operations.

        This is the SINGLE source of truth for input type generation.
        All inputs are derived from operations, not generated separately.
        Uses type registry to prevent duplicate input types.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Input type definitions
        """
        lines = []
        lines.append("# Input Types")

        # Generate Lambda input types (Issue #63)
        # Issue #70: Exclude output_only attributes from Input types
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType):
                input_name = f"{schema.name}Input"

                # Check registry before generating - skip duplicates
                if not self._register_type(input_name):
                    continue

                lines.append("")
                lines.append(f"input {input_name} {{")

                for attr in schema.attributes:
                    # Issue #70: Skip output_only attributes in Input type
                    if attr.output_only:
                        continue
                    # Use for_input=True to get Input variants for nested types
                    gql_type = self._graphql_type(attr, for_input=True)
                    lines.append(f"  {attr.name}: {gql_type}")

                lines.append("}")

        # Generate TableSchema input types from operations
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                for op in schema.operations:
                    input_name = f"{op.field}Input"

                    # Check registry before generating - skip duplicates
                    if not self._register_type(input_name):
                        continue

                    lines.append("")
                    lines.append(f"input {input_name} {{")

                    if op.input:
                        # Custom query with defined input fields
                        for field_name, field_def in op.input.items():
                            if isinstance(field_def, dict):
                                field_type = field_def.get("type", "String")
                                required = field_def.get("required", False)
                                gql_type = to_graphql_type(field_type)
                                if required:
                                    gql_type = f"{gql_type}!"
                                lines.append(f"  {field_name}: {gql_type}")
                            else:
                                # Simple type definition
                                lines.append(f"  {field_name}: {to_graphql_type(str(field_def))}")
                    elif op.type == "Query":
                        # Query operation - add key fields and pagination
                        if op.index_partition:
                            lines.append(f"  {op.index_partition}: String!")
                        if op.index_sort:
                            lines.append(f"  {op.index_sort}: String")
                        lines.append("  limit: Int")
                        lines.append("  nextToken: String")
                    elif op.type == "Mutation":
                        # Mutation operation - derive from operation name
                        if "Create" in op.name:
                            # Create uses all schema attributes - use for_input=True for nested types
                            for attr in schema.attributes:
                                gql_type = self._graphql_type(attr, for_input=True)
                                lines.append(f"  {attr.name}: {gql_type}")
                        elif "Update" in op.name:
                            # Update uses partition key required, others optional
                            # Use for_input=True for nested types
                            for attr in schema.attributes:
                                if attr.name == schema.partition_key:
                                    lines.append(f"  {attr.name}: String!")
                                elif attr.name == schema.sort_key and schema.sort_key != "None":
                                    lines.append(f"  {attr.name}: String!")
                                else:
                                    # Use _graphql_type with for_input=True, but make optional
                                    gql_type = self._graphql_type(attr, for_input=True)
                                    # Remove required marker for update (all non-key fields optional)
                                    if gql_type.endswith("!"):
                                        gql_type = gql_type[:-1]
                                    lines.append(f"  {attr.name}: {gql_type}")
                        elif "Delete" in op.name or "Disable" in op.name:
                            # Delete/Disable only needs keys
                            lines.append(f"  {schema.partition_key}: String!")
                            if schema.sort_key and schema.sort_key != "None":
                                lines.append(f"  {schema.sort_key}: String!")
                        else:
                            # Unknown mutation type - add placeholder
                            lines.append("  _placeholder: String")
                    else:
                        # Unknown operation type - add placeholder
                        lines.append("  _placeholder: String")

                    lines.append("}")

        return "\n".join(lines)

    def _generate_queries(self, schemas: Dict[str, Any]) -> str:
        """
        Generate Query type with all query operations.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Query type definition
        """
        lines = []
        lines.append("# Queries")
        lines.append("type Query {")

        # Generate Lambda query operations (Issue #63)
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType) and schema.operation == "query":
                auth_directive = self._get_lambda_auth_directives(schema)
                if auth_directive:
                    lines.append(
                        f"  {schema.name}(input: {schema.name}Input!): {schema.name} {auth_directive}"
                    )
                else:
                    lines.append(f"  {schema.name}(input: {schema.name}Input!): {schema.name}")

        # Generate TableSchema query operations
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                for op in schema.operations:
                    if op.type == "Query":
                        auth_directive = self._generate_auth_directive(op)
                        # Use operation's response_type_suffix for correct response type
                        response_type = f"{schema.name}{op.response_type_suffix}"
                        lines.append(
                            f"  {op.field}(input: {op.field}Input!): {response_type} {auth_directive}"
                        )

        lines.append("}")

        return "\n".join(lines)

    def _generate_mutations(self, schemas: Dict[str, Any]) -> str:
        """
        Generate Mutation type with all mutation operations.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Mutation type definition
        """
        lines = []
        lines.append("# Mutations")
        lines.append("type Mutation {")

        # Generate Lambda mutation operations (Issue #63)
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType) and schema.operation == "mutation":
                auth_directive = self._get_lambda_auth_directives(schema)
                if auth_directive:
                    lines.append(
                        f"  {schema.name}(input: {schema.name}Input!): {schema.name} {auth_directive}"
                    )
                else:
                    lines.append(f"  {schema.name}(input: {schema.name}Input!): {schema.name}")

        # Generate TableSchema mutation operations
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                for op in schema.operations:
                    if op.type == "Mutation":
                        auth_directive = self._generate_auth_directive(op)
                        # Use operation's response_type_suffix for correct response type
                        response_type = f"{schema.name}{op.response_type_suffix}"
                        lines.append(
                            f"  {op.field}(input: {op.field}Input!): {response_type} {auth_directive}"
                        )

        lines.append("}")

        return "\n".join(lines)

    def _generate_auth_directive(self, operation: Operation) -> str:
        """
        Generate auth directives for operation.

        Renders all directives in response_auth_directives, preserving
        their exact format and joining with spaces.

        Args:
            operation: Operation definition

        Returns:
            Auth directive string (e.g., "@aws_api_key @aws_auth(cognito_groups: [\"USER\"])")
        """
        if not operation.response_auth_directives:
            return ""

        # Return all directives joined with space
        return " ".join(operation.response_auth_directives)

    def _get_lambda_auth_directives(self, schema: LambdaType) -> str:
        """
        Get auth directives for a Lambda type schema.

        Uses the shared get_auth_directives_from_config utility to extract
        auth directives from the schema's auth_config.

        Args:
            schema: LambdaType schema with optional auth_config

        Returns:
            Auth directive string (e.g., "@aws_api_key @aws_auth(cognito_groups: [\"USER\"])")
        """
        directives = get_auth_directives_from_config(schema.auth_config, schema.name)
        return " ".join(directives) if directives else ""

    def _generate_enums(self, schemas: Dict[str, Any]) -> str:
        """
        Generate enum definitions for registry types.

        Uses type registry to prevent duplicate enum definitions.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Enum definitions
        """
        lines = []
        lines.append("# Enums")

        for name, schema in schemas.items():
            if isinstance(schema, RegistryType):
                enum_name = schema.name

                # Check registry before generating - skip duplicates
                if not self._register_type(enum_name):
                    continue

                lines.append("")
                lines.append(f"enum {enum_name} {{")
                for code in schema.items.keys():
                    # Convert enum key to valid GraphQL identifier (SCREAMING_SNAKE_CASE)
                    graphql_code = to_graphql_enum_member(code)
                    lines.append(f"  {graphql_code}")
                lines.append("}")

        return "\n".join(lines)

    # =========================================================================
    # FILTERED GENERATION METHODS FOR MULTI-API (Issue #83)
    # =========================================================================

    def _generate_all_inputs_filtered(
        self, schemas: Dict[str, Any], include_patterns: List[str]
    ) -> str:
        """Generate input types filtered by operation patterns.

        Only generates inputs for operations matching the include patterns.

        Args:
            schemas: Dictionary of schema objects
            include_patterns: Glob patterns for operations to include

        Returns:
            Input type definitions
        """
        lines = []
        lines.append("# Input Types")

        # Generate Lambda input types (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType):
                # Check if this Lambda operation should be included
                if not self._should_include_lambda_operation(schema, include_patterns):
                    continue

                input_name = f"{schema.name}Input"

                if not self._register_type(input_name):
                    continue

                lines.append("")
                lines.append(f"input {input_name} {{")

                for attr in schema.attributes:
                    if attr.output_only:
                        continue
                    gql_type = self._graphql_type(attr, for_input=True)
                    lines.append(f"  {attr.name}: {gql_type}")

                lines.append("}")

        # Generate TableSchema input types from operations (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                # Filter operations by patterns
                filtered_ops = self._filter_operations_by_patterns(
                    schema.operations, include_patterns
                )

                for op in filtered_ops:
                    input_name = f"{op.field}Input"

                    if not self._register_type(input_name):
                        continue

                    lines.append("")
                    lines.append(f"input {input_name} {{")

                    if op.input:
                        for field_name, field_def in op.input.items():
                            if isinstance(field_def, dict):
                                field_type = field_def.get("type", "String")
                                required = field_def.get("required", False)
                                gql_type = to_graphql_type(field_type)
                                if required:
                                    gql_type = f"{gql_type}!"
                                lines.append(f"  {field_name}: {gql_type}")
                            else:
                                lines.append(f"  {field_name}: {to_graphql_type(str(field_def))}")
                    elif op.type == "Query":
                        if op.index_partition:
                            lines.append(f"  {op.index_partition}: String!")
                        if op.index_sort:
                            lines.append(f"  {op.index_sort}: String")
                        lines.append("  limit: Int")
                        lines.append("  nextToken: String")
                    elif op.type == "Mutation":
                        if "Create" in op.name:
                            for attr in schema.attributes:
                                gql_type = self._graphql_type(attr, for_input=True)
                                lines.append(f"  {attr.name}: {gql_type}")
                        elif "Update" in op.name:
                            for attr in schema.attributes:
                                if attr.name == schema.partition_key:
                                    lines.append(f"  {attr.name}: String!")
                                elif attr.name == schema.sort_key and schema.sort_key != "None":
                                    lines.append(f"  {attr.name}: String!")
                                else:
                                    gql_type = self._graphql_type(attr, for_input=True)
                                    if gql_type.endswith("!"):
                                        gql_type = gql_type[:-1]
                                    lines.append(f"  {attr.name}: {gql_type}")
                        elif "Delete" in op.name or "Disable" in op.name:
                            lines.append(f"  {schema.partition_key}: String!")
                            if schema.sort_key and schema.sort_key != "None":
                                lines.append(f"  {schema.sort_key}: String!")
                        else:
                            lines.append("  _placeholder: String")
                    else:
                        lines.append("  _placeholder: String")

                    lines.append("}")

        return "\n".join(lines)

    def _generate_queries_filtered(
        self, schemas: Dict[str, Any], include_patterns: List[str]
    ) -> str:
        """Generate Query type with operations filtered by patterns.

        Args:
            schemas: Dictionary of schema objects
            include_patterns: Glob patterns for operations to include

        Returns:
            Query type definition
        """
        lines = []
        lines.append("# Queries")
        lines.append("type Query {")

        # Generate Lambda query operations (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType) and schema.operation == "query":
                if not self._should_include_lambda_operation(schema, include_patterns):
                    continue

                auth_directive = self._get_lambda_auth_directives(schema)
                if auth_directive:
                    lines.append(
                        f"  {schema.name}(input: {schema.name}Input!): {schema.name} {auth_directive}"
                    )
                else:
                    lines.append(f"  {schema.name}(input: {schema.name}Input!): {schema.name}")

        # Generate TableSchema query operations (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                filtered_ops = self._filter_operations_by_patterns(
                    schema.operations, include_patterns
                )

                for op in filtered_ops:
                    if op.type == "Query":
                        auth_directive = self._generate_auth_directive(op)
                        response_type = f"{schema.name}{op.response_type_suffix}"
                        lines.append(
                            f"  {op.field}(input: {op.field}Input!): {response_type} {auth_directive}"
                        )

        lines.append("}")

        return "\n".join(lines)

    def _generate_mutations_filtered(
        self, schemas: Dict[str, Any], include_patterns: List[str]
    ) -> str:
        """Generate Mutation type with operations filtered by patterns.

        Args:
            schemas: Dictionary of schema objects
            include_patterns: Glob patterns for operations to include

        Returns:
            Mutation type definition
        """
        lines = []
        lines.append("# Mutations")
        lines.append("type Mutation {")

        # Generate Lambda mutation operations (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, LambdaType) and schema.operation == "mutation":
                if not self._should_include_lambda_operation(schema, include_patterns):
                    continue

                auth_directive = self._get_lambda_auth_directives(schema)
                if auth_directive:
                    lines.append(
                        f"  {schema.name}(input: {schema.name}Input!): {schema.name} {auth_directive}"
                    )
                else:
                    lines.append(f"  {schema.name}(input: {schema.name}Input!): {schema.name}")

        # Generate TableSchema mutation operations (filtered)
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and hasattr(schema, "operations"):
                filtered_ops = self._filter_operations_by_patterns(
                    schema.operations, include_patterns
                )

                for op in filtered_ops:
                    if op.type == "Mutation":
                        auth_directive = self._generate_auth_directive(op)
                        response_type = f"{schema.name}{op.response_type_suffix}"
                        lines.append(
                            f"  {op.field}(input: {op.field}Input!): {response_type} {auth_directive}"
                        )

        lines.append("}")

        return "\n".join(lines)

    # =========================================================================
    # S3 SCHEMA GENERATION (Issue #53)
    # =========================================================================

    def _generate_s3_types(self, schemas: Dict[str, Any]) -> str:
        """
        Generate GraphQL types for S3 operations.

        Generates common response types used by S3 operations:
        - UploadUrlResponse
        - DownloadUrlResponse
        - FileInfo
        - FileListResponse
        - DeleteFileResponse

        Args:
            schemas: Dictionary of schema objects

        Returns:
            S3 type definitions or empty string if no S3 schemas
        """
        # Check if any S3 schemas exist
        has_s3 = any(isinstance(s, S3Schema) for s in schemas.values())
        if not has_s3:
            return ""

        lines = []
        lines.append("# S3 Storage Types")

        # UploadUrlResponse
        if self._register_type("UploadUrlResponse"):
            lines.append("")
            lines.append("type UploadUrlResponse {")
            lines.append("  url: String!")
            lines.append("  key: String!")
            lines.append("  expiresAt: AWSDateTime!")
            lines.append("}")

        # DownloadUrlResponse
        if self._register_type("DownloadUrlResponse"):
            lines.append("")
            lines.append("type DownloadUrlResponse {")
            lines.append("  url: String!")
            lines.append("  key: String!")
            lines.append("  expiresAt: AWSDateTime!")
            lines.append("}")

        # FileInfo
        if self._register_type("FileInfo"):
            lines.append("")
            lines.append("type FileInfo {")
            lines.append("  key: String!")
            lines.append("  size: Int!")
            lines.append("  lastModified: AWSDateTime!")
            lines.append("  etag: String")
            lines.append("}")

        # FileListResponse
        if self._register_type("FileListResponse"):
            lines.append("")
            lines.append("type FileListResponse {")
            lines.append("  files: [FileInfo!]!")
            lines.append("  continuationToken: String")
            lines.append("  isTruncated: Boolean!")
            lines.append("}")

        # DeleteFileResponse
        if self._register_type("DeleteFileResponse"):
            lines.append("")
            lines.append("type DeleteFileResponse {")
            lines.append("  success: Boolean!")
            lines.append("  key: String!")
            lines.append("}")

        return "\n".join(lines)

    def _generate_s3_inputs(self, schemas: Dict[str, Any]) -> str:
        """
        Generate GraphQL input types for S3 operations.

        Generates input types for each S3 schema's operations:
        - {SchemaName}UploadInput
        - {SchemaName}DownloadInput
        - {SchemaName}ListInput
        - {SchemaName}DeleteInput

        Args:
            schemas: Dictionary of schema objects

        Returns:
            S3 input type definitions or empty string if no S3 schemas
        """
        lines = []
        has_inputs = False

        for name, schema in schemas.items():
            if isinstance(schema, S3Schema):
                if not has_inputs:
                    lines.append("# S3 Storage Inputs")
                    has_inputs = True

                # Generate input types for each operation
                if "GetUploadUrl" in schema.operations:
                    input_name = f"{schema.name}UploadInput"
                    if self._register_type(input_name):
                        lines.append("")
                        lines.append(f"input {input_name} {{")
                        lines.append("  resourceId: String!")
                        lines.append("  resourceType: String")
                        lines.append("  fileName: String!")
                        lines.append("  contentType: String!")
                        lines.append("  expiresIn: Int")
                        lines.append("}")

                if "GetDownloadUrl" in schema.operations:
                    input_name = f"{schema.name}DownloadInput"
                    if self._register_type(input_name):
                        lines.append("")
                        lines.append(f"input {input_name} {{")
                        lines.append("  resourceId: String!")
                        lines.append("  resourceType: String")
                        lines.append("  fileName: String!")
                        lines.append("  expiresIn: Int")
                        lines.append("}")

                if "ListFiles" in schema.operations:
                    input_name = f"{schema.name}ListInput"
                    if self._register_type(input_name):
                        lines.append("")
                        lines.append(f"input {input_name} {{")
                        lines.append("  resourceId: String!")
                        lines.append("  resourceType: String")
                        lines.append("  prefix: String")
                        lines.append("  maxKeys: Int")
                        lines.append("  continuationToken: String")
                        lines.append("}")

                if "DeleteFile" in schema.operations:
                    input_name = f"{schema.name}DeleteInput"
                    if self._register_type(input_name):
                        lines.append("")
                        lines.append(f"input {input_name} {{")
                        lines.append("  resourceId: String!")
                        lines.append("  resourceType: String")
                        lines.append("  fileName: String!")
                        lines.append("}")

        return "\n".join(lines) if has_inputs else ""

    def _generate_s3_queries(self, schemas: Dict[str, Any]) -> str:
        """
        Generate GraphQL queries for S3 operations.

        Generates queries for:
        - GetDownloadUrl
        - ListFiles

        Args:
            schemas: Dictionary of schema objects

        Returns:
            S3 query definitions or empty string if no S3 schemas
        """
        lines = []
        has_queries = False

        for name, schema in schemas.items():
            if isinstance(schema, S3Schema):
                if "GetDownloadUrl" in schema.operations or "ListFiles" in schema.operations:
                    if not has_queries:
                        lines.append("# S3 Storage Queries")
                        lines.append("extend type Query {")
                        has_queries = True

                    if "GetDownloadUrl" in schema.operations:
                        lines.append(
                            f"  {schema.name}GetDownloadUrl(input: {schema.name}DownloadInput!): DownloadUrlResponse!"
                        )

                    if "ListFiles" in schema.operations:
                        lines.append(
                            f"  {schema.name}ListFiles(input: {schema.name}ListInput!): FileListResponse!"
                        )

        if has_queries:
            lines.append("}")

        return "\n".join(lines) if has_queries else ""

    def _generate_s3_mutations(self, schemas: Dict[str, Any]) -> str:
        """
        Generate GraphQL mutations for S3 operations.

        Generates mutations for:
        - GetUploadUrl
        - DeleteFile

        Args:
            schemas: Dictionary of schema objects

        Returns:
            S3 mutation definitions or empty string if no S3 schemas
        """
        lines = []
        has_mutations = False

        for name, schema in schemas.items():
            if isinstance(schema, S3Schema):
                if "GetUploadUrl" in schema.operations or "DeleteFile" in schema.operations:
                    if not has_mutations:
                        lines.append("# S3 Storage Mutations")
                        lines.append("extend type Mutation {")
                        has_mutations = True

                    if "GetUploadUrl" in schema.operations:
                        lines.append(
                            f"  {schema.name}GetUploadUrl(input: {schema.name}UploadInput!): UploadUrlResponse!"
                        )

                    if "DeleteFile" in schema.operations:
                        lines.append(
                            f"  {schema.name}DeleteFile(input: {schema.name}DeleteInput!): DeleteFileResponse!"
                        )

        if has_mutations:
            lines.append("}")

        return "\n".join(lines) if has_mutations else ""
