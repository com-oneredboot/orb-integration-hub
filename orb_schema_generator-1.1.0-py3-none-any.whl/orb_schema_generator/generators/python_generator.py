"""Python model generator."""

from typing import Any, Dict, Optional
import logging

from .base import BaseGenerator
from ..core.models import TableSchema, StandardType, LambdaType, RegistryType, Attribute
from ..core.import_resolver import ImportResolver
from ..utils.type_mapping import EnhancedTypeMapper
from ..utils.case_conversion import to_snake_case, to_pascal_case, to_python_enum_member
from ..utils.console import success

logger = logging.getLogger(__name__)


class PythonGenerator(BaseGenerator):
    """Generates Python Pydantic models and StrEnum enums from schemas."""

    def __init__(self, config):
        """Initialize the Python generator with enhanced type mapping."""
        super().__init__(config)
        self.type_mapper = EnhancedTypeMapper()

    def _path_to_python_module(self, rel_path: str) -> str:
        """
        Convert a relative file path to Python module notation.

        In Python relative imports:
        - "." means current package
        - ".." means parent package (one level up)
        - "..." means grandparent package (two levels up)

        Args:
            rel_path: Relative path like "../enums/", "./", "enums/"

        Returns:
            Python module prefix like "..enums", ".", "enums"

        Examples:
            "../enums/" -> "..enums" (go up one level, then into enums)
            "./" -> "."
            "enums/" -> ".enums" (same level, into enums subpackage)
            "../../types/enums/" -> "...types.enums"
        """
        if rel_path == "./":
            return "."

        # Count leading "../" for relative imports
        # Each "../" adds one dot (starting from one dot for current package)
        dot_count = 1  # Start with 1 for the base relative import
        path = rel_path
        while path.startswith("../"):
            dot_count += 1
            path = path[3:]

        dots = "." * dot_count

        # Remove trailing slash and convert remaining slashes to dots
        path = path.rstrip("/")
        if path:
            module_path = path.replace("/", ".")
            return dots + module_path
        else:
            # Only had "../" parts, return just the dots
            return dots

    def generate(
        self, schemas: Dict[str, Any], all_schemas: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Generate Python models and enums for all schemas.

        Handles all schema types in a unified manner:
        - RegistryType → StrEnum with to_json()/from_json()
        - StandardType, TableSchema, LambdaType → Pydantic models

        Uses target-based routing to write files to the correct output directories.
        Generates __init__.py barrel files when generate_init is True.

        Args:
            schemas: Dictionary of schema objects keyed by name
            all_schemas: All loaded schemas for cross-target import resolution.
                        If None, defaults to schemas (backward compatibility).
        """
        # Default all_schemas to schemas for backward compatibility
        if all_schemas is None:
            all_schemas = schemas

        logger.info(f"Generating Python code for {len(schemas)} schemas...")

        # Group schemas by target
        schemas_by_target = self._group_by_target(schemas)

        model_count = 0
        enum_count = 0
        query_count = 0

        for target, target_schemas in schemas_by_target.items():
            # Get output config for this target
            output_config = self.config.get_target_config("python", target)
            if not output_config:
                # No fallback - missing config is a configuration error
                from ..core.models import ConfigurationError

                raise ConfigurationError(
                    f"No Python output config for target '{target}'. "
                    f"Add it to output.python.targets in schema-generator.yml"
                )

            # Create ImportResolver for cross-target import resolution
            import_resolver = ImportResolver(self.config, all_schemas)

            # Track generated files for barrel file generation
            generated_models: list[tuple[str, str]] = []  # (filename, class_name)
            generated_enums: list[tuple[str, str]] = []  # (filename, class_name)

            for name, schema in target_schemas.items():
                if isinstance(schema, RegistryType):
                    content = self._generate_enum(schema)
                    filename = to_snake_case(name) + "_enum"
                    output_path = output_config.enum_path(filename, "py")
                    self._write_file(output_path, content)
                    enum_count += 1
                    # Use to_pascal_case to handle both snake_case and preserve acronyms
                    generated_enums.append((filename, to_pascal_case(name)))
                elif isinstance(schema, (TableSchema, StandardType, LambdaType)):
                    content = self._generate_model(schema, output_config, import_resolver, target)
                    filename = f"{name}Model"
                    output_path = output_config.model_path(filename, "py")
                    self._write_file(output_path, content)
                    model_count += 1
                    generated_models.append((filename, name))

            # Generate __init__.py barrel files if enabled
            if output_config.generate_init:
                if generated_models:
                    init_content = self._generate_init_file(generated_models, "model")
                    init_path = output_config.init_path("model")
                    self._write_file(init_path, init_content)
                    logger.debug(f"Generated {init_path}")

                if generated_enums:
                    init_content = self._generate_init_file(generated_enums, "enum")
                    init_path = output_config.init_path("enum")
                    self._write_file(init_path, init_content)
                    logger.debug(f"Generated {init_path}")

            # Generate GraphQL query definition files (Issue #79)
            query_count += self._generate_graphql_queries(
                target_schemas, output_config, all_schemas=all_schemas
            )

        logger.info(success(f"Generated {model_count} Python model files"))
        if enum_count > 0:
            logger.info(success(f"Generated {enum_count} Python enum files"))
        if query_count > 0:
            logger.info(success(f"Generated {query_count} Python GraphQL query files"))

    def _generate_enum(self, registry: RegistryType) -> str:
        """
        Generate Python StrEnum from RegistryType with JSON serialization.

        Uses Python 3.12+ StrEnum for type-safe string enums with
        to_json() and from_json() methods for JSON serialization.

        Args:
            registry: RegistryType schema object

        Returns:
            Complete Python enum file content
        """
        lines = []
        # Use to_pascal_case to handle both snake_case and preserve acronyms
        enum_name = to_pascal_case(registry.name)

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("python").rstrip())

        # Module docstring
        lines.append('"""')
        if registry.description:
            lines.append(f"{registry.description}")
        else:
            lines.append(f"Generated Python enum for {enum_name}")
        lines.append('"""')
        lines.append("")

        # Imports
        lines.append("from enum import StrEnum")
        lines.append("")
        lines.append("")

        # Enum class
        lines.append(f"class {enum_name}(StrEnum):")
        if registry.description:
            lines.append(f'    """{registry.description}"""')
        else:
            lines.append(f'    """{enum_name} enum."""')
        lines.append("")

        # Generate enum members with SCREAMING_SNAKE_CASE
        for key, item_data in registry.items.items():
            # Get the JSON value (original value from schema)
            json_value = item_data.get("value", key.lower()) if isinstance(item_data, dict) else key

            # Get description if available
            description = item_data.get("description") if isinstance(item_data, dict) else None

            # Convert enum key to SCREAMING_SNAKE_CASE for Python enum member
            member_name = to_python_enum_member(key)

            if description:
                lines.append(f"    # {description}")
            lines.append(f'    {member_name} = "{json_value}"')

        lines.append("")

        # Add to_json method
        lines.append("    def to_json(self) -> str:")
        lines.append('        """Convert enum to JSON string value."""')
        lines.append("        return self.value")
        lines.append("")

        # Add from_json classmethod
        lines.append("    @classmethod")
        lines.append(f'    def from_json(cls, value: str) -> "{enum_name}":')
        lines.append('        """Create enum from JSON string value."""')
        lines.append("        for member in cls:")
        lines.append("            if member.value == value:")
        lines.append("                return member")
        lines.append(f'        raise ValueError(f"Unknown {enum_name} value: {{value}}")')

        return "\n".join(lines)

    def _generate_init_file(self, files: list[tuple[str, str]], file_type: str) -> str:
        """Generate __init__.py content for a directory.

        Creates a barrel file that exports all generated classes from the directory,
        making imports cleaner for consumers.

        Args:
            files: List of (filename, class_name) tuples for generated files
            file_type: "model" or "enum"

        Returns:
            __init__.py content with imports and __all__ list
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("python").rstrip())

        # Module docstring
        lines.append('"""')
        if file_type == "model":
            lines.append("Generated Python models barrel file.")
        else:
            lines.append("Generated Python enums barrel file.")
        lines.append('"""')
        lines.append("")

        # Generate imports
        all_symbols = []
        for filename, class_name in sorted(files, key=lambda x: x[1]):
            lines.append(f"from .{filename} import {class_name}")
            all_symbols.append(class_name)

        # Add __all__ list
        lines.append("")
        lines.append(f"__all__ = {all_symbols!r}")

        return "\n".join(lines)

    def _generate_model(
        self,
        schema: Any,
        output_config=None,
        import_resolver: Optional[ImportResolver] = None,
        current_target: Optional[str] = None,
    ) -> str:
        """
        Generate complete Python model file.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to python_output)
            import_resolver: ImportResolver for cross-target import resolution
            current_target: Current target being generated

        Returns:
            Complete Python model file content
        """
        if output_config is None:
            output_config = self.config.python_output

        parts = []
        parts.append(self._generate_imports(schema, output_config, import_resolver, current_target))

        # Only generate input types for DynamoDB tables
        if isinstance(schema, TableSchema):
            parts.append(self._generate_input_types(schema))

        parts.append(self._generate_main_model(schema))
        parts.append(self._generate_response_types(schema))

        # Join with triple newlines (2 blank lines) for black compliance between top-level sections
        return "\n\n\n".join(parts) + "\n"

    def _generate_imports(
        self,
        schema: Any,
        output_config=None,
        import_resolver: Optional[ImportResolver] = None,
        current_target: Optional[str] = None,
    ) -> str:
        """
        Generate import statements using enhanced type mapping.

        Analyzes all attributes to determine exactly which typing imports are needed,
        avoiding duplicate imports and ensuring all used types are imported.

        Uses ImportResolver to determine if referenced types should be imported from
        another target (via imports_from configuration) or generated locally.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to python_output)
            import_resolver: ImportResolver for cross-target import resolution
            current_target: Current target being generated

        Returns:
            Import statements
        """
        if output_config is None:
            output_config = self.config.python_output

        lines = []
        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("python").rstrip())
        lines.append('"""')
        lines.append(f"Generated Python models for {schema.name}")
        lines.append('"""')
        lines.append("")

        # Issue #69: Analyze schema to determine which imports are needed
        # Only import field_validator if timestamp or boolean fields exist
        needs_field_validator = any(
            attr.type in ("timestamp", "boolean") for attr in schema.attributes
        )
        # Only import datetime if timestamp fields exist
        needs_datetime = any(attr.type == "timestamp" for attr in schema.attributes)

        # Build pydantic imports conditionally (Issue #69)
        pydantic_imports = ["BaseModel", "ConfigDict", "Field"]
        if needs_field_validator:
            pydantic_imports.append("field_validator")
        lines.append(f"from pydantic import {', '.join(sorted(pydantic_imports))}")

        # Track which typing imports are needed
        typing_imports: set[str] = set()
        other_imports: set[str] = set()
        enum_imports: set[str] = set()
        model_imports: set[str] = set()
        # Track cross-target imports separately
        cross_target_imports: list[str] = []

        # Response types always use Optional and List
        typing_imports.add("Optional")
        typing_imports.add("List")

        # Issue #69: Only add datetime import if timestamp fields exist
        if needs_datetime:
            other_imports.add("from datetime import datetime")

        for attr in schema.attributes:
            if attr.enum_type:
                enum_imports.add(attr.enum_type)

            # Collect model imports from items_ref (array of models)
            if attr.items_ref:
                model_imports.add(attr.items_ref)
                typing_imports.add("List")

            # Collect model imports from object_ref (nested model)
            if attr.object_ref:
                model_imports.add(attr.object_ref)

            # Collect model imports from direct model reference
            if hasattr(attr, "model_reference") and attr.model_reference:
                model_imports.add(attr.model_reference)

            # Track Optional for non-required fields
            if not attr.required:
                typing_imports.add("Optional")

            # Get type mapping for standard types to determine imports
            if not attr.enum_type and not attr.items_ref and not attr.object_ref:
                try:
                    mapping = self.type_mapper.get_type_mapping(attr.type)

                    # Parse python_import to extract typing imports
                    if mapping.python_import:
                        import_stmt = mapping.python_import
                        if "from typing import" in import_stmt:
                            # Extract types from "from typing import X, Y"
                            types_part = import_stmt.split("import ")[1]
                            for t in types_part.split(","):
                                typing_imports.add(t.strip())
                        elif "from datetime import" in import_stmt:
                            # Issue #69: datetime is handled conditionally above
                            # Skip adding it here to avoid duplicates
                            pass
                        else:
                            other_imports.add(import_stmt)

                    # Check if type uses List, Dict, Any, etc.
                    if "List[" in mapping.python_type:
                        typing_imports.add("List")
                    if "Dict[" in mapping.python_type:
                        typing_imports.add("Dict")
                    if "Any" in mapping.python_type:
                        typing_imports.add("Any")
                    if "Set[" in mapping.python_type:
                        typing_imports.add("Set")

                except ValueError:
                    # Fallback for unknown types
                    pass

        # Add typing imports as a single line
        if typing_imports:
            sorted_imports = sorted(typing_imports)
            lines.append(f"from typing import {', '.join(sorted_imports)}")

        # Add other imports (datetime, etc.)
        for import_stmt in sorted(other_imports):
            lines.append(import_stmt)

        # Separate enums into cross-target and local imports
        local_enum_imports: set[str] = set()
        for enum_name in enum_imports:
            if import_resolver and current_target:
                resolution = import_resolver.resolve(enum_name, current_target, "python")
                if resolution.should_import and resolution.import_path:
                    # Use configured import path for cross-target import
                    # Enum module naming: snake_case + _enum suffix
                    module_name = to_snake_case(enum_name) + "_enum"
                    cross_target_imports.append(
                        f"from {resolution.import_path}.{module_name} import {enum_name}"
                    )
                else:
                    local_enum_imports.add(enum_name)
            else:
                local_enum_imports.add(enum_name)

        # Add local enum imports (Issue #19, #39 fix: use relative paths with snake_case)
        if local_enum_imports:
            lines.append("")
            rel_path = output_config.relative_import_path("model", "enum")
            # Convert path to Python module notation: "../enums/" -> "..enums"
            module_prefix = self._path_to_python_module(rel_path)
            for enum_name in sorted(local_enum_imports):
                # Use snake_case for module name (file name)
                module_name = to_snake_case(enum_name) + "_enum"
                # Issue #42 fix: handle same-directory imports correctly
                if module_prefix == ".":
                    lines.append(f"from .{module_name} import {enum_name}")
                else:
                    lines.append(f"from {module_prefix}.{module_name} import {enum_name}")

        # Separate models into cross-target and local imports
        local_model_imports: set[str] = set()
        for model_name in model_imports:
            if import_resolver and current_target:
                resolution = import_resolver.resolve(model_name, current_target, "python")
                if resolution.should_import and resolution.import_path:
                    # Use configured import path for cross-target import
                    cross_target_imports.append(
                        f"from {resolution.import_path} import {model_name}"
                    )
                else:
                    local_model_imports.add(model_name)
            else:
                local_model_imports.add(model_name)

        # Add local model reference imports (Issue #19, #39, #42 fix: use relative paths)
        if local_model_imports:
            lines.append("")
            rel_path = output_config.relative_import_path("model", "model")
            # Convert path to Python module notation: "./" -> "."
            module_prefix = self._path_to_python_module(rel_path)
            for model_name in sorted(local_model_imports):
                # Issue #42 fix: handle same-directory imports correctly
                # When module_prefix is ".", we need "from .ModelName" not "from ..ModelName"
                if module_prefix == ".":
                    lines.append(f"from .{model_name}Model import {model_name}")
                else:
                    lines.append(f"from {module_prefix}.{model_name}Model import {model_name}")

        # Add cross-target imports (from imports_from configuration)
        if cross_target_imports:
            lines.append("")
            lines.append("# Cross-target imports (from imports_from configuration)")
            for import_stmt in sorted(cross_target_imports):
                lines.append(import_stmt)

        return "\n".join(lines)

    def _generate_input_types(self, schema: TableSchema) -> str:
        """
        Generate CRUD input types.

        Args:
            schema: Table schema

        Returns:
            CRUD input type definitions
        """
        lines = []
        lines.append("# CRUD Input Types")

        # CreateInput
        lines.append(f"class {schema.name}CreateInput(BaseModel):")
        lines.append(f'    """{schema.name} create input."""')
        lines.append("")
        for attr in schema.attributes:
            py_type = self._python_type(attr)
            field_name = to_snake_case(attr.name)
            field_def = self._generate_field_definition(attr, py_type)

            if attr.required:
                lines.append(f"    {field_name}: {py_type} = {field_def}")
            else:
                lines.append(f"    {field_name}: Optional[{py_type}] = {field_def}")

        lines.append("")
        lines.append("")

        # UpdateInput
        lines.append(f"class {schema.name}UpdateInput(BaseModel):")
        lines.append(f'    """{schema.name} update input."""')
        lines.append("")
        for attr in schema.attributes:
            py_type = self._python_type(attr)
            field_name = to_snake_case(attr.name)
            field_def = self._generate_field_definition(attr, py_type)
            lines.append(f"    {field_name}: Optional[{py_type}] = {field_def}")

        lines.append("")
        lines.append("")

        # DeleteInput
        lines.append(f"class {schema.name}DeleteInput(BaseModel):")
        lines.append(f'    """{schema.name} delete input."""')
        lines.append("")
        pk_field = to_snake_case(schema.partition_key)
        lines.append(f"    {pk_field}: str")
        if schema.sort_key and schema.sort_key != "None":
            sk_field = to_snake_case(schema.sort_key)
            lines.append(f"    {sk_field}: str")

        lines.append("")
        lines.append("")

        # DisableInput
        lines.append(f"class {schema.name}DisableInput(BaseModel):")
        lines.append(f'    """{schema.name} disable input."""')
        lines.append("")
        lines.append(f"    {pk_field}: str")
        if schema.sort_key and schema.sort_key != "None":
            sk_field = to_snake_case(schema.sort_key)
            lines.append(f"    {sk_field}: str")
        lines.append("    disabled: bool")

        return "\n".join(lines)

    def _generate_query_input_types(self, schema: TableSchema) -> str:
        """
        Generate Query input types for indexes.

        Issue #84: Refactored to use schema.operations from OperationBuilder
        as the single source of truth, ensuring deduplication when multiple
        GSIs share the same partition key. This follows the DRY principle.

        Args:
            schema: Table schema

        Returns:
            Query input type definitions
        """
        lines = []
        lines.append("")
        lines.append("# Query Input Types")

        # Issue #84: Use schema.operations from OperationBuilder (canonical source)
        # This ensures deduplication when multiple GSIs share the same partition key
        generated_query_classes: set[str] = set()

        if hasattr(schema, "operations") and schema.operations:
            for op in schema.operations:
                # Only generate for ListBy* operations (queries)
                if op.name.startswith("ListBy") and op.index_partition:
                    # Build class name using QueryBy* naming for backward compatibility
                    idx_pascal = to_pascal_case(op.index_partition)
                    idx_snake = to_snake_case(op.index_partition)
                    class_name = f"{schema.name}QueryBy{idx_pascal}Input"

                    # Skip if already generated (deduplication)
                    if class_name in generated_query_classes:
                        continue
                    generated_query_classes.add(class_name)

                    lines.append(f"class {class_name}(BaseModel):")
                    lines.append(f'    """{schema.name} query by {op.index_partition}."""')
                    lines.append("")
                    lines.append(f"    {idx_snake}: str")
                    lines.append("")
                    lines.append("")

            # Generate QueryByBoth if we have both partition and sort key
            if schema.sort_key and schema.sort_key != "None":
                pk_snake = to_snake_case(schema.partition_key)
                sk_snake = to_snake_case(schema.sort_key)
                lines.append(f"class {schema.name}QueryByBothInput(BaseModel):")
                lines.append(f'    """{schema.name} query by both keys."""')
                lines.append("")
                lines.append(f"    {pk_snake}: str")
                lines.append(f"    {sk_snake}: str")
                lines.append("")
                lines.append("")
        else:
            # Fallback for schemas without operations (backward compatibility)
            pk_pascal = to_pascal_case(schema.partition_key)
            pk_snake = to_snake_case(schema.partition_key)
            pk_class_name = f"{schema.name}QueryBy{pk_pascal}Input"
            generated_query_classes.add(pk_class_name)
            lines.append(f"class {pk_class_name}(BaseModel):")
            lines.append(f'    """{schema.name} query by {schema.partition_key}."""')
            lines.append("")
            lines.append(f"    {pk_snake}: str")

            lines.append("")
            lines.append("")

            # QueryBySortKey (if exists)
            if schema.sort_key and schema.sort_key != "None":
                sk_pascal = to_pascal_case(schema.sort_key)
                sk_snake = to_snake_case(schema.sort_key)
                sk_class_name = f"{schema.name}QueryBy{sk_pascal}Input"
                # Only generate if not already generated (could match partition key)
                if sk_class_name not in generated_query_classes:
                    generated_query_classes.add(sk_class_name)
                    lines.append(f"class {sk_class_name}(BaseModel):")
                    lines.append(f'    """{schema.name} query by {schema.sort_key}."""')
                    lines.append("")
                    lines.append(f"    {sk_snake}: str")

                    lines.append("")
                    lines.append("")

                # QueryByBoth
                pk_snake = to_snake_case(schema.partition_key)
                lines.append(f"class {schema.name}QueryByBothInput(BaseModel):")
                lines.append(f'    """{schema.name} query by both keys."""')
                lines.append("")
                lines.append(f"    {pk_snake}: str")
                lines.append(f"    {sk_snake}: str")

                lines.append("")
                lines.append("")

            # Query by secondary indexes (fallback without operations)
            if schema.secondary_indexes:
                for index in schema.secondary_indexes:
                    index_partition = index.get("partition")
                    if index_partition:
                        idx_pascal = to_pascal_case(index_partition)
                        idx_snake = to_snake_case(index_partition)
                        idx_class_name = f"{schema.name}QueryBy{idx_pascal}Input"
                        # Only generate if not already generated
                        if idx_class_name not in generated_query_classes:
                            generated_query_classes.add(idx_class_name)
                            lines.append(f"class {idx_class_name}(BaseModel):")
                            lines.append(f'    """{schema.name} query by {index_partition}."""')
                            lines.append("")
                            lines.append(f"    {idx_snake}: str")
                            lines.append("")
                            lines.append("")

        return "\n".join(lines)

    def _generate_main_model(self, schema: Any) -> str:
        """
        Generate main Pydantic model.

        Args:
            schema: Schema object

        Returns:
            Main model class definition
        """
        lines = []

        # Add query input types for TableSchema
        if isinstance(schema, TableSchema):
            lines.append(self._generate_query_input_types(schema))

        lines.append("# Main Model")
        lines.append(f"class {schema.name}(BaseModel):")
        lines.append(f'    """{schema.name} model."""')
        lines.append("")

        # Add model_config using ConfigDict (modern Pydantic v2 pattern)
        lines.append("    model_config = ConfigDict(from_attributes=True)")
        lines.append("")

        # Generate fields
        for attr in schema.attributes:
            py_type = self._python_type(attr)
            field_name = to_snake_case(attr.name)
            field_def = self._generate_field_definition(attr, py_type)

            if attr.required:
                lines.append(f"    {field_name}: {py_type} = {field_def}")
            else:
                lines.append(f"    {field_name}: Optional[{py_type}] = {field_def}")

        # Add validators
        validators = self._generate_validators(schema)
        if validators:
            lines.append("")
            lines.append(validators)

        return "\n".join(lines)

    def _generate_validators(self, schema: Any) -> str:
        """
        Generate validators for timestamps and booleans.

        Args:
            schema: Schema object

        Returns:
            Validator methods
        """
        lines = []

        for attr in schema.attributes:
            field_name = to_snake_case(attr.name)

            # Timestamp validator
            if attr.type == "timestamp":
                lines.append(f'    @field_validator("{field_name}", mode="before")')
                lines.append("    @classmethod")
                lines.append(f"    def parse_{field_name}(cls, value):")
                lines.append('        """Parse timestamp to epoch seconds."""')
                lines.append("        if value is None:")
                lines.append("            return None")
                lines.append("        if isinstance(value, int):")
                lines.append("            return value")
                lines.append("        if isinstance(value, float):")
                lines.append("            return int(value)")
                lines.append("        if isinstance(value, datetime):")
                lines.append("            return int(value.timestamp())")
                lines.append("        if isinstance(value, str):")
                lines.append("            try:")
                lines.append(
                    '                dt = datetime.fromisoformat(value.replace("Z", "+00:00"))'
                )
                lines.append("                return int(dt.timestamp())")
                lines.append("            except (ValueError, TypeError):")
                lines.append("                pass")
                lines.append("        return value")
                lines.append("")

            # Boolean validator
            elif attr.type == "boolean":
                lines.append(f'    @field_validator("{field_name}", mode="before")')
                lines.append("    @classmethod")
                lines.append(f"    def parse_{field_name}(cls, value):")
                lines.append('        """Parse boolean value."""')
                lines.append("        if value is None:")
                lines.append("            return None")
                lines.append("        if isinstance(value, bool):")
                lines.append("            return value")
                lines.append("        if isinstance(value, str):")
                lines.append('            if value.lower() == "true":')
                lines.append("                return True")
                lines.append('            if value.lower() == "false":')
                lines.append("                return False")
                lines.append("        return bool(value)")
                lines.append("")

        return "\n".join(lines).rstrip()

    def _python_type(self, attr: Attribute) -> str:
        """
        Convert schema type to Python type using enhanced type mapping.

        Priority:
        1. enum_type - Enum reference
        2. object_ref - Nested model reference
        3. items_ref - Array of model references
        4. model_reference - Direct model type
        5. Standard type mapping

        Args:
            attr: Attribute definition

        Returns:
            Python type string
        """
        if attr.enum_type:
            return attr.enum_type

        # Check for object_ref (nested model)
        if attr.object_ref:
            return attr.object_ref

        # Check for array with items_ref
        if attr.type == "array" and attr.items_ref:
            return f"List[{attr.items_ref}]"

        # Check for direct model reference
        if hasattr(attr, "model_reference") and attr.model_reference:
            return attr.model_reference

        try:
            mapping = self.type_mapper.get_type_mapping(attr.type)
            return mapping.python_type
        except ValueError:
            # Fallback for unknown types
            logger.warning(
                f"Unknown type '{attr.type}' for attribute '{attr.name}', defaulting to str"
            )
            return "str"

    def _generate_field_definition(self, attr: Attribute, py_type: str) -> str:
        """
        Generate Pydantic Field definition with validation constraints.

        Handles default values from schema (Issue #43) and validation rules (Issue #44).

        Args:
            attr: Attribute definition
            py_type: Python type string

        Returns:
            Field definition string
        """
        field_args = []

        # Add default value (Issue #43: support schema-defined defaults)
        if attr.required:
            field_args.append("...")
        elif attr.default is not None:
            # Use schema-defined default value
            if isinstance(attr.default, str):
                # Escape quotes in string defaults
                escaped = attr.default.replace("\\", "\\\\").replace('"', '\\"')
                field_args.append(f'"{escaped}"')
            elif isinstance(attr.default, bool):
                # Python booleans are True/False
                field_args.append(str(attr.default))
            else:
                # Numbers and other types
                field_args.append(str(attr.default))
        else:
            field_args.append("None")

        # Add description
        if attr.description:
            field_args.append(f'description="{attr.description}"')

        # Add validation constraints if present
        if hasattr(attr, "validation") and attr.validation:
            try:
                constraints = self.type_mapper.get_validation_constraints(attr.validation)
                python_constraints = constraints.get("python", [])
                field_args.extend(python_constraints)
            except Exception as e:
                logger.warning(f"Failed to process validation constraints for {attr.name}: {e}")

        return f"Field({', '.join(field_args)})"

    def _generate_response_types(self, schema: Any) -> str:
        """
        Generate response wrapper types.

        Issue #78: Updated to match GraphQL response standardization:
        - All responses have envelope: code, success, message
        - Mutation responses have `item` (singular)
        - List responses have `items` (plural) and `next_token`
        - Get responses have `item` (singular)

        Args:
            schema: Schema object

        Returns:
            Response type definitions
        """
        lines = []
        lines.append("# Response Types")

        # Mutation response types (single item)
        lines.append(f"class {schema.name}CreateResponse(BaseModel):")
        lines.append(f'    """{schema.name} create response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    item: Optional[{schema.name}] = None")

        lines.append("")
        lines.append("")

        lines.append(f"class {schema.name}UpdateResponse(BaseModel):")
        lines.append(f'    """{schema.name} update response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    item: Optional[{schema.name}] = None")

        lines.append("")
        lines.append("")

        lines.append(f"class {schema.name}DeleteResponse(BaseModel):")
        lines.append(f'    """{schema.name} delete response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    item: Optional[{schema.name}] = None")

        lines.append("")
        lines.append("")

        lines.append(f"class {schema.name}DisableResponse(BaseModel):")
        lines.append(f'    """{schema.name} disable response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    item: Optional[{schema.name}] = None")

        lines.append("")
        lines.append("")

        # Get response type (single item)
        lines.append(f"class {schema.name}GetResponse(BaseModel):")
        lines.append(f'    """{schema.name} get response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    item: Optional[{schema.name}] = None")

        lines.append("")
        lines.append("")

        # List response type (multiple items with pagination)
        lines.append(f"class {schema.name}ListResponse(BaseModel):")
        lines.append(f'    """{schema.name} list response."""')
        lines.append("")
        lines.append("    code: int")
        lines.append("    success: bool")
        lines.append("    message: Optional[str] = None")
        lines.append(f"    items: Optional[List[{schema.name}]] = None")
        lines.append("    next_token: Optional[str] = None")

        return "\n".join(lines)

    # =========================================================================
    # GRAPHQL QUERY DEFINITION FILE GENERATION (Issue #79)
    # =========================================================================

    def _has_operations(self, schema: Any) -> bool:
        """
        Check if a schema has operations defined.

        Args:
            schema: Schema object

        Returns:
            True if schema has non-empty operations list or is a LambdaType, False otherwise
        """
        if isinstance(schema, LambdaType):
            return True
        if not hasattr(schema, "operations"):
            return False
        if schema.operations is None:
            return False
        return len(schema.operations) > 0

    def _generate_gql_attribute_fields(
        self,
        schema: Any,
        indent: int = 6,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL field selection for schema attributes.

        Args:
            schema: Schema object with attributes
            indent: Number of spaces for indentation
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Field selection string with proper indentation
        """
        lines = []
        prefix = " " * indent

        for attr in schema.attributes:
            if attr.object_ref and all_schemas:
                nested_schema = all_schemas.get(attr.object_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    lines.append(f"{prefix}{attr.name}")
            elif attr.items_ref and all_schemas:
                nested_schema = all_schemas.get(attr.items_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    lines.append(f"{prefix}{attr.name}")
            else:
                lines.append(f"{prefix}{attr.name}")

        return "\n".join(lines)

    def _generate_gql_response_fields(
        self,
        schema: Any,
        operation: Any = None,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL response field selection for an operation.

        v0.19.0 format:
        - All responses include envelope: code, success, message
        - Mutations/Get: singular `item` field
        - List: plural `items` field + nextToken

        Args:
            schema: Schema object
            operation: Operation object (required for TableSchema)
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Response field selection string
        """
        from ..core.models import classify_operation_response_type

        if isinstance(schema, TableSchema):
            if operation is not None:
                response_type = classify_operation_response_type(operation)
            else:
                response_type = "list"

            attr_fields = self._generate_gql_attribute_fields(
                schema, indent=8, all_schemas=all_schemas
            )

            envelope = """      code
      success
      message"""

            if response_type == "singular":
                return f"""{envelope}
      item {{
{attr_fields}
      }}"""
            else:
                return f"""{envelope}
      items {{
{attr_fields}
      }}
      nextToken"""
        else:
            return self._generate_gql_attribute_fields(schema, indent=6, all_schemas=all_schemas)

    def _generate_gql_operation_constant(
        self,
        schema: Any,
        operation: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a single GraphQL operation constant for Python.

        Args:
            schema: Schema object the operation belongs to
            operation: Operation object with name, type, field
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Python constant string with GraphQL operation
        """
        op_type = "query" if operation.type == "Query" else "mutation"
        response_fields = self._generate_gql_response_fields(schema, operation, all_schemas)

        # Use triple-quoted string for Python
        return f'''{operation.field.upper()} = """
  {op_type} {operation.field}($input: {operation.field}Input!) {{
    {operation.field}(input: $input) {{
{response_fields}
    }}
  }}
"""'''

    def _generate_lambda_gql_operation_constant(
        self,
        schema: LambdaType,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a GraphQL operation constant for a Lambda type.

        Args:
            schema: LambdaType schema object
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Python constant string with GraphQL operation
        """
        op_type = "query" if schema.operation == "query" else "mutation"
        op_name = schema.name

        # Filter to only output attributes (not input_only)
        output_attrs = [
            attr for attr in schema.attributes if not getattr(attr, "input_only", False)
        ]

        # Generate field selection
        lines = []
        for attr in output_attrs:
            lines.append(f"      {attr.name}")
        fields = "\n".join(lines)

        return f'''{op_name.upper()} = """
  {op_type} {op_name}($input: {op_name}Input!) {{
    {op_name}(input: $input) {{
{fields}
    }}
  }}
"""'''

    def _generate_gql_query_file(
        self,
        schema: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a complete GraphQL query definition file for Python.

        Args:
            schema: Schema object with operations or LambdaType
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Complete Python file content with GraphQL operation constants
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("python").rstrip())
        lines.append(f'"""GraphQL operations for {schema.name}."""')
        lines.append("")

        if isinstance(schema, LambdaType):
            lines.append(self._generate_lambda_gql_operation_constant(schema, all_schemas))
            lines.append("")
        else:
            for operation in schema.operations:
                lines.append(self._generate_gql_operation_constant(schema, operation, all_schemas))
                lines.append("")

        return "\n".join(lines)

    def _generate_graphql_queries(
        self,
        schemas: Dict[str, Any],
        output_config,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Generate Python GraphQL query definition files for all schemas with operations.

        Args:
            schemas: Dictionary of schema objects for this target
            output_config: OutputConfig for this target
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Number of query files generated
        """
        # Skip if graphql_queries_subdir not configured
        if not output_config.graphql_queries_subdir:
            return 0

        generated_files = []

        for name, schema in schemas.items():
            if self._has_operations(schema):
                content = self._generate_gql_query_file(schema, all_schemas or schemas)
                filename = f"{to_snake_case(schema.name)}_graphql"
                output_path = output_config.graphql_queries_path(f"{filename}.py")
                if output_path:
                    self._write_file(output_path, content)
                    generated_files.append((filename, schema.name))

        # Generate __init__.py barrel file if any files were generated
        if generated_files:
            barrel_content = self._generate_gql_queries_barrel(generated_files)
            barrel_path = output_config.graphql_queries_path("__init__.py")
            if barrel_path:
                self._write_file(barrel_path, barrel_content)

        return len(generated_files)

    def _generate_gql_queries_barrel(self, generated_files: list) -> str:
        """
        Generate barrel file (__init__.py) re-exporting all GraphQL query files.

        Args:
            generated_files: List of (filename, schema_name) tuples

        Returns:
            Complete barrel file content
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("python").rstrip())
        lines.append('"""')
        lines.append("GraphQL operations barrel file.")
        lines.append("Re-exports all GraphQL query definitions for convenient imports.")
        lines.append('"""')
        lines.append("")

        # Export all entity files
        for filename, schema_name in sorted(generated_files, key=lambda x: x[0]):
            # Export the uppercase constant
            lines.append(f"from .{filename} import *  # noqa: F401, F403")

        return "\n".join(lines)
