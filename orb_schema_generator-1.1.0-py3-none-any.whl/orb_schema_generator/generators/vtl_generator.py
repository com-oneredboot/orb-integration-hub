"""VTL resolver template generator for AWS AppSync DynamoDB operations."""

from pathlib import Path
from typing import Any, Dict, List, TYPE_CHECKING
import logging

from .base import BaseGenerator
from ..core.models import TableSchema
from ..utils.case_conversion import to_pascal_case
from ..utils.vtl_builder import VTLTemplateBuilder
from ..utils.console import success
from ..utils.glob_matcher import matches_any_pattern

if TYPE_CHECKING:
    from ..core.config import ApiDefinition

logger = logging.getLogger(__name__)


class VTLGenerator(BaseGenerator):
    """Generates VTL resolver templates for AppSync DynamoDB direct resolvers."""

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate VTL templates for all DynamoDB schemas.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info("Generating VTL resolver templates...")

        template_count = 0
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema) and schema.type == "dynamodb":
                count = self._generate_schema_templates(schema)
                template_count += count

        logger.info(success(f"Generated {template_count} VTL resolver templates"))

    # =========================================================================
    # MULTI-API GENERATION METHODS (Issue #83)
    # =========================================================================

    def generate_for_api(self, schemas: Dict[str, Any], api_def: "ApiDefinition") -> int:
        """Generate VTL templates for a specific API definition.

        Filters schemas to only those in api_def.tables and filters
        operations to only those matching api_def.include_operations patterns.

        Args:
            schemas: Dictionary of all schema objects
            api_def: API definition with tables and include_operations filters

        Returns:
            Number of templates generated
        """
        logger.info(
            f"Generating VTL resolvers for API '{api_def.name}' "
            f"with tables: {', '.join(api_def.tables)}"
        )

        template_count = 0
        for name, schema in schemas.items():
            # Filter by tables list
            if name not in api_def.tables:
                continue

            if isinstance(schema, TableSchema) and schema.type == "dynamodb":
                count = self._generate_schema_templates_filtered(
                    schema, api_def.include_operations, api_def.resolvers_output
                )
                template_count += count

        return template_count

    def generate_multi_api(self, schemas: Dict[str, Any]) -> None:
        """Generate VTL templates for all API definitions.

        This method is called when api_definitions are configured.
        Each API definition gets its own resolver directory.

        Args:
            schemas: Dictionary of all schema objects
        """
        from ..core.validators import validate_all_api_definitions

        api_definitions = self.config.api_definitions
        if not api_definitions:
            logger.warning("No API definitions configured for multi-API generation")
            return

        # Validate all API definitions against available schemas
        validate_all_api_definitions(api_definitions, schemas)

        total_count = 0
        for api_def in api_definitions:
            count = self.generate_for_api(schemas, api_def)
            total_count += count

        logger.info(
            success(
                f"Generated {total_count} VTL resolver templates for {len(api_definitions)} APIs"
            )
        )

    def _generate_schema_templates_filtered(
        self,
        schema: TableSchema,
        include_patterns: List[str],
        output_dir: Path,
    ) -> int:
        """Generate VTL templates for a schema with operation filtering.

        Args:
            schema: Table schema to generate templates for
            include_patterns: Glob patterns for operations to include
            output_dir: Output directory for resolver files

        Returns:
            Number of templates generated
        """
        count = 0
        operations = self._get_vtl_operations(schema)

        for operation in operations:
            # Filter by include_operations patterns
            op_field = f"{schema.name.lower()}{operation['name']}"
            if not matches_any_pattern(op_field, include_patterns):
                continue

            # Generate request template
            request_content = self._generate_request_template(schema, operation)
            request_path = self._get_output_path_for_api(
                schema.name, operation, "request", output_dir
            )
            self._write_file(request_path, request_content)
            count += 1

            # Generate response template
            response_content = self._generate_response_template(schema, operation)
            response_path = self._get_output_path_for_api(
                schema.name, operation, "response", output_dir
            )
            self._write_file(response_path, response_content)
            count += 1

        logger.debug(f"Generated {count} templates for {schema.name}")
        return count

    def _get_output_path_for_api(
        self,
        schema_name: str,
        operation: Dict[str, Any],
        template_type: str,
        output_dir: Path,
    ) -> Path:
        """Get output path for a VTL template in multi-API mode.

        Args:
            schema_name: Name of the schema
            operation: Operation definition
            template_type: 'request' or 'response'
            output_dir: Base output directory for this API

        Returns:
            Full path to the template file
        """
        op_name = operation.get("name", "")
        filename = f"{schema_name}{op_name}.{template_type}.vtl"
        return output_dir / filename

    def _generate_schema_templates(self, schema: TableSchema) -> int:
        """
        Generate all VTL templates for a single schema.

        Args:
            schema: Table schema to generate templates for

        Returns:
            Number of templates generated
        """
        count = 0
        operations = self._get_vtl_operations(schema)

        for operation in operations:
            # Generate request template
            request_content = self._generate_request_template(schema, operation)
            request_path = self._get_output_path(schema.name, operation, "request")
            self._write_file(request_path, request_content)
            count += 1

            # Generate response template
            response_content = self._generate_response_template(schema, operation)
            response_path = self._get_output_path(schema.name, operation, "response")
            self._write_file(response_path, response_content)
            count += 1

        logger.debug(f"Generated {count} templates for {schema.name}")
        return count

    def _get_vtl_operations(self, schema: TableSchema) -> List[Dict[str, Any]]:
        """
        Get VTL-relevant operations from schema.operations.

        This method uses the operations populated by OperationBuilder (the single source
        of truth for operations) instead of independently deriving operations from
        secondary_indexes. This follows the DRY principle and ensures VTL resolvers
        match the GraphQL schema operations.

        Issue #77: The previous implementation incorrectly included sort keys in
        partition-only GSI queries because it built its own operation list.

        Args:
            schema: TableSchema with operations populated by OperationBuilder

        Returns:
            List of operation dictionaries for VTL generation
        """
        vtl_operations = []

        # Check if schema has operations from OperationBuilder
        if hasattr(schema, "operations") and schema.operations:
            for op in schema.operations:
                # Only include operations with DynamoDB operations
                if not op.dynamodb_op:
                    continue

                vtl_operations.append(
                    {
                        "name": op.name,
                        "type": op.type,  # Issue #81: Use operation type from OperationBuilder
                        "dynamodb_op": op.dynamodb_op,
                        "index_name": op.index_name,
                        "index_partition": op.index_partition,
                        # index_sort will be None for partition-only queries (Issue #77)
                        "index_sort": op.index_sort if op.index_sort else None,
                    }
                )
        else:
            # Fallback for schemas without operations (backward compatibility)
            # This handles cases where schema.operations is not populated (e.g., in tests)
            logger.debug(f"Schema {schema.name} has no operations, using fallback")
            vtl_operations = [
                {"name": "Create", "type": "Mutation", "dynamodb_op": "PutItem"},
                {"name": "Update", "type": "Mutation", "dynamodb_op": "UpdateItem"},
                {"name": "Delete", "type": "Mutation", "dynamodb_op": "DeleteItem"},
                {"name": "Disable", "type": "Mutation", "dynamodb_op": "UpdateItem"},
                {"name": "Get", "type": "Query", "dynamodb_op": "GetItem"},
            ]

            # Add list operations for secondary indexes (fallback for backward compatibility)
            if schema.secondary_indexes:
                for index in schema.secondary_indexes:
                    if index.get("type") == "GSI":
                        partition = index.get("partition", "")
                        index_name = index.get("name", "")
                        op_name = f"ListBy{self._to_pascal_case(partition)}"
                        # Issue #77: In fallback mode, only create partition-only queries
                        # The partition-and-sort queries should come from schema.operations
                        # which is populated by OperationBuilder
                        vtl_operations.append(
                            {
                                "name": op_name,
                                "type": "Query",  # Issue #81: Explicit type, no defaults
                                "dynamodb_op": "Query",
                                "index_name": index_name,
                                "index_partition": partition,
                                "index_sort": None,  # Always None for fallback partition-only queries
                            }
                        )

        return vtl_operations

    def _generate_request_template(self, schema: TableSchema, operation: Dict[str, Any]) -> str:
        """
        Generate request mapping template for a specific operation.

        Args:
            schema: Table schema
            operation: Operation definition

        Returns:
            VTL request template content
        """
        header = self._get_file_header("vtl")
        dynamodb_op = operation.get("dynamodb_op", "")

        if dynamodb_op == "PutItem":
            content = self._generate_put_item_request(schema)
        elif dynamodb_op == "UpdateItem":
            content = self._generate_update_item_request(schema)
        elif dynamodb_op == "DeleteItem":
            content = self._generate_delete_item_request(schema)
        elif dynamodb_op == "GetItem":
            content = self._generate_get_item_request(schema)
        elif dynamodb_op == "Query":
            content = self._generate_query_request(schema, operation)
        else:
            logger.warning(f"Unknown DynamoDB operation: {dynamodb_op}")
            return ""

        return header + content

    def _generate_response_template(self, schema: TableSchema, operation: Dict[str, Any]) -> str:
        """
        Generate response mapping template for a specific operation.

        Args:
            schema: Table schema
            operation: Operation definition

        Returns:
            VTL response template content
        """
        header = self._get_file_header("vtl")
        dynamodb_op = operation.get("dynamodb_op", "")

        if dynamodb_op == "Query":
            content = self._generate_list_response_template()
        else:
            content = self._generate_standard_response_template()

        return header + content

    def _generate_put_item_request(self, schema: TableSchema) -> str:
        """Generate PutItem request template."""
        builder = VTLTemplateBuilder()

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"PutItem"')
        builder.add_dynamodb_key(schema.partition_key, schema.sort_key)
        builder.add_vtl_property(
            "attributeValues", "$util.dynamodb.toMapValuesJson($ctx.args.input)", is_last=True
        )
        builder.add_vtl_json_end()

        return builder.build()

    def _generate_update_item_request(self, schema: TableSchema) -> str:
        """Generate UpdateItem request template."""
        builder = VTLTemplateBuilder()
        pk = schema.partition_key
        sk = schema.sort_key if schema.sort_key and schema.sort_key != "None" else None

        # Set up variables for dynamic update expression
        builder.add_set("input", "$ctx.args.input")
        builder.add_set("updateExpression", '""')
        builder.add_set("expressionNames", "{}")
        builder.add_set("expressionValues", "{}")
        builder.add_set("separator", '""')
        builder.add_line()

        # Check if updatedAt field exists and get its type (Issue #76)
        updated_at_type = self._get_field_type(schema, "updatedAt")
        if updated_at_type is not None:
            timestamp_fn = self._get_timestamp_vtl_function(updated_at_type)
            builder.add_line("## Automatically set updatedAt to current timestamp")
            builder.add_set("updateExpression", '"updatedAt = :updatedAt"')
            builder.add_line(
                f'$!{{expressionValues.put(":updatedAt", $util.dynamodb.toDynamoDB({timestamp_fn}))}}'
            )
            builder.add_set("separator", '", "')
            builder.add_line()

        # Build dynamic update expression excluding keys
        builder.add_line("## Build update expression for non-key attributes")
        builder.add_line("#foreach($entry in $input.entrySet())")
        builder.indent()

        # Build condition to exclude key attributes
        key_conditions = [f'$entry.key != "{pk}"']
        if sk:
            key_conditions.append(f'$entry.key != "{sk}"')
        key_conditions.append('$entry.key != "updatedAt"')
        condition = " && ".join(key_conditions)

        builder.add_line(f"#if({condition})")
        builder.indent()
        builder.add_set(
            "updateExpression", '"$updateExpression$separator#$entry.key = :$entry.key"'
        )
        builder.add_line('$!{expressionNames.put("#$entry.key", "$entry.key")}')
        builder.add_line(
            '$!{expressionValues.put(":$entry.key", $util.dynamodb.toDynamoDB($entry.value))}'
        )
        builder.add_set("separator", '", "')
        builder.dedent()
        builder.add_line("#end")
        builder.dedent()
        builder.add_line("#end")
        builder.add_line()

        # Build the request object
        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"UpdateItem"')
        builder.add_dynamodb_key(pk, sk)
        builder.add_line('"update": {')
        builder.indent()
        builder.add_vtl_property("expression", '"SET $updateExpression"')
        builder.add_vtl_property("expressionNames", "$util.toJson($expressionNames)")
        builder.add_vtl_property(
            "expressionValues", "$util.toJson($expressionValues)", is_last=True
        )
        builder.dedent()
        builder.add_line("}")
        builder.add_vtl_json_end()

        return builder.build()

    def _generate_delete_item_request(self, schema: TableSchema) -> str:
        """Generate DeleteItem request template."""
        builder = VTLTemplateBuilder()
        pk = schema.partition_key
        sk = schema.sort_key if schema.sort_key and schema.sort_key != "None" else None

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"DeleteItem"')

        # Build key object (last property, no trailing comma)
        builder.add_line('"key": {')
        builder.indent()
        pk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{pk})"
        if sk:
            builder.add_vtl_property(pk, pk_value)
            sk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{sk})"
            builder.add_vtl_property(sk, sk_value, is_last=True)
        else:
            builder.add_vtl_property(pk, pk_value, is_last=True)
        builder.dedent()
        builder.add_line("}")

        builder.add_vtl_json_end()

        return builder.build()

    def _generate_get_item_request(self, schema: TableSchema) -> str:
        """Generate GetItem request template."""
        builder = VTLTemplateBuilder()
        pk = schema.partition_key
        sk = schema.sort_key if schema.sort_key and schema.sort_key != "None" else None

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"GetItem"')

        # Build key object (last property, no trailing comma)
        builder.add_line('"key": {')
        builder.indent()
        pk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{pk})"
        if sk:
            builder.add_vtl_property(pk, pk_value)
            sk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{sk})"
            builder.add_vtl_property(sk, sk_value, is_last=True)
        else:
            builder.add_vtl_property(pk, pk_value, is_last=True)
        builder.dedent()
        builder.add_line("}")

        builder.add_vtl_json_end()

        return builder.build()

    def _generate_query_request(self, schema: TableSchema, operation: Dict[str, Any]) -> str:
        """Generate Query request template with optional index and pagination."""
        builder = VTLTemplateBuilder()

        # Determine which key to use (index or primary)
        index_name = operation.get("index_name")
        pk = operation.get("index_partition", schema.partition_key)
        sk = operation.get("index_sort")
        if not sk and not index_name:
            # For primary table queries, use sort key if defined
            sk = schema.sort_key if schema.sort_key and schema.sort_key != "None" else None

        builder.add_vtl_json_start()
        builder.add_vtl_property("version", '"2018-05-29"')
        builder.add_vtl_property("operation", '"Query"')

        # Add index if specified
        if index_name:
            builder.add_vtl_property("index", f'"{index_name}"')

        # Build query expression
        builder.add_line('"query": {')
        builder.indent()

        # Build expression based on keys
        if sk:
            expression = f"{pk} = :{pk} AND {sk} = :{sk}"
        else:
            expression = f"{pk} = :{pk}"
        builder.add_vtl_property("expression", f'"{expression}"')

        # Build expression values
        builder.add_line('"expressionValues": {')
        builder.indent()
        pk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{pk})"
        if sk:
            builder.add_vtl_property(f":{pk}", pk_value)
            sk_value = f"$util.dynamodb.toDynamoDBJson($ctx.args.input.{sk})"
            builder.add_vtl_property(f":{sk}", sk_value, is_last=True)
        else:
            builder.add_vtl_property(f":{pk}", pk_value, is_last=True)
        builder.dedent()
        builder.add_line("}")

        builder.dedent()
        builder.add_line("}")

        # Add pagination support with conditionals
        builder.add_line("#if($ctx.args.limit)")
        builder.add_line('  ,"limit": $ctx.args.limit')
        builder.add_line("#end")
        builder.add_line("#if($ctx.args.nextToken)")
        builder.add_line('  ,"nextToken": "$ctx.args.nextToken"')
        builder.add_line("#end")

        builder.add_vtl_json_end()

        return builder.build()

    def _generate_standard_response_template(self) -> str:
        """Generate standard response template for single-item operations.

        Returns response with envelope: code, success, message, item.
        Used for mutations (Create, Update, Delete) and Get operations.
        """
        builder = VTLTemplateBuilder()

        # Error handling
        builder.add_line("#if($ctx.error)")
        builder.indent()
        builder.add_line("$util.error($ctx.error.message, $ctx.error.type)")
        builder.dedent()
        builder.add_line("#else")
        builder.indent()

        # Return envelope with single item
        builder.add_vtl_json_start()
        builder.add_vtl_property("code", "200")
        builder.add_vtl_property("success", "true")
        builder.add_vtl_property("message", "null")
        builder.add_vtl_property("item", "$util.toJson($ctx.result)", is_last=True)
        builder.add_vtl_json_end()

        builder.dedent()
        builder.add_line("#end")

        return builder.build()

    def _generate_list_response_template(self) -> str:
        """Generate list response template with pagination support.

        Returns response with envelope: code, success, message, items, nextToken.
        Used for List operations.
        """
        builder = VTLTemplateBuilder()

        # Error handling
        builder.add_line("#if($ctx.error)")
        builder.indent()
        builder.add_line("$util.error($ctx.error.message, $ctx.error.type)")
        builder.dedent()
        builder.add_line("#else")
        builder.indent()

        # Return envelope with items and pagination
        builder.add_vtl_json_start()
        builder.add_vtl_property("code", "200")
        builder.add_vtl_property("success", "true")
        builder.add_vtl_property("message", "null")
        builder.add_vtl_property("items", "$util.toJson($ctx.result.items)")

        # Handle nextToken - encode LastEvaluatedKey if present
        next_token_value = builder.add_inline_conditional(
            "$ctx.result.nextToken", '"$ctx.result.nextToken"', "null"
        )
        builder.add_vtl_property("nextToken", next_token_value, is_last=True)
        builder.add_vtl_json_end()

        builder.dedent()
        builder.add_line("#end")

        return builder.build()

    def _get_output_path(
        self, schema_name: str, operation: Dict[str, Any], template_type: str
    ) -> Path:
        """
        Get output file path for a VTL template.

        Args:
            schema_name: Name of the schema
            operation: Operation definition with 'type' and 'name' keys
            template_type: 'request' or 'response'

        Returns:
            Path to output file

        Raises:
            KeyError: If operation is missing required 'type' key
        """
        type_name = self._get_operation_type(operation)
        field_name = self._get_field_name(schema_name, operation["name"])
        filename = f"{type_name}.{field_name}.{template_type}.vtl"

        output_dir = self._get_resolver_output_dir()
        return output_dir / filename

    def _get_resolver_output_dir(self) -> Path:
        """Get the resolver output directory from config."""
        # Use custom path if configured, otherwise default
        if hasattr(self.config, "appsync") and self.config.appsync:
            if self.config.appsync.resolver_output_dir:
                return Path(self.config.appsync.resolver_output_dir)

        # Default to CDK output dir / appsync / resolvers
        return Path(self.config.cdk_output_dir) / "appsync" / "resolvers"

    def _get_operation_type(self, operation: Dict[str, Any]) -> str:
        """
        Return 'Mutation' or 'Query' from the operation's type field.

        Issue #81: Uses operation type from OperationBuilder instead of
        hardcoded mapping. This ensures VTL file prefixes match the GraphQL
        schema exactly.

        Args:
            operation: Operation dictionary with 'type' key

        Returns:
            'Mutation' or 'Query'

        Raises:
            KeyError: If operation is missing 'type' key (no default values)
        """
        if "type" not in operation:
            raise KeyError(
                f"Operation '{operation.get('name', 'unknown')}' missing required 'type' key. "
                "Operations must have explicit type from OperationBuilder."
            )
        return operation["type"]

    def _get_field_name(self, schema_name: str, operation_name: str) -> str:
        """
        Generate GraphQL field name for operation.

        Args:
            schema_name: Name of the schema
            operation_name: Name of the operation

        Returns:
            GraphQL field name (e.g., 'UsersCreate')
        """
        return f"{schema_name}{operation_name}"

    def _to_pascal_case(self, text: str) -> str:
        """Convert text to PascalCase, preserving acronyms."""
        return to_pascal_case(text)

    def _get_field_type(self, schema: TableSchema, field_name: str) -> str | None:
        """
        Look up the type of a field from the schema's attributes.

        Args:
            schema: TableSchema containing attribute definitions
            field_name: Name of the field to look up

        Returns:
            Field type string (e.g., 'timestamp', 'datetime') or None if not found
        """
        if not schema.attributes:
            return None
        for attr in schema.attributes:
            if attr.name == field_name:
                return attr.type
        return None

    def _get_timestamp_vtl_function(self, field_type: str | None) -> str:
        """
        Get the appropriate VTL timestamp function based on field type.

        Args:
            field_type: Schema field type ('timestamp', 'datetime', or None)

        Returns:
            VTL function string for generating timestamps
        """
        if field_type == "datetime":
            return "$util.time.nowISO8601()"
        # Default to epoch seconds for 'timestamp' type or backward compatibility
        return "$util.time.nowEpochSeconds()"
