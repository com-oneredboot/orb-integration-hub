"""Dart/Flutter model generator."""

from typing import Dict, Any, Optional
import logging

from .base import BaseGenerator
from ..core.models import TableSchema, StandardType, LambdaType, RegistryType, Attribute
from ..core.config import DartConfig
from ..utils.type_mapping import EnhancedTypeMapper
from ..utils.case_conversion import (
    to_snake_case,
    to_pascal_case,
    to_camel_case,
    to_dart_enum_member,
)
from ..utils.console import success

logger = logging.getLogger(__name__)


class DartGenerator(BaseGenerator):
    """Generates Dart model classes from schemas."""

    def __init__(self, config, dart_config: Optional[DartConfig] = None):
        """
        Initialize the Dart generator with configuration.

        Args:
            config: Generator configuration
            dart_config: Dart-specific configuration options
        """
        super().__init__(config)
        self.type_mapper = EnhancedTypeMapper()
        self.dart_config = dart_config or DartConfig()
        # Initialize counter from config for user-configurable starting typeId
        self._hive_type_id_counter = self.dart_config.hive_type_id_start

    def _dart_class_name(self, name: str) -> str:
        """
        Get Dart class name, preserving acronyms.

        Dart convention: Preserve acronyms in class names (GPSPoint, not GpsPoint).
        Uses shared to_pascal_case() which handles both conversion and acronym preservation.

        Args:
            name: Schema name

        Returns:
            Dart class name
        """
        return to_pascal_case(name)

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate Dart models and enums for all schemas.

        Handles all schema types in a unified manner:
        - RegistryType → Dart enhanced enum with toJson()/fromJson()
        - StandardType, TableSchema, LambdaType → Dart classes

        Uses target-based routing to write files to the correct output directories.
        Generates barrel files when barrel_file is True.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        logger.info(f"Generating Dart code for {len(schemas)} schemas...")

        # Group schemas by target
        schemas_by_target = self._group_by_target(schemas)

        model_count = 0
        enum_count = 0
        query_count = 0

        for target, target_schemas in schemas_by_target.items():
            # Get output config for this target
            output_config = self.config.get_target_config("dart", target)
            if not output_config:
                # No fallback - missing config is a configuration error
                from ..core.models import ConfigurationError

                raise ConfigurationError(
                    f"No Dart output config for target '{target}'. "
                    f"Add it to output.dart.targets in schema-generator.yml"
                )

            # Track generated files for barrel file generation
            generated_models: list[str] = []  # filenames (without extension)
            generated_enums: list[str] = []  # filenames (without extension)

            for name, schema in target_schemas.items():
                if isinstance(schema, (TableSchema, StandardType, LambdaType)):
                    content = self._generate_model(schema, output_config)
                    filename = to_snake_case(name)
                    output_path = output_config.model_path(filename, "dart")
                    self._write_file(output_path, content)
                    model_count += 1
                    generated_models.append(filename)
                elif isinstance(schema, RegistryType):
                    content = self._generate_registry_enum(schema)
                    filename = to_snake_case(name)
                    output_path = output_config.enum_path(filename, "dart")
                    self._write_file(output_path, content)
                    enum_count += 1
                    generated_enums.append(filename)

            # Generate barrel files if enabled
            if output_config.barrel_file:
                if generated_models:
                    barrel_content = self._generate_barrel_file(generated_models, "models")
                    barrel_path = output_config.barrel_path("model", "models")
                    self._write_file(barrel_path, barrel_content)
                    logger.debug(f"Generated {barrel_path}")

                if generated_enums:
                    barrel_content = self._generate_barrel_file(generated_enums, "enums")
                    barrel_path = output_config.barrel_path("enum", "enums")
                    self._write_file(barrel_path, barrel_content)
                    logger.debug(f"Generated {barrel_path}")

            # Generate GraphQL utility file (Issue #71)
            utils_content = self._generate_graphql_utils()
            utils_path = output_config.base_dir / "graphql_utils.dart"
            self._write_file(utils_path, utils_content)

            # Generate GraphQL query definition files (Issue #79)
            query_count += self._generate_graphql_queries(
                target_schemas, output_config, all_schemas=schemas
            )

        logger.info(success(f"Generated {model_count} Dart model files"))
        if enum_count > 0:
            logger.info(success(f"Generated {enum_count} Dart enum files"))
        if query_count > 0:
            logger.info(success(f"Generated {query_count} Dart GraphQL query files"))

    def _generate_barrel_file(self, files: list[str], barrel_name: str) -> str:
        """Generate Dart barrel file content.

        Creates a barrel file that exports all generated files from the directory,
        making imports cleaner for consumers.

        Args:
            files: List of filenames (without extension) for generated files
            barrel_name: Name for the barrel file (e.g., "models", "enums")

        Returns:
            Barrel file content with export statements
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())

        # Add doc comment
        lines.append(f"/// Barrel file for {barrel_name}.")
        lines.append(f"/// Export all {barrel_name} from this directory.")
        lines.append("")

        # Generate export statements
        for filename in sorted(files):
            lines.append(f"export '{filename}.dart';")

        return "\n".join(lines)

    def _generate_registry_enum(self, registry: RegistryType) -> str:
        """
        Generate Dart enum from RegistryType with JSON serialization.

        Args:
            registry: RegistryType schema object

        Returns:
            Complete Dart enum file content with toJson/fromJson
        """
        lines = []
        enum_name = self._dart_class_name(registry.name)

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())

        # Header comment
        if registry.description:
            lines.append(f"/// {registry.description}")
        else:
            lines.append(f"/// Generated Dart enum for {enum_name}")
        lines.append("")

        # Add Hive import if enabled
        if self.dart_config.hive:
            lines.append("import 'package:hive/hive.dart';")
            lines.append("")
            file_name = to_snake_case(registry.name)
            lines.append(f"part '{file_name}.g.dart';")
            lines.append("")

        # Add Hive type annotation if enabled
        if self.dart_config.hive:
            type_id = self._get_next_hive_type_id()
            lines.append(f"@HiveType(typeId: {type_id})")

        # Enum declaration with enhanced enum syntax for JSON serialization
        lines.append(f"enum {enum_name} {{")

        # Generate enum values with their JSON string values
        items_list = list(registry.items.items())
        for i, (key, item_data) in enumerate(items_list):
            # Convert enum key to camelCase for Dart enum value
            dart_value = to_dart_enum_member(key)

            # Get the JSON value (original value from schema)
            json_value = item_data.get("value", key.lower()) if isinstance(item_data, dict) else key

            # Get description if available
            description = item_data.get("description") if isinstance(item_data, dict) else None

            if description:
                lines.append(f"  /// {description}")

            if self.dart_config.hive:
                lines.append(f"  @HiveField({i})")

            # Use enhanced enum syntax with value parameter
            comma = "," if i < len(items_list) - 1 else ";"
            lines.append(f"  {dart_value}('{json_value}'){comma}")

        lines.append("")

        # Add value field and constructor
        lines.append(f"  const {enum_name}(this.value);")
        lines.append("")
        lines.append("  /// The JSON value for this enum")
        lines.append("  final String value;")
        lines.append("")

        # Add toJson method
        lines.append("  /// Converts this enum to its JSON string value")
        lines.append("  String toJson() => value;")
        lines.append("")

        # Add fromJson static method
        lines.append(f"  /// Creates an {enum_name} from a JSON string value")
        lines.append(f"  static {enum_name} fromJson(String json) {{")
        lines.append(f"    return {enum_name}.values.firstWhere(")
        lines.append("      (e) => e.value == json,")
        lines.append(
            f"      orElse: () => throw ArgumentError('Unknown {enum_name} value: $json'),"
        )
        lines.append("    );")
        lines.append("  }")

        lines.append("}")

        return "\n".join(lines)

    def _generate_model(self, schema: Any, output_config=None) -> str:
        """
        Generate complete Dart model file.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to dart_output)

        Returns:
            Complete Dart model file content
        """
        if output_config is None:
            output_config = self.config.dart_output

        parts = []
        parts.append(self._generate_imports(schema, output_config))
        parts.append(self._generate_class(schema))

        return "\n\n".join(filter(None, parts))

    def _generate_imports(self, schema: Any, output_config=None) -> str:
        """
        Generate import statements based on options.

        Args:
            schema: Schema object
            output_config: OutputConfig for this target (optional, defaults to dart_output)

        Returns:
            Import statements
        """
        if output_config is None:
            output_config = self.config.dart_output

        lines = []
        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())
        lines.append(f"/// Generated Dart model for {schema.name}")
        lines.append("")

        # Collect enum and model imports from attributes (Issue #16, #18 fix)
        enum_imports = set()
        model_imports = set()
        for attr in schema.attributes:
            if attr.enum_type:
                enum_imports.add(attr.enum_type)
            # Collect model imports from items_ref (array of models)
            if attr.items_ref:
                model_imports.add(attr.items_ref)
            # Collect model imports from object_ref (nested model)
            if attr.object_ref:
                model_imports.add(attr.object_ref)
            # Collect model imports from direct model reference
            if hasattr(attr, "model_reference") and attr.model_reference:
                model_imports.add(attr.model_reference)

        # Add Hive import if enabled
        if self.dart_config.hive:
            lines.append("import 'package:hive/hive.dart';")

        # Add Equatable import if enabled
        if self.dart_config.equatable:
            lines.append("import 'package:equatable/equatable.dart';")

        # Add enum imports (Issue #19 fix: use relative paths)
        if enum_imports:
            lines.append("")
            rel_path = output_config.relative_import_path("model", "enum")
            for enum_name in sorted(enum_imports):
                # Use snake_case for Dart file names
                file_name = to_snake_case(enum_name)
                lines.append(f"import '{rel_path}{file_name}.dart';")

        # Add model imports (Issue #18, #19 fix: use relative paths)
        if model_imports:
            if not enum_imports:
                lines.append("")
            rel_path = output_config.relative_import_path("model", "model")
            for model_name in sorted(model_imports):
                # Use snake_case for Dart file names
                file_name = to_snake_case(model_name)
                lines.append(f"import '{rel_path}{file_name}.dart';")

        # Add part directive for Hive generated code
        if self.dart_config.hive:
            file_name = to_snake_case(schema.name)
            lines.append("")
            lines.append(f"part '{file_name}.g.dart';")

        return "\n".join(lines)

    def _generate_class(self, schema: Any) -> str:
        """
        Generate the Dart class.

        Args:
            schema: Schema object

        Returns:
            Class definition
        """
        lines = []
        class_name = self._dart_class_name(schema.name)

        # Add Hive type annotation if enabled
        if self.dart_config.hive:
            type_id = self._get_next_hive_type_id()
            lines.append(f"@HiveType(typeId: {type_id})")

        # Class declaration
        if self.dart_config.equatable:
            lines.append(f"class {class_name} extends Equatable {{")
        else:
            lines.append(f"class {class_name} {{")

        # Fields
        lines.append(self._generate_fields(schema))

        # Constructor
        lines.append("")
        lines.append(self._generate_constructor(schema))

        # fromJson factory
        lines.append("")
        lines.append(self._generate_from_json(schema))

        # toJson method
        lines.append("")
        lines.append(self._generate_to_json(schema))

        # copyWith method
        lines.append("")
        lines.append(self._generate_copy_with(schema))

        # toString method
        lines.append("")
        lines.append(self._generate_to_string(schema))

        # Equatable props if enabled
        if self.dart_config.equatable:
            lines.append("")
            lines.append(self._generate_props(schema))

        lines.append("}")

        return "\n".join(lines)

    def _generate_fields(self, schema: Any) -> str:
        """
        Generate field declarations with optional Hive annotations.

        Args:
            schema: Schema object

        Returns:
            Field declarations
        """
        lines = []
        hive_field_index = 0

        for attr in schema.attributes:
            dart_type = self._dart_type(attr)

            # Add Hive field annotation if enabled
            if self.dart_config.hive:
                lines.append(f"  @HiveField({hive_field_index})")
                hive_field_index += 1

            # Generate field with proper nullability (Dart uses camelCase for fields)
            field_name = to_camel_case(attr.name)
            if self.dart_config.immutable:
                if attr.required:
                    lines.append(f"  final {dart_type} {field_name};")
                else:
                    lines.append(f"  final {dart_type}? {field_name};")
            else:
                if attr.required:
                    lines.append(f"  {dart_type} {field_name};")
                else:
                    lines.append(f"  {dart_type}? {field_name};")

        return "\n".join(lines)

    def _generate_constructor(self, schema: Any) -> str:
        """
        Generate named constructor with required and optional parameters.

        Handles schema-defined defaults (Issue #43).

        Args:
            schema: Schema object

        Returns:
            Constructor definition
        """
        class_name = self._dart_class_name(schema.name)
        lines = []

        # Determine if we need const constructor (only if immutable and no mutable fields)
        const_prefix = "const " if self.dart_config.immutable else ""

        lines.append(f"  {const_prefix}{class_name}({{")

        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)
            if attr.required:
                lines.append(f"    required this.{field_name},")
            elif attr.default is not None:
                # Issue #43: Use schema-defined default value
                default_value = self._format_dart_default(attr.default)
                lines.append(f"    this.{field_name} = {default_value},")
            else:
                lines.append(f"    this.{field_name},")

        lines.append("  });")

        return "\n".join(lines)

    def _format_dart_default(self, value: Any) -> str:
        """
        Format a default value for Dart syntax.

        Args:
            value: The default value from schema

        Returns:
            Dart-formatted default value string
        """
        if value is None:
            # Dart uses lowercase null
            return "null"
        elif isinstance(value, str):
            # Escape quotes in string defaults
            escaped = value.replace("\\", "\\\\").replace("'", "\\'")
            return f"'{escaped}'"
        elif isinstance(value, bool):
            # Dart booleans are lowercase
            return str(value).lower()
        elif isinstance(value, dict):
            # Issue #48: Dart requires const for Map defaults in const constructors
            return "const {}"
        elif isinstance(value, list):
            # Issue #48: Dart requires const for List defaults in const constructors
            return "const []"
        else:
            # Numbers and other types
            return str(value)

    def _generate_from_json(self, schema: Any) -> str:
        """
        Generate fromJson factory constructor.

        Args:
            schema: Schema object

        Returns:
            fromJson factory definition
        """
        class_name = self._dart_class_name(schema.name)
        lines = []

        lines.append(f"  factory {class_name}.fromJson(Map<String, dynamic> json) {{")
        lines.append(f"    return {class_name}(")

        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)  # Dart field name (camelCase)
            json_key = attr.name  # JSON key (original, typically snake_case)
            dart_type = self._dart_type(attr)

            conversion = self._get_from_json_conversion(attr, dart_type, json_key)

            if attr.required:
                lines.append(f"      {field_name}: {conversion},")
            else:
                lines.append(
                    f"      {field_name}: json['{json_key}'] != null ? {conversion} : null,"
                )

        lines.append("    );")
        lines.append("  }")

        return "\n".join(lines)

    def _get_from_json_conversion(self, attr: Attribute, dart_type: str, json_key: str) -> str:
        """
        Get the conversion expression for fromJson.

        Args:
            attr: Attribute definition
            dart_type: Dart type string
            json_key: JSON key name

        Returns:
            Conversion expression
        """
        base_type = attr.type.lower()

        # Handle array with items_ref (Issue #18)
        if base_type == "array" and attr.items_ref:
            model_name = attr.items_ref
            return (
                f"(json['{json_key}'] as List<dynamic>)"
                f".map((e) => {model_name}.fromJson(e as Map<String, dynamic>)).toList()"
            )

        # Handle object with object_ref (Issue #18)
        if attr.object_ref:
            model_name = attr.object_ref
            return f"{model_name}.fromJson(json['{json_key}'] as Map<String, dynamic>)"

        if base_type in ("float", "number"):
            return f"(json['{json_key}'] as num).toDouble()"
        elif base_type == "integer":
            return f"(json['{json_key}'] as num).toInt()"
        elif base_type == "timestamp":
            # AWSTimestamp: Unix epoch seconds (int) → DateTime
            return f"DateTime.fromMillisecondsSinceEpoch((json['{json_key}'] as int) * 1000)"
        elif base_type == "datetime":
            # AWSDateTime: ISO 8601 string → DateTime
            return f"DateTime.parse(json['{json_key}'] as String)"
        elif base_type == "boolean":
            return f"json['{json_key}'] as bool"
        elif base_type == "string":
            return f"json['{json_key}'] as String"
        elif base_type.startswith("array<"):
            element_type = base_type[6:-1]
            element_dart_type = self.type_mapper.get_type_mapping(element_type).dart_type
            return f"(json['{json_key}'] as List).map((e) => e as {element_dart_type}).toList()"
        elif base_type == "object":
            return f"json['{json_key}'] as Map<String, dynamic>"
        else:
            return f"json['{json_key}']"

    def _generate_to_json(self, schema: Any) -> str:
        """
        Generate toJson method.

        Args:
            schema: Schema object

        Returns:
            toJson method definition
        """
        lines = []

        lines.append("  Map<String, dynamic> toJson() => {")

        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)  # Dart field name (camelCase)
            json_key = attr.name  # JSON key (original, typically snake_case)
            dart_type = self._dart_type(attr)

            conversion = self._get_to_json_conversion(attr, dart_type, field_name)

            if attr.required:
                lines.append(f"    '{json_key}': {conversion},")
            else:
                lines.append(f"    if ({field_name} != null) '{json_key}': {conversion},")

        lines.append("  };")

        return "\n".join(lines)

    def _get_to_json_conversion(self, attr: Attribute, dart_type: str, field_name: str) -> str:
        """
        Get the conversion expression for toJson.

        Args:
            attr: Attribute definition
            dart_type: Dart type string
            field_name: Field name

        Returns:
            Conversion expression
        """
        base_type = attr.type.lower()

        # Handle array with items_ref (Issue #18)
        if base_type == "array" and attr.items_ref:
            if attr.required:
                return f"{field_name}.map((e) => e.toJson()).toList()"
            else:
                return f"{field_name}?.map((e) => e.toJson()).toList()"

        # Handle object with object_ref (Issue #18)
        if attr.object_ref:
            if attr.required:
                return f"{field_name}.toJson()"
            else:
                return f"{field_name}?.toJson()"

        if base_type == "timestamp":
            # AWSTimestamp: DateTime → Unix epoch seconds (int)
            if attr.required:
                return f"{field_name}.millisecondsSinceEpoch ~/ 1000"
            else:
                return f"{field_name}?.millisecondsSinceEpoch ~/ 1000"
        elif base_type == "datetime":
            # AWSDateTime: DateTime → ISO 8601 string
            if attr.required:
                return f"{field_name}.toIso8601String()"
            else:
                return f"{field_name}?.toIso8601String()"
        else:
            return field_name

    def _generate_copy_with(self, schema: Any) -> str:
        """
        Generate copyWith method for immutability.

        Args:
            schema: Schema object

        Returns:
            copyWith method definition
        """
        class_name = self._dart_class_name(schema.name)
        lines = []

        lines.append(f"  {class_name} copyWith({{")

        # Parameters (all optional)
        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)
            dart_type = self._dart_type(attr)
            lines.append(f"    {dart_type}? {field_name},")

        lines.append(f"  }}) => {class_name}(")

        # Field assignments
        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)
            lines.append(f"    {field_name}: {field_name} ?? this.{field_name},")

        lines.append("  );")

        return "\n".join(lines)

    def _generate_to_string(self, schema: Any) -> str:
        """
        Generate toString override.

        Args:
            schema: Schema object

        Returns:
            toString method definition
        """
        class_name = self._dart_class_name(schema.name)
        lines = []

        lines.append("  @override")
        lines.append("  String toString() {")

        field_strings = []
        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)
            field_strings.append(f"{field_name}: ${field_name}")

        fields_str = ", ".join(field_strings)
        lines.append(f"    return '{class_name}({fields_str})';")
        lines.append("  }")

        return "\n".join(lines)

    def _generate_props(self, schema: Any) -> str:
        """
        Generate Equatable props getter.

        Args:
            schema: Schema object

        Returns:
            props getter definition
        """
        lines = []

        lines.append("  @override")
        lines.append("  List<Object?> get props => [")

        for attr in schema.attributes:
            field_name = to_camel_case(attr.name)
            lines.append(f"    {field_name},")

        lines.append("  ];")

        return "\n".join(lines)

    def _dart_type(self, attr: Attribute) -> str:
        """
        Convert schema type to Dart type.

        Priority:
        1. enum_type - Enum reference
        2. object_ref - Nested model reference
        3. items_ref - Array of model references
        4. model_reference - Direct model type
        5. Standard type mapping

        Args:
            attr: Attribute definition

        Returns:
            Dart type string
        """
        if attr.enum_type:
            return attr.enum_type

        # Check for object_ref (nested model)
        if attr.object_ref:
            return attr.object_ref

        # Check for array with items_ref
        if attr.type == "array" and attr.items_ref:
            return f"List<{attr.items_ref}>"

        # Check for direct model reference
        if hasattr(attr, "model_reference") and attr.model_reference:
            return attr.model_reference

        try:
            mapping = self.type_mapper.get_type_mapping(attr.type)
            return mapping.dart_type
        except ValueError:
            # Fallback for unknown types
            logger.warning(
                f"Unknown type '{attr.type}' for attribute '{attr.name}', defaulting to dynamic"
            )
            return "dynamic"

    def _get_next_hive_type_id(self) -> int:
        """
        Get the next unique Hive typeId.

        Returns:
            Next typeId value
        """
        type_id = self._hive_type_id_counter
        self._hive_type_id_counter += 1
        return type_id

    def reset_hive_type_id_counter(self) -> None:
        """Reset the Hive typeId counter (useful for testing)."""
        self._hive_type_id_counter = 0

    # =========================================================================
    # GRAPHQL UTILITY FILE GENERATION (Issue #71)
    # =========================================================================

    def _generate_graphql_utils(self) -> str:
        """
        Generate GraphQL utility file with timestamp conversion functions.

        AWSTimestamp is a Unix timestamp in seconds, but Dart uses DateTime objects.
        This utility provides functions to convert between the two formats.

        Returns:
            Complete Dart utility file content
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())
        lines.append("")
        lines.append("/// GraphQL utilities for AWSTimestamp conversion.")
        lines.append("///")
        lines.append(
            "/// AWSTimestamp is a Unix timestamp in seconds, but Dart uses DateTime objects."
        )
        lines.append("/// Use [toGraphQLInput] before sending data to GraphQL mutations.")
        lines.append(
            "/// Use [fromGraphQLTimestamp] when receiving AWSTimestamp from GraphQL responses."
        )
        lines.append("")

        # toGraphQLInput function
        lines.append(
            "/// Convert DateTime fields to Unix timestamps for GraphQL AWSTimestamp compatibility."
        )
        lines.append("/// Recursively handles nested Maps and Lists.")
        lines.append("///")
        lines.append("/// Example:")
        lines.append("/// ```dart")
        lines.append("/// final input = toGraphQLInput({")
        lines.append("///   'name': 'John',")
        lines.append("///   'createdAt': DateTime.now(),")
        lines.append("///   'metadata': {'updatedAt': DateTime.now()}")
        lines.append("/// });")
        lines.append(
            "/// // Result: {'name': 'John', 'createdAt': 1705500000, 'metadata': {'updatedAt': 1705500000}}"
        )
        lines.append("/// ```")
        lines.append("Map<String, dynamic> toGraphQLInput(Map<String, dynamic> input) {")
        lines.append("  final result = <String, dynamic>{};")
        lines.append("")
        lines.append("  for (final entry in input.entries) {")
        lines.append("    final value = entry.value;")
        lines.append("    if (value is DateTime) {")
        lines.append("      result[entry.key] = value.millisecondsSinceEpoch ~/ 1000;")
        lines.append("    } else if (value is List) {")
        lines.append("      result[entry.key] = value.map((item) {")
        lines.append("        if (item is DateTime) {")
        lines.append("          return item.millisecondsSinceEpoch ~/ 1000;")
        lines.append("        } else if (item is Map<String, dynamic>) {")
        lines.append("          return toGraphQLInput(item);")
        lines.append("        }")
        lines.append("        return item;")
        lines.append("      }).toList();")
        lines.append("    } else if (value is Map<String, dynamic>) {")
        lines.append("      result[entry.key] = toGraphQLInput(value);")
        lines.append("    } else {")
        lines.append("      result[entry.key] = value;")
        lines.append("    }")
        lines.append("  }")
        lines.append("")
        lines.append("  return result;")
        lines.append("}")
        lines.append("")

        # fromGraphQLTimestamp function
        lines.append("/// Convert Unix timestamp from GraphQL AWSTimestamp to Dart DateTime.")
        lines.append("///")
        lines.append("/// Returns null if [timestamp] is null.")
        lines.append("///")
        lines.append("/// Example:")
        lines.append("/// ```dart")
        lines.append("/// final date = fromGraphQLTimestamp(1705500000);")
        lines.append("/// // Result: DateTime object representing 2024-01-17T...")
        lines.append("/// ```")
        lines.append("DateTime? fromGraphQLTimestamp(int? timestamp) {")
        lines.append("  if (timestamp == null) {")
        lines.append("    return null;")
        lines.append("  }")
        lines.append("  return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);")
        lines.append("}")

        return "\n".join(lines)

    # =========================================================================
    # GRAPHQL QUERY DEFINITION FILE GENERATION (Issue #79)
    # =========================================================================

    def _has_operations(self, schema: Any) -> bool:
        """
        Check if a schema has operations defined.

        Args:
            schema: Schema object

        Returns:
            True if schema has non-empty operations list or is a LambdaType, False otherwise
        """
        if isinstance(schema, LambdaType):
            return True
        if not hasattr(schema, "operations"):
            return False
        if schema.operations is None:
            return False
        return len(schema.operations) > 0

    def _generate_gql_attribute_fields(
        self,
        schema: Any,
        indent: int = 6,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL field selection for schema attributes.

        Args:
            schema: Schema object with attributes
            indent: Number of spaces for indentation
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Field selection string with proper indentation
        """
        lines = []
        prefix = " " * indent

        for attr in schema.attributes:
            if attr.object_ref and all_schemas:
                nested_schema = all_schemas.get(attr.object_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    lines.append(f"{prefix}{attr.name}")
            elif attr.items_ref and all_schemas:
                nested_schema = all_schemas.get(attr.items_ref)
                if nested_schema and hasattr(nested_schema, "attributes"):
                    lines.append(f"{prefix}{attr.name} {{")
                    for nested_attr in nested_schema.attributes:
                        lines.append(f"{prefix}  {nested_attr.name}")
                    lines.append(f"{prefix}}}")
                else:
                    lines.append(f"{prefix}{attr.name}")
            else:
                lines.append(f"{prefix}{attr.name}")

        return "\n".join(lines)

    def _generate_gql_response_fields(
        self,
        schema: Any,
        operation: Any = None,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate GraphQL response field selection for an operation.

        v0.19.0 format:
        - All responses include envelope: code, success, message
        - Mutations/Get: singular `item` field
        - List: plural `items` field + nextToken

        Args:
            schema: Schema object
            operation: Operation object (required for TableSchema)
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Response field selection string
        """
        from ..core.models import classify_operation_response_type

        if isinstance(schema, TableSchema):
            if operation is not None:
                response_type = classify_operation_response_type(operation)
            else:
                response_type = "list"

            attr_fields = self._generate_gql_attribute_fields(
                schema, indent=8, all_schemas=all_schemas
            )

            envelope = """      code
      success
      message"""

            if response_type == "singular":
                return f"""{envelope}
      item {{
{attr_fields}
      }}"""
            else:
                return f"""{envelope}
      items {{
{attr_fields}
      }}
      nextToken"""
        else:
            return self._generate_gql_attribute_fields(schema, indent=6, all_schemas=all_schemas)

    def _generate_gql_operation_constant(
        self,
        schema: Any,
        operation: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a single GraphQL operation constant for Dart.

        Args:
            schema: Schema object the operation belongs to
            operation: Operation object with name, type, field
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Dart constant string with GraphQL operation
        """
        op_type = "query" if operation.type == "Query" else "mutation"
        response_fields = self._generate_gql_response_fields(schema, operation, all_schemas)

        # Use camelCase for Dart constant names
        const_name = to_camel_case(operation.field)

        # Use triple-quoted string for Dart
        # Note: Using string concatenation to avoid escape sequence warnings
        dollar = "$"
        return f"""/// GraphQL {op_type} for {operation.field}
const String {const_name} = '''
  {op_type} {operation.field}({dollar}input: {operation.field}Input!) {{
    {operation.field}(input: {dollar}input) {{
{response_fields}
    }}
  }}
''';"""

    def _generate_lambda_gql_operation_constant(
        self,
        schema: LambdaType,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a GraphQL operation constant for a Lambda type.

        Args:
            schema: LambdaType schema object
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Dart constant string with GraphQL operation
        """
        op_type = "query" if schema.operation == "query" else "mutation"
        op_name = schema.name

        # Filter to only output attributes (not input_only)
        output_attrs = [
            attr for attr in schema.attributes if not getattr(attr, "input_only", False)
        ]

        # Generate field selection
        lines = []
        for attr in output_attrs:
            lines.append(f"      {attr.name}")
        fields = "\n".join(lines)

        # Use camelCase for Dart constant names
        const_name = to_camel_case(op_name)

        # Note: Using string concatenation to avoid escape sequence warnings
        dollar = "$"
        return f"""/// GraphQL {op_type} for {op_name}
const String {const_name} = '''
  {op_type} {op_name}({dollar}input: {op_name}Input!) {{
    {op_name}(input: {dollar}input) {{
{fields}
    }}
  }}
''';"""

    def _generate_gql_query_file(
        self,
        schema: Any,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate a complete GraphQL query definition file for Dart.

        Args:
            schema: Schema object with operations or LambdaType
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Complete Dart file content with GraphQL operation constants
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())
        lines.append(f"/// GraphQL operations for {schema.name}.")
        lines.append("")

        if isinstance(schema, LambdaType):
            lines.append(self._generate_lambda_gql_operation_constant(schema, all_schemas))
            lines.append("")
        else:
            for operation in schema.operations:
                lines.append(self._generate_gql_operation_constant(schema, operation, all_schemas))
                lines.append("")

        return "\n".join(lines)

    def _generate_graphql_queries(
        self,
        schemas: Dict[str, Any],
        output_config,
        all_schemas: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Generate Dart GraphQL query definition files for all schemas with operations.

        Args:
            schemas: Dictionary of schema objects for this target
            output_config: OutputConfig for this target
            all_schemas: Dictionary of all schemas for resolving nested types

        Returns:
            Number of query files generated
        """
        # Skip if graphql_queries_subdir not configured
        if not output_config.graphql_queries_subdir:
            return 0

        generated_files = []

        for name, schema in schemas.items():
            if self._has_operations(schema):
                content = self._generate_gql_query_file(schema, all_schemas or schemas)
                filename = f"{to_snake_case(schema.name)}_graphql"
                output_path = output_config.graphql_queries_path(f"{filename}.dart")
                if output_path:
                    self._write_file(output_path, content)
                    generated_files.append(filename)

        # Generate barrel file if any files were generated
        if generated_files:
            barrel_content = self._generate_gql_queries_barrel(generated_files)
            barrel_path = output_config.graphql_queries_path("graphql_queries.dart")
            if barrel_path:
                self._write_file(barrel_path, barrel_content)

        return len(generated_files)

    def _generate_gql_queries_barrel(self, generated_files: list) -> str:
        """
        Generate barrel file re-exporting all GraphQL query files.

        Args:
            generated_files: List of filenames (without extension)

        Returns:
            Complete barrel file content
        """
        lines = []

        # Add AUTO-GENERATED header
        lines.append(self._get_file_header("dart").rstrip())
        lines.append("/// GraphQL operations barrel file.")
        lines.append("/// Re-exports all GraphQL query definitions for convenient imports.")
        lines.append("")

        # Export all entity files
        for filename in sorted(generated_files):
            lines.append(f"export '{filename}.dart';")

        return "\n".join(lines)
