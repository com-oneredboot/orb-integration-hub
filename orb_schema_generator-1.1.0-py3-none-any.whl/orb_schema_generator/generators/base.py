"""Base generator class for all code generators."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Union
import logging

from ..core.config import GeneratorConfig
from ..core.models import StandardType, TableSchema, GraphQLType, RegistryType, LambdaType
from ..utils.file_io import atomic_write
from ..utils.console import success, error

logger = logging.getLogger(__name__)

# Union type for all schema types
SchemaType = Union[StandardType, TableSchema, GraphQLType, RegistryType, LambdaType]


def _get_package_version() -> str:
    """Get package version from metadata or fallback."""
    try:
        from importlib.metadata import version

        return version("orb-schema-generator")
    except Exception:
        return "0.10.1"


class BaseGenerator(ABC):
    """Base class for all code generators."""

    AUTO_GENERATED_PATTERNS = [
        "# AUTO-GENERATED",
        "// AUTO-GENERATED",
        "/* AUTO-GENERATED",
        "## AUTO-GENERATED",  # VTL comment style
    ]

    def __init__(self, config: GeneratorConfig):
        """
        Initialize generator with configuration.

        Args:
            config: Generator configuration
        """
        self.config = config

    @abstractmethod
    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate code from schemas.

        Args:
            schemas: Dictionary of schema objects keyed by name
        """
        pass

    def _group_by_target(self, schemas: Dict[str, SchemaType]) -> Dict[str, Dict[str, SchemaType]]:
        """Group schemas by their targets.

        A schema with multiple targets appears in multiple groups.

        Args:
            schemas: Dictionary mapping schema names to schema objects

        Returns:
            Dictionary mapping target names to dictionaries of schemas
        """
        grouped: Dict[str, Dict[str, SchemaType]] = {}

        for schema_name, schema in schemas.items():
            targets = getattr(schema, "targets", [])
            if not targets:
                # Skip schemas without targets (shouldn't happen with validation)
                logger.warning(f"Schema {schema_name} has no targets, skipping")
                continue

            for target in targets:
                if target not in grouped:
                    grouped[target] = {}
                grouped[target][schema_name] = schema

        return grouped

    def _write_file(self, path: Path, content: str) -> None:
        """
        Write file atomically with header detection.

        Only overwrites files that:
        1. Do not exist, OR
        2. Have an AUTO-GENERATED header

        Skips files without the header to protect custom code.

        Args:
            path: Path to write file to
            content: File content

        Raises:
            IOError: If file write fails
        """
        if path.exists():
            if not self._has_auto_generated_header(path):
                logger.warning(
                    f"Skipping {path}: No AUTO-GENERATED header found. "
                    "Move custom code to lib/ or delete file to regenerate."
                )
                return

        try:
            # Create parent directories if they don't exist
            path.parent.mkdir(parents=True, exist_ok=True)

            # Write file atomically
            atomic_write(str(path), content)
            logger.debug(success(f"Wrote file: {path}"))
        except Exception as e:
            logger.error(error(f"Failed to write file {path}: {str(e)}"))
            raise

    def _has_auto_generated_header(self, path: Path) -> bool:
        """
        Check if file has AUTO-GENERATED header in first 5 lines.

        Args:
            path: Path to file to check

        Returns:
            True if file has AUTO-GENERATED header
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                for _ in range(5):
                    line = f.readline()
                    if not line:
                        break
                    if any(pattern in line for pattern in self.AUTO_GENERATED_PATTERNS):
                        return True
        except (OSError, IOError) as e:
            logger.debug(f"Could not read file {path}: {e}")
        return False

    def _format_docstring(self, text: str, indent: int = 0) -> str:
        """
        Format docstring with proper indentation.

        Args:
            text: Docstring text
            indent: Number of spaces to indent

        Returns:
            Formatted docstring
        """
        spaces = " " * indent
        return f'{spaces}"""{text}"""'

    def _get_file_header(self, language: str) -> str:
        """
        Generate AUTO-GENERATED header for a file.

        Args:
            language: Target language ("python", "typescript", "dart", "vtl", or "graphql")

        Returns:
            Header string with version and regeneration command
        """
        version = _get_package_version()

        if language == "python":
            return f"""# AUTO-GENERATED by orb-schema-generator v{version} - DO NOT EDIT
# Regenerate with: orb-schema generate

"""
        elif language == "dart":
            return f"""// AUTO-GENERATED by orb-schema-generator v{version} - DO NOT EDIT
// Regenerate with: orb-schema generate

"""
        elif language == "vtl":
            return f"""## AUTO-GENERATED by orb-schema-generator v{version} - DO NOT EDIT
## Regenerate with: orb-schema generate

"""
        elif language == "graphql":
            return f"""# AUTO-GENERATED by orb-schema-generator v{version} - DO NOT EDIT
# Regenerate with: orb-schema generate

"""
        else:  # typescript
            return f"""// AUTO-GENERATED by orb-schema-generator v{version} - DO NOT EDIT
// Regenerate with: orb-schema generate

"""
