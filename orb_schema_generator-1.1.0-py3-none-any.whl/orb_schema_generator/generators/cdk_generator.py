"""CDK construct generator."""

from pathlib import Path
from typing import Dict, Any, List, TYPE_CHECKING
import logging
import os
import re

from .base import BaseGenerator
from ..core.models import ConfigurationError, TableSchema
from ..utils.case_conversion import to_pascal_case
from ..utils.console import success

if TYPE_CHECKING:
    from ..core.config import ApiDefinition

logger = logging.getLogger(__name__)


class CDKGenerator(BaseGenerator):
    """Generates AWS CDK constructs from schemas."""

    def _get_file_header(self, language: str = "typescript") -> str:
        """
        Generate header comment for generated files.

        Args:
            language: Target language ("typescript" or "python")

        Returns:
            Header comment string
        """
        # Use the base class method
        return super()._get_file_header(language)

    def _get_graphql_schema_path(self, from_dir: str = "appsync") -> str:
        """
        Calculate relative path from CDK output to GraphQL schema.

        Args:
            from_dir: Subdirectory within CDK output (e.g., "appsync")

        Returns:
            Relative path to schema.graphql
        """
        cdk_dir = Path(self.config.cdk_output_dir).resolve()
        graphql_dir = self.config.graphql_output.base_dir.resolve()

        # Calculate relative path from CDK appsync dir to GraphQL schema
        from_path = cdk_dir / from_dir if from_dir else cdk_dir

        try:
            rel_path = os.path.relpath(graphql_dir / "schema.graphql", from_path)
            # Normalize path separators for cross-platform
            return rel_path.replace("\\", "/")
        except ValueError:
            # Different drives on Windows - use absolute path
            return str(graphql_dir / "schema.graphql").replace("\\", "/")

    def generate(self, schemas: Dict[str, Any]) -> None:
        """
        Generate CDK constructs for all schemas.

        Only Python CDK generation is supported. TypeScript CDK generation
        has been removed to reduce maintenance burden.

        Args:
            schemas: Dictionary of schema objects keyed by name

        Raises:
            ConfigurationError: If cdk_language is not 'python'
        """
        logger.info("Generating CDK constructs...")

        # Determine language from config - default to python
        language = getattr(self.config, "cdk_language", "python").lower()

        if language != "python":
            raise ConfigurationError(
                f"CDK language '{language}' is not supported. "
                "Only 'python' is supported for CDK generation. "
                "Set 'cdk.language: python' in your schema-generator.yml configuration."
            )

        self._generate_python(schemas)

    def _generate_python(self, schemas: Dict[str, Any]) -> None:
        """Generate Python CDK constructs."""
        # SSM parameters are always generated for DynamoDB tables (Issue #64)

        # Generate table constructs
        table_count = 0
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                content = self._generate_table_construct_py(schema)
                # Python uses snake_case file names
                file_name = self._to_snake_case(name) + "_table.py"
                output_path = Path(self.config.cdk_output_dir) / "tables" / file_name
                self._write_file(output_path, content)
                table_count += 1

        logger.info(success(f"Generated {table_count} CDK table constructs (Python)"))

        # Generate AppSync API construct
        api_content = self._generate_api_construct_py(schemas)
        api_path = Path(self.config.cdk_output_dir) / "appsync" / "api.py"
        self._write_file(api_path, api_content)
        logger.info(success("Generated CDK AppSync API construct (Python)"))

        # Generate __init__.py file
        index_content = self._generate_index_py(schemas)
        index_path = Path(self.config.cdk_output_dir) / "__init__.py"
        self._write_file(index_path, index_content)
        logger.info(success("Generated CDK __init__.py file (Python)"))

        # Also create __init__.py in subdirectories
        tables_init = self._generate_tables_init_py(schemas)
        tables_init_path = Path(self.config.cdk_output_dir) / "tables" / "__init__.py"
        self._write_file(tables_init_path, tables_init)

        appsync_init = self._get_file_header("python") + "from .api import AppSyncApi\n"
        appsync_init_path = Path(self.config.cdk_output_dir) / "appsync" / "__init__.py"
        self._write_file(appsync_init_path, appsync_init)

        # Generate stack files if enabled
        self._generate_stack_files(schemas)

    def _to_snake_case(self, text: str) -> str:
        """Convert PascalCase/camelCase to snake_case."""
        if not text:
            return ""
        result = re.sub(r"(?<!^)(?=[A-Z])", "_", text)
        return result.lower()

    def _to_pascal_case(self, text: str) -> str:
        """Convert text to PascalCase, preserving acronyms."""
        return to_pascal_case(text)

    def _get_resource_name(self, resource_type: str, name: str) -> str:
        """
        Generate resource name using loaded config values.

        Creates names like orb-project-dev-table-users using the customerId,
        projectId, and environment from the loaded GeneratorConfig (Issue #28 fix).

        Args:
            resource_type: Type of resource (e.g., 'table', 'lambda')
            name: Resource name (will be included as-is)

        Returns:
            Formatted resource name: {customerId}-{projectId}-{environment}-{resourceType}-{name}
        """
        prefix = f"{self.config.customer_id}-{self.config.project_id}-{self.config.environment}"
        return f"{prefix}-{resource_type}-{name}"

    def _get_ssm_parameter_path(self, *segments: str) -> str:
        """
        Generate hierarchical SSM parameter path.

        Creates paths like /orb/project/dev/appsync/api-id for better
        organization in AWS Parameter Store (Issue #26 fix).

        Args:
            segments: Path segments (e.g., 'appsync', 'api-id')

        Returns:
            Hierarchical path like '/orb/project/dev/appsync/api-id'
        """
        base = f"/{self.config.customer_id}/{self.config.project_id}/{self.config.environment}"
        if segments:
            return f"{base}/{'/'.join(segments)}"
        return base

    def _get_lambda_arn_reference(self, schema_name: str) -> str:
        """
        Get Lambda ARN reference for a schema.

        Args:
            schema_name: Name of the schema

        Returns:
            Lambda ARN reference (SSM parameter path)
        """
        name_lower = schema_name.lower()

        # Check for custom ARN pattern
        if hasattr(self.config, "lambda_config") and self.config.lambda_config:
            if self.config.lambda_config.lambda_arn_pattern:
                pattern = self.config.lambda_config.lambda_arn_pattern
                return pattern.replace("${name}", name_lower)

        # Default: SSM parameter pattern
        return self._get_ssm_parameter_path("lambda", name_lower, "arn")

    # =========================================================================
    # PYTHON CDK GENERATION METHODS
    # =========================================================================

    def _generate_table_construct_py(self, schema: TableSchema) -> str:
        """
        Generate Python DynamoDB table CDK construct.

        SSM parameters are always generated for table discovery (Issue #64).

        Args:
            schema: Table schema

        Returns:
            Python CDK construct code
        """
        lines = []
        lines.append(self._get_file_header("python").rstrip())
        lines.append("from aws_cdk import (")
        lines.append("    aws_dynamodb as dynamodb,")
        lines.append("    aws_ssm as ssm,")
        lines.append(")")
        lines.append("from constructs import Construct")
        lines.append("")
        lines.append("")

        # Class definition
        class_name = f"{schema.name}Table"
        lines.append(f"class {class_name}(Construct):")
        lines.append('    """DynamoDB table construct for {name}."""'.format(name=schema.name))
        lines.append("")
        lines.append("    def __init__(self, scope: Construct, id: str) -> None:")
        lines.append("        super().__init__(scope, id)")
        lines.append("")

        # Table name
        table_name = self._get_resource_name("table", schema.name.lower())

        # Build table kwargs
        lines.append("        self.table = dynamodb.Table(")
        lines.append(f'            self, "{schema.name}",')
        lines.append(f'            table_name="{table_name}",')

        # Partition key
        pk_type = self._dynamodb_attribute_type_py("string")
        lines.append("            partition_key=dynamodb.Attribute(")
        lines.append(f'                name="{schema.partition_key}",')
        lines.append(f"                type=dynamodb.AttributeType.{pk_type},")
        lines.append("            ),")

        # Sort key (if exists)
        if schema.sort_key and schema.sort_key != "None":
            sk_type = self._dynamodb_attribute_type_py("string")
            lines.append("            sort_key=dynamodb.Attribute(")
            lines.append(f'                name="{schema.sort_key}",')
            lines.append(f"                type=dynamodb.AttributeType.{sk_type},")
            lines.append("            ),")

        # Billing mode
        lines.append("            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,")

        # Point-in-Time Recovery (Issue #65)
        if schema.pitr_enabled:
            lines.append("            point_in_time_recovery=True,")

        # Stream configuration
        if schema.stream and schema.stream.get("enabled"):
            view_type = schema.stream.get("viewType", "NEW_AND_OLD_IMAGES")
            lines.append(f"            stream=dynamodb.StreamViewType.{view_type},")

        lines.append("        )")

        # Add GSIs
        if schema.secondary_indexes:
            for index in schema.secondary_indexes:
                if index.get("type") == "GSI":
                    lines.append("")
                    lines.extend(self._generate_gsi_py(index))

        # SSM Parameters for table discovery (always generated - Issue #64)
        table_name_lower = schema.name.lower()
        table_name_param = self._get_ssm_parameter_path("dynamodb", table_name_lower, "table-name")
        table_arn_param = self._get_ssm_parameter_path("dynamodb", table_name_lower, "table-arn")
        lines.append("")
        lines.append("        # SSM Parameters for table discovery")
        lines.append("        ssm.StringParameter(")
        lines.append(f'            self, "{schema.name}TableNameParam",')
        lines.append(f'            parameter_name="{table_name_param}",')
        lines.append("            string_value=self.table.table_name,")
        lines.append("        )")
        lines.append("")
        lines.append("        ssm.StringParameter(")
        lines.append(f'            self, "{schema.name}TableArnParam",')
        lines.append(f'            parameter_name="{table_arn_param}",')
        lines.append("            string_value=self.table.table_arn,")
        lines.append("        )")

        return "\n".join(lines)

    def _dynamodb_attribute_type_py(self, schema_type: str) -> str:
        """Convert schema type to Python DynamoDB attribute type."""
        if schema_type in ["string", "timestamp"]:
            return "STRING"
        elif schema_type in ["number", "int", "float"]:
            return "NUMBER"
        elif schema_type == "binary":
            return "BINARY"
        else:
            return "STRING"

    def _generate_gsi_py(self, index: Dict[str, Any]) -> list:
        """Generate Python GSI configuration."""
        lines = []
        index_name = index.get("name", "")
        partition = index.get("partition", "")
        sort = index.get("sort")
        projection_type = index.get("projection_type", "ALL")

        lines.append("        self.table.add_global_secondary_index(")
        lines.append(f'            index_name="{index_name}",')

        pk_type = self._dynamodb_attribute_type_py("string")
        lines.append("            partition_key=dynamodb.Attribute(")
        lines.append(f'                name="{partition}",')
        lines.append(f"                type=dynamodb.AttributeType.{pk_type},")
        lines.append("            ),")

        if sort:
            sk_type = self._dynamodb_attribute_type_py("string")
            lines.append("            sort_key=dynamodb.Attribute(")
            lines.append(f'                name="{sort}",')
            lines.append(f"                type=dynamodb.AttributeType.{sk_type},")
            lines.append("            ),")

        lines.append(f"            projection_type=dynamodb.ProjectionType.{projection_type},")
        lines.append("        )")

        return lines

    def _generate_data_source_and_resolvers_py(self, schema: TableSchema) -> list:
        """
        Generate Python DynamoDB data source and resolver code for a schema.

        Issue #80: Refactored to consume schema.operations from OperationBuilder
        instead of hardcoding operation lists. This ensures CDK resolvers match
        the GraphQL schema exactly (Get, Disable, ListBy* operations).

        Args:
            schema: Table schema

        Returns:
            List of code lines for data source and resolver setup
        """
        lines = []
        name = schema.name
        name_snake = self._to_snake_case(name)
        ds_var = f"{name_snake}_data_source"

        # Track generated resolver names to prevent duplicates (Issue #46)
        generated_resolvers: set = set()

        lines.append("")
        lines.append(f"        # {name} data source and resolvers")
        lines.append(f"        {ds_var} = self.api.add_dynamo_db_data_source(")
        lines.append(f'            "{name}DataSource",')
        lines.append(f'            tables["{name}"],')
        lines.append("        )")
        lines.append("")

        # Generate resolvers from schema.operations (canonical source - Issue #80)
        # This includes: Create, Update, Delete, Disable, Get, and all ListBy* operations
        for operation in schema.operations:
            resolver_name = f"{name}{operation.name}Resolver"

            # Skip if already generated (deduplication)
            if resolver_name in generated_resolvers:
                continue
            generated_resolvers.add(resolver_name)

            type_name = operation.type  # "Query" or "Mutation"
            field_name = operation.field

            lines.append(f"        {ds_var}.create_resolver(")
            lines.append(f'            "{resolver_name}",')
            lines.append(f'            type_name="{type_name}",')
            lines.append(f'            field_name="{field_name}",')
            lines.append("            request_mapping_template=appsync.MappingTemplate.from_file(")
            lines.append(
                f'                str(Path(__file__).parent / "resolvers/{type_name}.{field_name}.request.vtl")'
            )
            lines.append("            ),")
            lines.append("            response_mapping_template=appsync.MappingTemplate.from_file(")
            lines.append(
                f'                str(Path(__file__).parent / "resolvers/{type_name}.{field_name}.response.vtl")'
            )
            lines.append("            ),")
            lines.append("        )")
            lines.append("")

        return lines

    def _generate_lambda_resolver_py(
        self, schema_name: str, ds_var: str, field_name: str, type_name: str
    ) -> list:
        """
        Generate a single Python Lambda resolver.

        For pure Lambda schemas (type: lambda), uses Lambda direct resolver
        without VTL templates. The Lambda function receives the full AppSync
        context and returns the response directly.
        """
        lines = []
        lines.append(f"        {ds_var}.create_resolver(")
        lines.append(f'            "{schema_name}Resolver",')
        lines.append(f'            type_name="{type_name}",')
        lines.append(f'            field_name="{field_name}",')
        lines.append("        )")
        lines.append("")
        return lines

    def _generate_lambda_dynamodb_resolvers_py(self, schema: TableSchema, ds_var: str) -> list:
        """Generate Python resolvers for Lambda-DynamoDB schema."""
        lines = []
        name = schema.name

        # CRUD operations
        operations = [
            ("Create", "Mutation"),
            ("Update", "Mutation"),
            ("Delete", "Mutation"),
            ("Disable", "Mutation"),
        ]

        for op_name, type_name in operations:
            field_name = f"{name}{op_name}"
            lines.extend(self._generate_lambda_resolver_py(name, ds_var, field_name, type_name))

        # QueryBy for partition key
        pk = schema.partition_key
        pk_pascal = self._to_pascal_case(pk)
        field_name = f"{name}QueryBy{pk_pascal}"
        lines.extend(self._generate_lambda_resolver_py(name, ds_var, field_name, "Query"))

        # QueryBy for GSIs
        if schema.secondary_indexes:
            for index in schema.secondary_indexes:
                if index.get("type") == "GSI":
                    partition = index.get("partition", "")
                    partition_pascal = self._to_pascal_case(partition)
                    field_name = f"{name}QueryBy{partition_pascal}"
                    lines.extend(
                        self._generate_lambda_resolver_py(name, ds_var, field_name, "Query")
                    )

        return lines

    def _generate_lambda_data_source_and_resolvers_py(self, schema) -> list:
        """
        Generate Python Lambda data source and resolver code for a schema.

        Args:
            schema: Lambda or Lambda-DynamoDB schema

        Returns:
            List of code lines
        """
        lines = []
        name = schema.name
        name_snake = self._to_snake_case(name)
        ds_var = f"{name_snake}_lambda_data_source"

        lines.append("")
        lines.append(f"        # {name} Lambda data source and resolvers")

        # Get Lambda ARN reference
        lambda_arn_ref = self._get_lambda_arn_reference(name)

        lines.append(
            f"        {name_snake}_lambda_arn = ssm.StringParameter.value_for_string_parameter("
        )
        lines.append(f'            self, "{lambda_arn_ref}"')
        lines.append("        )")
        # Issue #74: Use from_function_attributes with same_environment=True
        # to allow AppSync to add invoke permissions to the imported Lambda
        lines.append(f"        {name_snake}_lambda = lambda_.Function.from_function_attributes(")
        lines.append("            self,")
        lines.append(f'            "{name}Lambda",')
        lines.append(f"            function_arn={name_snake}_lambda_arn,")
        lines.append("            same_environment=True,")
        lines.append("        )")
        lines.append(f"        {ds_var} = self.api.add_lambda_data_source(")
        lines.append(f'            "{name}LambdaDataSource",')
        lines.append(f"            {name_snake}_lambda,")
        lines.append("        )")
        lines.append("")

        # Generate resolvers based on schema type
        schema_type = getattr(schema, "type", "lambda")
        if schema_type == "lambda":
            # Pure Lambda - single operation (Issue #68)
            # Use the operation field to determine Query vs Mutation
            operation_type = getattr(schema, "operation", "mutation")
            type_name = "Query" if operation_type == "query" else "Mutation"
            lines.extend(self._generate_lambda_resolver_py(name, ds_var, schema.name, type_name))
        else:
            # Lambda-DynamoDB - CRUD + GSI operations
            lines.extend(self._generate_lambda_dynamodb_resolvers_py(schema, ds_var))

        return lines

    def _generate_api_construct_py(self, schemas: Dict[str, Any]) -> str:
        """
        Generate Python AppSync API construct.

        Issue #72: Refactored to use proper naming conventions instead of
        hardcoded values. The construct now:
        - Uses {customerId}-{projectId}-{environment}-appsync-api for API name
        - Looks up user pool via SSM using naming convention
        - Always creates SSM parameters using naming convention
        - Supports API key auth mode via enable_api_key parameter

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Python AppSync API construct code
        """
        # Check if any DynamoDB table schemas exist (VTL resolvers needed)
        has_table_schemas = any(
            getattr(schema, "type", None) == "dynamodb" for schema in schemas.values()
        )

        # Check if any Lambda schemas exist (Issue #68)
        has_lambda_schemas = any(
            getattr(schema, "type", None) == "lambda" for schema in schemas.values()
        )

        # Get resolved GraphQL schema path
        graphql_schema_path = self._get_graphql_schema_path("appsync")

        # Generate names using naming conventions (Issue #72)
        api_name = self._get_resource_name("appsync", "api")
        user_pool_ssm_path = self._get_ssm_parameter_path("cognito", "user-pool-id")
        api_id_param = self._get_ssm_parameter_path("appsync", "api-id")
        graphql_url_param = self._get_ssm_parameter_path("appsync", "graphql-url")

        lines = []
        lines.append(self._get_file_header("python").rstrip())

        # Imports
        lines.append("from pathlib import Path")
        lines.append("from typing import Dict")
        lines.append("")
        lines.append("from aws_cdk import (")
        lines.append("    aws_appsync as appsync,")
        lines.append("    aws_cognito as cognito,")
        lines.append("    aws_dynamodb as dynamodb,")
        lines.append("    aws_iam as iam,")
        if has_lambda_schemas:
            lines.append("    aws_lambda as lambda_,")
        lines.append("    aws_ssm as ssm,")
        lines.append(")")
        lines.append("from constructs import Construct")
        lines.append("")
        lines.append("")

        # Class definition
        lines.append("class AppSyncApi(Construct):")
        lines.append('    """AppSync GraphQL API construct.')
        lines.append("")
        lines.append("    Args:")
        lines.append("        scope: CDK construct scope")
        lines.append("        id: Construct ID")
        lines.append("        tables: Dictionary of DynamoDB tables by schema name")
        if has_lambda_schemas:
            lines.append("        lambda_functions: Optional dictionary of Lambda functions")
        lines.append("        enable_api_key: Enable API_KEY authorization mode (default False)")
        lines.append("        enable_xray: Enable X-Ray tracing (default False)")
        lines.append('    """')
        lines.append("")

        # Constructor signature (Issue #72, #73)
        lines.append("    def __init__(")
        lines.append("        self,")
        lines.append("        scope: Construct,")
        lines.append("        id: str,")
        lines.append("        tables: Dict[str, dynamodb.Table],")
        if has_lambda_schemas:
            lines.append("        lambda_functions: Dict[str, lambda_.IFunction] | None = None,")
        lines.append("        enable_api_key: bool = False,")
        lines.append("        enable_xray: bool = False,")
        lines.append("    ) -> None:")

        lines.append("        super().__init__(scope, id)")
        lines.append("")

        # Schema path calculation
        lines.append("        # Calculate schema path relative to this file")
        lines.append(f'        schema_path = Path(__file__).parent / "{graphql_schema_path}"')
        lines.append("")

        # Get User Pool ID from SSM using naming convention (Issue #72)
        lines.append("        # Get User Pool ID from SSM")
        lines.append("        user_pool_id = ssm.StringParameter.value_for_string_parameter(")
        lines.append(f'            self, "{user_pool_ssm_path}"')
        lines.append("        )")
        lines.append("        user_pool = cognito.UserPool.from_user_pool_id(")
        lines.append('            self, "UserPool", user_pool_id')
        lines.append("        )")
        lines.append("")

        # Create logging role
        lines.append("        # Create CloudWatch Logs role for AppSync")
        lines.append("        logging_role = iam.Role(")
        lines.append('            self, "AppSyncLoggingRole",')
        lines.append('            assumed_by=iam.ServicePrincipal("appsync.amazonaws.com"),')
        lines.append("            managed_policies=[")
        lines.append("                iam.ManagedPolicy.from_aws_managed_policy_name(")
        lines.append('                    "service-role/AWSAppSyncPushToCloudWatchLogs"')
        lines.append("                ),")
        lines.append("            ],")
        lines.append("        )")
        lines.append("")

        # Build additional auth modes (Issue #72)
        lines.append("        # Build additional authorization modes")
        lines.append("        additional_auth_modes = []")
        lines.append("        if enable_api_key:")
        lines.append("            additional_auth_modes.append(")
        lines.append("                appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.API_KEY,")
        lines.append("                )")
        lines.append("            )")
        lines.append("")

        # Create GraphQL API using naming convention (Issue #72)
        lines.append("        # Create GraphQL API")
        lines.append("        self.api = appsync.GraphqlApi(")
        lines.append('            self, "Api",')
        lines.append(f'            name="{api_name}",')
        lines.append("            definition=appsync.Definition.from_file(str(schema_path)),")
        lines.append("            authorization_config=appsync.AuthorizationConfig(")
        lines.append("                default_authorization=appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.USER_POOL,")
        lines.append("                    user_pool_config=appsync.UserPoolConfig(")
        lines.append("                        user_pool=user_pool,")
        lines.append("                    ),")
        lines.append("                ),")
        lines.append(
            "                additional_authorization_modes=additional_auth_modes if additional_auth_modes else None,"
        )
        lines.append("            ),")
        lines.append("            log_config=appsync.LogConfig(")
        lines.append("                field_log_level=appsync.FieldLogLevel.ALL,")
        lines.append("                exclude_verbose_content=False,")
        lines.append("                role=logging_role,")
        lines.append("            ),")
        lines.append("            xray_enabled=enable_xray,")
        lines.append("        )")
        lines.append("")

        # SSM Parameters - always created using naming convention (Issue #72)
        lines.append("        # SSM Parameters for API discovery")
        lines.append("        ssm.StringParameter(")
        lines.append('            self, "ApiIdParameter",')
        lines.append(f'            parameter_name="{api_id_param}",')
        lines.append("            string_value=self.api.api_id,")
        lines.append("        )")
        lines.append("")
        lines.append("        ssm.StringParameter(")
        lines.append('            self, "GraphqlUrlParameter",')
        lines.append(f'            parameter_name="{graphql_url_param}",')
        lines.append("            string_value=self.api.graphql_url,")
        lines.append("        )")
        lines.append("")

        # Add data sources and resolvers for table schemas
        if has_table_schemas:
            lines.append("        # Add DynamoDB data sources and resolvers")
            for name, schema in schemas.items():
                if isinstance(schema, TableSchema) and schema.type == "dynamodb":
                    lines.extend(self._generate_data_source_and_resolvers_py(schema))

        # Issue #68: Generate Lambda data sources for type: lambda schemas
        if has_lambda_schemas:
            lines.append("")
            lines.append("        # Add Lambda data sources and resolvers")
            for name, schema in schemas.items():
                schema_type = getattr(schema, "type", None)
                if schema_type == "lambda":
                    lines.extend(self._generate_lambda_data_source_and_resolvers_py(schema))

        return "\n".join(lines)

    def _generate_index_py(self, schemas: Dict[str, Any]) -> str:
        """
        Generate Python __init__.py file that exports all constructs.

        Args:
            schemas: Dictionary of schema objects

        Returns:
            Python __init__.py code
        """
        lines = []
        lines.append(self._get_file_header("python").rstrip())

        # Import table constructs
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                snake_name = self._to_snake_case(name)
                lines.append(f"from .tables.{snake_name}_table import {name}Table")

        lines.append("from .appsync.api import AppSyncApi")
        lines.append("")

        # __all__ export
        lines.append("__all__ = [")
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                lines.append(f'    "{name}Table",')
        lines.append('    "AppSyncApi",')
        lines.append("]")

        return "\n".join(lines)

    def _generate_tables_init_py(self, schemas: Dict[str, Any]) -> str:
        """Generate __init__.py for tables subdirectory."""
        lines = []
        lines.append(self._get_file_header("python").rstrip())

        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                snake_name = self._to_snake_case(name)
                lines.append(f"from .{snake_name}_table import {name}Table")

        return "\n".join(lines)

    # =========================================================================
    # CDK STACK GENERATION METHODS
    # =========================================================================

    def _get_stack_output_dir(self) -> Path:
        """Get the output directory for stack files."""
        if self.config.cdk_stack_output_dir:
            return self.config.cdk_stack_output_dir
        # Default to parent of cdk_output_dir
        return Path(self.config.cdk_output_dir).parent

    def _get_import_prefix_from_stack(self) -> str:
        """
        Calculate the absolute import prefix from stack_output_dir to cdk_output_dir.

        Returns the import path as seen from the project root (where CDK runs).
        For cdk_output_dir='infrastructure/cdk', returns 'cdk'.
        For cdk_output_dir='infrastructure/backend/cdk', returns 'backend.cdk'.

        Raises:
            ConfigurationError: If cdk_output_dir is outside stack_output_dir.
        """
        stack_dir = self._get_stack_output_dir()
        cdk_dir = Path(self.config.cdk_output_dir)

        # Calculate path from stack_output_dir (project root) to cdk_output_dir
        try:
            rel_path = cdk_dir.relative_to(stack_dir)
            # Convert path to Python import format: a/b/c → a.b.c
            return ".".join(rel_path.parts)
        except ValueError:
            # cdk_dir is not under stack_dir - invalid configuration
            raise ConfigurationError(
                f"cdk_output_dir ({cdk_dir}) must be inside stack_output_dir ({stack_dir}). "
                f"CDK runs from stack_output_dir, so cdk_output_dir must be accessible from there."
            )

    def _get_project_name_pascal(self) -> str:
        """Get project name in PascalCase for class names."""
        name = self.config.project_name
        # Convert kebab-case or snake_case to PascalCase
        parts = re.split(r"[-_]", name)
        return "".join(part.capitalize() for part in parts)

    def _get_project_name_kebab(self) -> str:
        """Get project name in kebab-case for file names."""
        name = self.config.project_name
        # Convert to kebab-case
        return re.sub(r"[_\s]", "-", name).lower()

    # =========================================================================
    # MULTI-API GENERATION METHODS (Issue #83)
    # =========================================================================

    def generate_multi_api(self, schemas: Dict[str, Any]) -> None:
        """Generate CDK constructs for all API definitions.

        This method is called when api_definitions are configured.
        Each API definition gets its own CDK construct file.

        Args:
            schemas: Dictionary of all schema objects
        """
        from ..core.validators import validate_all_api_definitions

        api_definitions = self.config.api_definitions
        if not api_definitions:
            logger.warning("No API definitions configured for multi-API generation")
            return

        # Validate all API definitions against available schemas
        validate_all_api_definitions(api_definitions, schemas)

        # Generate table constructs (shared across all APIs)
        table_count = 0
        for name, schema in schemas.items():
            if isinstance(schema, TableSchema):
                content = self._generate_table_construct_py(schema)
                file_name = self._to_snake_case(name) + "_table.py"
                output_path = Path(self.config.cdk_output_dir) / "tables" / file_name
                self._write_file(output_path, content)
                table_count += 1

        logger.info(success(f"Generated {table_count} CDK table constructs (Python)"))

        # Generate API construct for each API definition
        for api_def in api_definitions:
            self._generate_api_construct_for_definition(schemas, api_def)

        # Generate combined __init__.py with all API exports
        self._generate_multi_api_init_py(api_definitions)

        logger.info(success(f"Generated CDK constructs for {len(api_definitions)} APIs"))

    def _generate_api_construct_for_definition(
        self, schemas: Dict[str, Any], api_def: "ApiDefinition"
    ) -> None:
        """Generate CDK API construct for a specific API definition.

        Args:
            schemas: Dictionary of all schema objects
            api_def: API definition with auth config and table filters
        """
        # Filter schemas to only those in the API's tables list
        filtered_schemas = {
            name: schema for name, schema in schemas.items() if name in api_def.tables
        }

        # Generate class name from API name (e.g., "sdk" -> "AppSyncSdkApi")
        api_name_parts = re.split(r"[-_]", api_def.name)
        class_name = "AppSync" + "".join(part.capitalize() for part in api_name_parts) + "Api"

        content = self._generate_api_construct_for_auth_py(filtered_schemas, api_def, class_name)

        # Write to API-specific output path
        file_name = self._to_snake_case(class_name) + ".py"
        output_path = api_def.cdk_output / file_name
        self._write_file(output_path, content)

        # Also create __init__.py in the API directory
        init_content = self._get_file_header("python")
        init_content += f"from .{self._to_snake_case(class_name)} import {class_name}\n"
        init_path = api_def.cdk_output / "__init__.py"
        self._write_file(init_path, init_content)

        logger.info(success(f"Generated CDK construct for API: {api_def.name}"))

    def _generate_api_construct_for_auth_py(
        self,
        schemas: Dict[str, Any],
        api_def: "ApiDefinition",
        class_name: str,
    ) -> str:
        """Generate Python AppSync API construct with specific auth configuration.

        Args:
            schemas: Filtered dictionary of schema objects for this API
            api_def: API definition with auth configuration
            class_name: Name for the generated class

        Returns:
            Python CDK construct code
        """
        auth = api_def.auth
        has_lambda_auth = auth.default == "AWS_LAMBDA"
        has_cognito_auth = auth.default == "AMAZON_COGNITO_USER_POOLS"
        has_oidc_auth = auth.default == "OPENID_CONNECT"
        has_api_key = "API_KEY" in auth.additional or auth.default == "API_KEY"

        # Check if any Lambda schemas exist
        has_lambda_schemas = any(
            getattr(schema, "type", None) == "lambda" for schema in schemas.values()
        )

        lines = []
        lines.append(self._get_file_header("python").rstrip())

        # Imports
        lines.append("from pathlib import Path")
        lines.append("from typing import Dict, Optional")
        lines.append("")
        lines.append("from aws_cdk import (")
        lines.append("    aws_appsync as appsync,")
        if has_cognito_auth:
            lines.append("    aws_cognito as cognito,")
        lines.append("    aws_dynamodb as dynamodb,")
        lines.append("    aws_iam as iam,")
        if has_lambda_schemas or has_lambda_auth:
            lines.append("    aws_lambda as lambda_,")
        lines.append("    aws_ssm as ssm,")
        lines.append(")")
        lines.append("from constructs import Construct")
        lines.append("")
        lines.append("")

        # Class definition
        lines.append(f"class {class_name}(Construct):")
        lines.append(f'    """AppSync API construct for {api_def.name}."""')
        lines.append("")

        # Constructor with appropriate parameters based on auth mode
        if has_lambda_auth:
            lines.append("    def __init__(")
            lines.append("        self,")
            lines.append("        scope: Construct,")
            lines.append("        id: str,")
            lines.append("        tables: Dict[str, dynamodb.Table],")
            lines.append("        lambda_authorizer: lambda_.IFunction,")
            lines.append("    ) -> None:")
        else:
            lines.append("    def __init__(")
            lines.append("        self,")
            lines.append("        scope: Construct,")
            lines.append("        id: str,")
            lines.append("        tables: Dict[str, dynamodb.Table],")
            lines.append("    ) -> None:")

        lines.append("        super().__init__(scope, id)")
        lines.append("")

        # Generate authorization configuration based on auth mode
        if has_cognito_auth:
            lines.extend(self._generate_cognito_auth_config_py(api_def))
        elif has_lambda_auth:
            lines.extend(self._generate_lambda_auth_config_py(api_def))
        elif has_oidc_auth:
            lines.extend(self._generate_oidc_auth_config_py(api_def))
        else:
            # IAM or API_KEY default
            lines.extend(self._generate_iam_auth_config_py(api_def))

        # SSM parameters for API discovery
        api_name_snake = self._to_snake_case(
            api_def.name.replace("${project}", "").replace("${env}", "")
        )
        api_id_param = self._get_ssm_parameter_path("appsync", api_name_snake, "api-id")
        graphql_url_param = self._get_ssm_parameter_path("appsync", api_name_snake, "graphql-url")

        lines.append("")
        lines.append("        # SSM Parameters for API discovery")
        lines.append("        ssm.StringParameter(")
        lines.append('            self, "ApiIdParam",')
        lines.append(f'            parameter_name="{api_id_param}",')
        lines.append("            string_value=self.api.api_id,")
        lines.append("        )")
        lines.append("")
        lines.append("        ssm.StringParameter(")
        lines.append('            self, "GraphQLUrlParam",')
        lines.append(f'            parameter_name="{graphql_url_param}",')
        lines.append("            string_value=self.api.graphql_url,")
        lines.append("        )")

        # Add API key SSM parameter if enabled
        if has_api_key:
            api_key_param = self._get_ssm_parameter_path("appsync", api_name_snake, "api-key")
            lines.append("")
            lines.append("        ssm.StringParameter(")
            lines.append('            self, "ApiKeyParam",')
            lines.append(f'            parameter_name="{api_key_param}",')
            lines.append("            string_value=self.api_key.attr_api_key,")
            lines.append("        )")

        return "\n".join(lines)

    def _generate_cognito_auth_config_py(self, api_def: "ApiDefinition") -> List[str]:
        """Generate Cognito authorization configuration."""
        lines = []
        auth = api_def.auth
        has_api_key = "API_KEY" in auth.additional

        # Look up user pool from SSM
        user_pool_ssm = auth.cognito.user_pool_ssm_param if auth.cognito else ""
        lines.append("        # Look up Cognito User Pool from SSM")
        lines.append("        user_pool_id = ssm.StringParameter.value_for_string_parameter(")
        lines.append(f'            self, "{user_pool_ssm}"')
        lines.append("        )")
        lines.append("        user_pool = cognito.UserPool.from_user_pool_id(")
        lines.append('            self, "UserPool", user_pool_id')
        lines.append("        )")
        lines.append("")

        # Create API with Cognito auth
        lines.append("        # Create AppSync API with Cognito authorization")
        lines.append("        self.api = appsync.GraphqlApi(")
        lines.append('            self, "Api",')
        lines.append(f'            name="{api_def.name}",')
        lines.append("            definition=appsync.Definition.from_file(")
        lines.append('                str(Path(__file__).parent.parent / "schema.graphql")')
        lines.append("            ),")
        lines.append("            authorization_config=appsync.AuthorizationConfig(")
        lines.append("                default_authorization=appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.USER_POOL,")
        lines.append("                    user_pool_config=appsync.UserPoolConfig(")
        lines.append("                        user_pool=user_pool,")
        lines.append("                    ),")
        lines.append("                ),")

        if has_api_key:
            lines.append("                additional_authorization_modes=[")
            lines.append("                    appsync.AuthorizationMode(")
            lines.append(
                "                        authorization_type=appsync.AuthorizationType.API_KEY,"
            )
            lines.append("                    ),")
            lines.append("                ],")

        lines.append("            ),")
        lines.append("        )")

        if has_api_key:
            lines.append("")
            lines.append("        # Create API Key")
            lines.append("        self.api_key = self.api.add_api_key(")
            lines.append('            "ApiKey",')
            lines.append("        )")

        return lines

    def _generate_lambda_auth_config_py(self, api_def: "ApiDefinition") -> List[str]:
        """Generate Lambda authorizer configuration."""
        lines = []
        auth = api_def.auth
        lambda_auth = auth.lambda_authorizer

        ttl = lambda_auth.result_ttl_seconds if lambda_auth else 300
        identity_regex = lambda_auth.identity_validation_expression if lambda_auth else None

        lines.append("        # Create AppSync API with Lambda authorization")
        lines.append("        self.api = appsync.GraphqlApi(")
        lines.append('            self, "Api",')
        lines.append(f'            name="{api_def.name}",')
        lines.append("            definition=appsync.Definition.from_file(")
        lines.append('                str(Path(__file__).parent.parent / "schema.graphql")')
        lines.append("            ),")
        lines.append("            authorization_config=appsync.AuthorizationConfig(")
        lines.append("                default_authorization=appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.LAMBDA,")
        lines.append("                    lambda_authorizer_config=appsync.LambdaAuthorizerConfig(")
        lines.append("                        handler=lambda_authorizer,")
        lines.append(f"                        results_cache_ttl=Duration.seconds({ttl}),")

        if identity_regex:
            lines.append(f'                        validation_regex="{identity_regex}",')

        lines.append("                    ),")
        lines.append("                ),")
        lines.append("            ),")
        lines.append("        )")
        lines.append("")
        lines.append("        # Grant AppSync permission to invoke the authorizer")
        lines.append("        lambda_authorizer.grant_invoke(")
        lines.append("            iam.ServicePrincipal('appsync.amazonaws.com')")
        lines.append("        )")

        return lines

    def _generate_oidc_auth_config_py(self, api_def: "ApiDefinition") -> List[str]:
        """Generate OIDC authorization configuration."""
        lines = []
        auth = api_def.auth
        oidc = auth.oidc

        issuer = oidc.issuer if oidc else ""
        client_id = oidc.client_id if oidc else None

        lines.append("        # Create AppSync API with OIDC authorization")
        lines.append("        self.api = appsync.GraphqlApi(")
        lines.append('            self, "Api",')
        lines.append(f'            name="{api_def.name}",')
        lines.append("            definition=appsync.Definition.from_file(")
        lines.append('                str(Path(__file__).parent.parent / "schema.graphql")')
        lines.append("            ),")
        lines.append("            authorization_config=appsync.AuthorizationConfig(")
        lines.append("                default_authorization=appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.OIDC,")
        lines.append("                    open_id_connect_config=appsync.OpenIdConnectConfig(")
        lines.append(f'                        oidc_provider="{issuer}",')

        if client_id:
            lines.append(f'                        client_id="{client_id}",')

        lines.append("                    ),")
        lines.append("                ),")
        lines.append("            ),")
        lines.append("        )")

        return lines

    def _generate_iam_auth_config_py(self, api_def: "ApiDefinition") -> List[str]:
        """Generate IAM authorization configuration."""
        lines = []
        auth = api_def.auth
        has_api_key = "API_KEY" in auth.additional or auth.default == "API_KEY"

        lines.append("        # Create AppSync API with IAM authorization")
        lines.append("        self.api = appsync.GraphqlApi(")
        lines.append('            self, "Api",')
        lines.append(f'            name="{api_def.name}",')
        lines.append("            definition=appsync.Definition.from_file(")
        lines.append('                str(Path(__file__).parent.parent / "schema.graphql")')
        lines.append("            ),")
        lines.append("            authorization_config=appsync.AuthorizationConfig(")
        lines.append("                default_authorization=appsync.AuthorizationMode(")
        lines.append("                    authorization_type=appsync.AuthorizationType.IAM,")
        lines.append("                ),")

        if has_api_key:
            lines.append("                additional_authorization_modes=[")
            lines.append("                    appsync.AuthorizationMode(")
            lines.append(
                "                        authorization_type=appsync.AuthorizationType.API_KEY,"
            )
            lines.append("                    ),")
            lines.append("                ],")

        lines.append("            ),")
        lines.append("        )")

        if has_api_key:
            lines.append("")
            lines.append("        # Create API Key")
            lines.append("        self.api_key = self.api.add_api_key(")
            lines.append('            "ApiKey",')
            lines.append("        )")

        return lines

    def _generate_multi_api_init_py(self, api_definitions: List["ApiDefinition"]) -> None:
        """Generate combined __init__.py with all API exports.

        Args:
            api_definitions: List of API definitions
        """
        lines = []
        lines.append(self._get_file_header("python").rstrip())
        lines.append("")

        # Import all API constructs
        for api_def in api_definitions:
            api_name_parts = re.split(r"[-_]", api_def.name)
            class_name = "AppSync" + "".join(part.capitalize() for part in api_name_parts) + "Api"
            module_name = self._to_snake_case(class_name)
            # Calculate relative import path
            rel_path = os.path.relpath(api_def.cdk_output, self.config.cdk_output_dir)
            import_path = rel_path.replace(os.sep, ".").replace("/", ".")
            lines.append(f"from .{import_path}.{module_name} import {class_name}")

        lines.append("")
        lines.append("__all__ = [")
        for api_def in api_definitions:
            api_name_parts = re.split(r"[-_]", api_def.name)
            class_name = "AppSync" + "".join(part.capitalize() for part in api_name_parts) + "Api"
            lines.append(f'    "{class_name}",')
        lines.append("]")

        content = "\n".join(lines)
        init_path = Path(self.config.cdk_output_dir) / "__init__.py"
        self._write_file(init_path, content)

    def _generate_stack_files(self, schemas: Dict[str, Any]) -> None:
        """Generate complete CDK stack definition files (Python only)."""
        if not getattr(self.config, "cdk_generate_stack", False):
            return

        stack_dir = self._get_stack_output_dir()
        self._generate_stack_files_py(schemas, stack_dir)

    def _generate_stack_files_py(self, schemas: Dict[str, Any], stack_dir: Path) -> None:
        """Generate Python CDK stack files."""
        stack_name = getattr(self.config, "cdk_stack_name", "backend_stack")
        stack_name_snake = self._to_snake_case(stack_name.replace("-", "_"))
        stack_class_name = self._to_pascal_case_from_snake(stack_name)

        # Generate lib/{stack_name}.py
        stack_content = self._generate_stack_py(schemas, stack_class_name)
        stack_path = stack_dir / "lib" / f"{stack_name_snake}.py"
        self._write_stack_file(stack_path, stack_content)

        # Generate lib/__init__.py
        init_content = self._get_file_header("python")
        init_path = stack_dir / "lib" / "__init__.py"
        self._write_stack_file(init_path, init_content)

        # Generate app.py
        app_content = self._generate_app_py(stack_class_name, stack_name_snake)
        app_path = stack_dir / "app.py"
        self._write_stack_file(app_path, app_content)

        # Generate cdk.json
        cdk_json_content = self._generate_cdk_json_py()
        cdk_json_path = stack_dir / "cdk.json"
        self._write_stack_file(cdk_json_path, cdk_json_content)

        logger.info(success("Generated CDK stack files (Python)"))

    def _generate_stack_py(self, schemas: Dict[str, Any], stack_class_name: str) -> str:
        """Generate Python stack class."""
        lines = []
        lines.append(self._get_file_header("python").rstrip())

        # Imports
        lines.append("from aws_cdk import Stack, CfnOutput")
        lines.append("from constructs import Construct")
        lines.append("")

        # Calculate import prefix from lib/ to cdk_output_dir
        import_prefix = self._get_import_prefix_from_stack()

        # Import generated constructs
        table_schemas = {n: s for n, s in schemas.items() if isinstance(s, TableSchema)}
        for name in table_schemas:
            snake_name = self._to_snake_case(name)
            lines.append(f"from {import_prefix}.tables.{snake_name}_table import {name}Table")
        lines.append(f"from {import_prefix}.appsync.api import AppSyncApi")
        lines.append("")
        lines.append("")

        # Stack class
        lines.append(f"class {stack_class_name}Stack(Stack):")
        lines.append('    """CDK Stack for backend infrastructure."""')
        lines.append("")
        lines.append("    def __init__(")
        lines.append("        self,")
        lines.append("        scope: Construct,")
        lines.append("        id: str,")
        lines.append("        **kwargs,")
        lines.append("    ) -> None:")
        lines.append("        super().__init__(scope, id, **kwargs)")
        lines.append("")

        # Instantiate tables
        if table_schemas:
            lines.append("        # Create DynamoDB tables")
            for name in table_schemas:
                var_name = self._to_snake_case(name)
                lines.append(f"        {var_name}_table = {name}Table(self, '{name}Table')")
            lines.append("")

        # Instantiate API with tables
        lines.append("        # Create AppSync API with table references")
        lines.append("        api = AppSyncApi(")
        lines.append("            self,")
        lines.append('            "AppSyncApi",')
        lines.append("            tables={")
        for name in table_schemas:
            var_name = self._to_snake_case(name)
            lines.append(f'                "{name}": {var_name}_table.table,')
        lines.append("            },")
        lines.append("        )")
        lines.append("")

        # Outputs
        lines.append("        # CloudFormation Outputs")
        lines.append("        CfnOutput(")
        lines.append('            self, "GraphQLApiUrl",')
        lines.append("            value=api.api.graphql_url,")
        lines.append('            description="GraphQL API URL",')
        lines.append("        )")
        lines.append("")

        for name in table_schemas:
            var_name = self._to_snake_case(name)
            lines.append("        CfnOutput(")
            lines.append(f'            self, "{name}TableName",')
            lines.append(f"            value={var_name}_table.table.table_name,")
            lines.append(f'            description="{name} DynamoDB table name",')
            lines.append("        )")
            lines.append("")

        return "\n".join(lines)

    def _generate_app_py(self, stack_class_name: str, stack_name_snake: str) -> str:
        """Generate Python app entry point."""
        lines = []
        lines.append("#!/usr/bin/env python3")
        lines.append(self._get_file_header("python").rstrip())

        lines.append("import os")
        lines.append("import aws_cdk as cdk")
        lines.append(f"from lib.{stack_name_snake} import {stack_class_name}Stack")
        lines.append("")
        lines.append("app = cdk.App()")
        lines.append("")
        lines.append('env_name = app.node.try_get_context("environment") or "dev"')
        lines.append("")
        lines.append(f"{stack_class_name}Stack(")
        lines.append("    app,")
        lines.append(f'    f"{stack_class_name}Stack-{{env_name}}",')
        lines.append("    env=cdk.Environment(")
        lines.append('        account=os.environ.get("CDK_DEFAULT_ACCOUNT"),')
        lines.append('        region=os.environ.get("CDK_DEFAULT_REGION"),')
        lines.append("    ),")
        lines.append("    tags={")
        lines.append('        "Environment": env_name,')
        lines.append('        "ManagedBy": "CDK",')
        lines.append("    },")
        lines.append(")")
        lines.append("")
        lines.append("app.synth()")

        return "\n".join(lines)

    def _generate_cdk_json_py(self) -> str:
        """Generate cdk.json for Python."""
        import json

        cdk_config = {
            "app": "python app.py",
            "watch": {"include": ["**"], "exclude": ["cdk.out", "**/__pycache__"]},
            "context": {"environment": "dev"},
        }
        return json.dumps(cdk_config, indent=2)

    def _write_stack_file(self, path: Path, content: str) -> None:
        """Write stack file, warning if it already exists."""
        if path.exists():
            logger.warning(
                f"Stack file already exists: {path}. "
                "Skipping to preserve customizations. "
                "Delete manually to regenerate."
            )
            return
        self._write_file(path, content)

    def _to_camel_case(self, text: str) -> str:
        """Convert PascalCase to camelCase."""
        if not text:
            return ""
        return text[0].lower() + text[1:]

    def _to_pascal_case_from_snake(self, text: str) -> str:
        """Convert snake_case or kebab-case to PascalCase."""
        if not text:
            return ""
        parts = re.split(r"[-_]", text)
        return "".join(part.capitalize() for part in parts)
