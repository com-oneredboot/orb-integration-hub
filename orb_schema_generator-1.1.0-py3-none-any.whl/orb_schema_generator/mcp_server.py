"""MCP Server for AI assistant integration.

This module implements the Model Context Protocol (MCP) server for the
orb-schema-generator, enabling AI assistants like Kiro to interact with
schema generation functionality.

**Feature: v0.9.2-graphql-validation-mcp**
**Validates: Requirements 4.1-4.6, 5.1-5.4**
"""

import asyncio
import logging
import json
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

logger = logging.getLogger(__name__)

# Create server instance
server = Server("orb-schema-generator")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """
    Return list of available tools.

    **Validates: Requirements 4.3**
    """
    return [
        Tool(
            name="list_schemas",
            description="List all available schemas in a directory",
            inputSchema={
                "type": "object",
                "properties": {
                    "schema_dir": {
                        "type": "string",
                        "description": "Path to schema directory",
                    }
                },
                "required": ["schema_dir"],
            },
        ),
        Tool(
            name="inspect_schema",
            description="Get detailed information about a schema file",
            inputSchema={
                "type": "object",
                "properties": {
                    "schema_file": {
                        "type": "string",
                        "description": "Path to schema file",
                    }
                },
                "required": ["schema_file"],
            },
        ),
        Tool(
            name="validate_schema",
            description="Validate schema files in a directory",
            inputSchema={
                "type": "object",
                "properties": {
                    "schema_dir": {
                        "type": "string",
                        "description": "Path to schema directory",
                    }
                },
                "required": ["schema_dir"],
            },
        ),
        Tool(
            name="generate_from_schema",
            description="Generate code from schema files",
            inputSchema={
                "type": "object",
                "properties": {
                    "config_file": {
                        "type": "string",
                        "description": "Path to schema-generator.yml configuration file",
                    },
                    "formats": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Formats to generate (python, typescript, graphql, cdk)",
                    },
                },
                "required": ["config_file"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """
    Handle tool calls.

    **Validates: Requirements 4.4, 4.6**
    """
    try:
        if name == "list_schemas":
            result = _list_schemas(arguments)
        elif name == "inspect_schema":
            result = _inspect_schema(arguments)
        elif name == "validate_schema":
            result = _validate_schema(arguments)
        elif name == "generate_from_schema":
            result = _generate_from_schema(arguments)
        else:
            result = {"error": f"Unknown tool: {name}"}

        return [TextContent(type="text", text=json.dumps(result, indent=2))]
    except Exception as e:
        logger.error(f"Tool call failed: {e}")
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


def _list_schemas(args: dict[str, Any]) -> dict[str, Any]:
    """
    List all schemas in a directory.

    **Validates: Requirements 4.4**
    """
    from .core.config import GeneratorConfig
    from .core.loaders import SchemaLoader

    schema_dir = args.get("schema_dir")
    if not schema_dir:
        return {"error": "schema_dir is required"}

    try:
        config = GeneratorConfig()
        config.schema_dir = Path(schema_dir)

        loader = SchemaLoader(config)
        schemas = loader.load_all_schemas()

        schema_list = [
            {
                "name": name,
                "type": schema.type if hasattr(schema, "type") else "unknown",
            }
            for name, schema in schemas.items()
        ]

        return {
            "success": True,
            "schemas": schema_list,
            "count": len(schema_list),
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def _inspect_schema(args: dict[str, Any]) -> dict[str, Any]:
    """
    Inspect a schema file and return its details.

    **Validates: Requirements 4.5**
    """
    import yaml

    schema_file = args.get("schema_file")
    if not schema_file:
        return {"error": "schema_file is required"}

    try:
        with open(schema_file, "r", encoding="utf-8") as f:
            schema_dict = yaml.safe_load(f)

        info: dict[str, Any] = {
            "name": schema_dict.get("name"),
            "type": schema_dict.get("type"),
            "version": schema_dict.get("version"),
        }

        if "model" in schema_dict:
            model = schema_dict["model"]
            info["attributes"] = list(model.get("attributes", {}).keys())

            if "keys" in model:
                keys = model["keys"]
                if "primary" in keys:
                    info["partition_key"] = keys["primary"].get("partition")
                    info["sort_key"] = keys["primary"].get("sort")
                if "secondary" in keys:
                    info["secondary_indexes"] = len(keys["secondary"])

        return {"success": True, "schema": info}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _validate_schema(args: dict[str, Any]) -> dict[str, Any]:
    """
    Validate schemas in a directory.

    **Validates: Requirements 4.5**
    """
    from .core.config import GeneratorConfig
    from .generator import SchemaGenerator

    schema_dir = args.get("schema_dir")
    if not schema_dir:
        return {"error": "schema_dir is required"}

    try:
        config = GeneratorConfig()
        config.schema_dir = Path(schema_dir)

        generator = SchemaGenerator(config)
        generator.validate_schemas()

        return {"success": True, "message": "All schemas are valid"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _generate_from_schema(args: dict[str, Any]) -> dict[str, Any]:
    """
    Generate code from schemas using configuration file.

    **Validates: Requirements 4.4**
    """
    from .fluent_api import Generator

    config_file = args.get("config_file")
    formats = args.get("formats", [])

    if not config_file:
        return {"error": "config_file is required"}

    try:
        gen = Generator.from_config(config_file)

        # Apply format filters if specified
        if formats:
            if "python" in formats and len(formats) == 1:
                gen = gen.python_only()
            elif "typescript" in formats and len(formats) == 1:
                gen = gen.typescript_only()
            elif "graphql" in formats and len(formats) == 1:
                gen = gen.graphql_only()
            elif "cdk" in formats and len(formats) == 1:
                gen = gen.cdk_only()

        result = gen.generate()

        return {
            "success": True,
            "result": result,
            "message": f"Generated {result.get('files_count', 0)} files",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


async def main() -> None:
    """
    Run the MCP server.

    **Validates: Requirements 5.1, 5.2**
    """
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
