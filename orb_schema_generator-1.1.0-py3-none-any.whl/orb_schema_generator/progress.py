"""Progress tracking for schema generation."""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from enum import Enum
import time


class Stage(Enum):
    """Generation stages."""

    LOADING = "loading"
    VALIDATING = "validating"
    BUILDING_OPERATIONS = "building_operations"
    GENERATING_PYTHON = "generating_python"
    GENERATING_TYPESCRIPT = "generating_typescript"
    GENERATING_GRAPHQL = "generating_graphql"
    GENERATING_CDK = "generating_cdk"
    COMPLETE = "complete"


@dataclass
class ProgressTracker:
    """
    Tracks progress of schema generation.

    Provides percentage completion, current stage, and timing information.
    """

    def __init__(self):
        """Initialize progress tracker."""
        self.total_steps = 0
        self.completed_steps = 0
        self.current_stage: Optional[Stage] = None
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.stage_times: Dict[Stage, float] = {}
        self._stage_start_time: Optional[float] = None

    def start(self, total_steps: int = 0) -> None:
        """
        Start tracking progress.

        Args:
            total_steps: Total number of steps (0 for unknown)
        """
        self.total_steps = total_steps
        self.completed_steps = 0
        self.start_time = time.time()
        self.end_time = None
        self.stage_times.clear()

    def set_stage(self, stage: Stage) -> None:
        """
        Set the current stage.

        Args:
            stage: Current generation stage
        """
        # Record time for previous stage
        if self.current_stage and self._stage_start_time:
            elapsed = time.time() - self._stage_start_time
            self.stage_times[self.current_stage] = elapsed

        self.current_stage = stage
        self._stage_start_time = time.time()

    def step(self, count: int = 1) -> None:
        """
        Increment completed steps.

        Args:
            count: Number of steps to increment
        """
        self.completed_steps += count

    def complete(self) -> None:
        """Mark generation as complete."""
        self.end_time = time.time()

        # Record final stage time
        if self.current_stage and self._stage_start_time:
            elapsed = time.time() - self._stage_start_time
            self.stage_times[self.current_stage] = elapsed

        self.current_stage = Stage.COMPLETE

    @property
    def percentage(self) -> int:
        """
        Get completion percentage.

        Returns:
            Percentage complete (0-100)
        """
        if self.total_steps == 0:
            return 0
        return min(100, int((self.completed_steps / self.total_steps) * 100))

    @property
    def elapsed_time(self) -> float:
        """
        Get elapsed time in seconds.

        Returns:
            Elapsed time since start
        """
        if not self.start_time:
            return 0.0

        end = self.end_time or time.time()
        return end - self.start_time

    @property
    def is_complete(self) -> bool:
        """Check if generation is complete."""
        return self.current_stage == Stage.COMPLETE

    def get_summary(self) -> Dict[str, Any]:
        """
        Get progress summary.

        Returns:
            Dictionary with progress information
        """
        return {
            "total_steps": self.total_steps,
            "completed_steps": self.completed_steps,
            "percentage": self.percentage,
            "current_stage": self.current_stage.value if self.current_stage else None,
            "elapsed_time": self.elapsed_time,
            "is_complete": self.is_complete,
            "stage_times": {stage.value: duration for stage, duration in self.stage_times.items()},
        }

    def __repr__(self) -> str:
        return (
            f"ProgressTracker(stage={self.current_stage.value if self.current_stage else 'none'}, "
            f"progress={self.completed_steps}/{self.total_steps}, "
            f"percentage={self.percentage}%, "
            f"elapsed={self.elapsed_time:.2f}s)"
        )
