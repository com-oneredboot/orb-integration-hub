"""Event system for schema generation."""

from enum import Enum
from typing import Callable, List, Any, Optional, Dict
import asyncio
import logging

logger = logging.getLogger(__name__)


class EventType(Enum):
    """Event types for schema generation."""

    START = "start"
    PROGRESS = "progress"
    FILE_GENERATED = "file_generated"
    SCHEMA_LOADED = "schema_loaded"
    SCHEMA_VALIDATED = "schema_validated"
    STAGE_COMPLETE = "stage_complete"
    COMPLETE = "complete"
    ERROR = "error"
    WARNING = "warning"


class Event:
    """Event data container."""

    def __init__(self, event_type: EventType, data: Optional[Dict[str, Any]] = None):
        """
        Initialize event.

        Args:
            event_type: Type of event
            data: Event data dictionary
        """
        self.type = event_type
        self.data = data or {}

    def __repr__(self) -> str:
        return f"Event(type={self.type.value}, data={self.data})"


class EventEmitter:
    """
    Event emitter for schema generation events.

    Supports both synchronous and asynchronous callbacks.
    """

    def __init__(self):
        """Initialize event emitter."""
        self._listeners: Dict[EventType, List[Callable]] = {}
        self._async_listeners: Dict[EventType, List[Callable]] = {}

    def on(self, event_type: EventType, callback: Callable) -> "EventEmitter":
        """
        Register a synchronous event listener.

        Args:
            event_type: Type of event to listen for
            callback: Function to call when event occurs

        Returns:
            Self for chaining
        """
        if event_type not in self._listeners:
            self._listeners[event_type] = []

        self._listeners[event_type].append(callback)
        logger.debug(f"Registered listener for {event_type.value}")
        return self

    def on_async(self, event_type: EventType, callback: Callable) -> "EventEmitter":
        """
        Register an asynchronous event listener.

        Args:
            event_type: Type of event to listen for
            callback: Async function to call when event occurs

        Returns:
            Self for chaining
        """
        if event_type not in self._async_listeners:
            self._async_listeners[event_type] = []

        self._async_listeners[event_type].append(callback)
        logger.debug(f"Registered async listener for {event_type.value}")
        return self

    def emit(self, event: Event) -> None:
        """
        Emit an event to all registered listeners.

        Args:
            event: Event to emit
        """
        # Call synchronous listeners
        if event.type in self._listeners:
            for callback in self._listeners[event.type]:
                try:
                    callback(event)
                except Exception as e:
                    logger.error(f"Error in event listener for {event.type.value}: {e}")

        # Call async listeners (if in async context)
        if event.type in self._async_listeners:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    for callback in self._async_listeners[event.type]:
                        asyncio.create_task(self._call_async_listener(callback, event))
            except RuntimeError:
                # No event loop running, skip async listeners
                pass

    async def emit_async(self, event: Event) -> None:
        """
        Emit an event asynchronously to all registered listeners.

        Args:
            event: Event to emit
        """
        # Call synchronous listeners
        if event.type in self._listeners:
            for callback in self._listeners[event.type]:
                try:
                    callback(event)
                except Exception as e:
                    logger.error(f"Error in event listener for {event.type.value}: {e}")

        # Call async listeners
        if event.type in self._async_listeners:
            tasks = [
                self._call_async_listener(callback, event)
                for callback in self._async_listeners[event.type]
            ]
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _call_async_listener(self, callback: Callable, event: Event) -> None:
        """
        Call an async listener with error handling.

        Args:
            callback: Async callback function
            event: Event to pass to callback
        """
        try:
            await callback(event)
        except Exception as e:
            logger.error(f"Error in async event listener for {event.type.value}: {e}")

    def off(self, event_type: EventType, callback: Optional[Callable] = None) -> "EventEmitter":
        """
        Remove event listener(s).

        Args:
            event_type: Type of event
            callback: Specific callback to remove, or None to remove all

        Returns:
            Self for chaining
        """
        if callback is None:
            # Remove all listeners for this event type
            if event_type in self._listeners:
                del self._listeners[event_type]
            if event_type in self._async_listeners:
                del self._async_listeners[event_type]
        else:
            # Remove specific listener
            if event_type in self._listeners and callback in self._listeners[event_type]:
                self._listeners[event_type].remove(callback)
            if (
                event_type in self._async_listeners
                and callback in self._async_listeners[event_type]
            ):
                self._async_listeners[event_type].remove(callback)

        return self

    def clear(self) -> None:
        """Remove all event listeners."""
        self._listeners.clear()
        self._async_listeners.clear()
        logger.debug("Cleared all event listeners")
