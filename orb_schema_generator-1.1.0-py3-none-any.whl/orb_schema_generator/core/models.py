"""Core data models for schema generation."""

from dataclasses import dataclass, field as dataclass_field
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator


class SchemaType(str, Enum):
    """Supported schema types."""

    STANDARD = "standard"
    DYNAMODB = "dynamodb"
    LAMBDA = "lambda"
    LAMBDA_DYNAMODB = "lambda-dynamodb"
    GRAPHQL = "graphql"
    REGISTRY = "registry"
    S3 = "s3"


class SchemaValidationError(Exception):
    """Raised when schema validation fails."""

    pass


class ConfigurationError(Exception):
    """Raised when generator configuration is invalid."""

    pass


class MissingLanguageTargetsError(ConfigurationError):
    """Raised when a language is enabled but has no targets configuration."""

    def __init__(self, language: str):
        self.language = language
        super().__init__(
            f"Language '{language}' is enabled but has no 'targets' configuration. "
            f"Add a 'targets' map under output.{language} in your configuration."
        )


class MissingTargetsError(SchemaValidationError):
    """Raised when a schema is missing the required 'targets' field."""

    def __init__(self, schema_name: str, schema_path: str):
        self.schema_name = schema_name
        self.schema_path = schema_path
        super().__init__(
            f"Schema '{schema_name}' is missing required 'targets' field: {schema_path}\n"
            f"Since v0.12.0, all schemas must have a 'targets' array:\n"
            f"  targets:\n"
            f"    - api  # or your target name"
        )


class InvalidTargetsError(SchemaValidationError):
    """Raised when a schema has invalid 'targets' field."""

    def __init__(self, schema_name: str, message: str):
        self.schema_name = schema_name
        super().__init__(f"Schema '{schema_name}' has invalid 'targets': {message}")


class ReferenceResolutionError(SchemaValidationError):
    """Raised when a $ref or object_ref cannot be resolved."""

    def __init__(
        self,
        ref_type: str,
        ref_name: str,
        attr_name: str,
        schema_name: str,
        available_models: List[str],
    ):
        self.ref_type = ref_type
        self.ref_name = ref_name
        self.attr_name = attr_name
        self.schema_name = schema_name
        self.available_models = available_models
        super().__init__(
            f"Cannot resolve {ref_type} '{ref_name}' in attribute '{attr_name}' "
            f"of schema '{schema_name}'. Available models: {sorted(available_models)}"
        )


# =============================================================================
# OPERATION CLASSIFICATION UTILITIES
# =============================================================================


def classify_operation_response_type(operation: "Operation") -> str:
    """
    Classify an operation to determine its response format.

    Used by GraphQL query generators to determine whether to use:
    - 'singular' response: envelope fields + `item` (for mutations and Get)
    - 'list' response: envelope fields + `items` + `nextToken` (for List operations)

    Args:
        operation: Operation object with name, type, and field attributes

    Returns:
        'singular' for mutations and get operations (use `item`)
        'list' for list operations (use `items` + `nextToken`)
    """
    # Mutations always use singular response
    if operation.type == "Mutation":
        return "singular"

    # Get operations use singular response
    if operation.field.endswith("Get"):
        return "singular"

    # ListBy operations use list response
    if "ListBy" in operation.field:
        return "list"

    # Default: queries use list response
    return "list"


# =============================================================================
# AUTH DIRECTIVE UTILITIES
# =============================================================================


def get_auth_directives_from_config(
    auth_config: Optional[Dict[str, Any]], operation_name: str
) -> List[str]:
    """
    Extract auth directives from an auth_config for a given operation.

    This is a shared utility used by both OperationBuilder (for TableSchema)
    and GraphQLGenerator (for LambdaType) to ensure consistent auth directive
    generation.

    Args:
        auth_config: Auth configuration dict with apiKeyAuthentication and/or
                     cognitoAuthentication keys
        operation_name: Name of the operation to get directives for

    Returns:
        List of auth directive strings (e.g., ["@aws_api_key", "@aws_auth(...)"])
    """
    directives: List[str] = []

    if not auth_config:
        return directives

    # API Key authentication
    api_key_ops = auth_config.get("apiKeyAuthentication", [])
    if operation_name in api_key_ops:
        directives.append("@aws_api_key")

    # Cognito group authentication
    cognito_auth = auth_config.get("cognitoAuthentication", {})
    if isinstance(cognito_auth, dict):
        groups = cognito_auth.get("groups", {})
        allowed_groups = []

        for group, ops in groups.items():
            if isinstance(ops, list) and ("*" in ops or operation_name in ops):
                allowed_groups.append(group)

        if allowed_groups:
            group_list = ", ".join(f'"{g}"' for g in sorted(allowed_groups))
            directives.append(f"@aws_auth(cognito_groups: [{group_list}])")

    return directives


class SchemaField(BaseModel):
    """Schema field definition."""

    type: str
    required: bool = False
    description: Optional[str] = None
    validation: Optional[Dict[str, Any]] = None
    enum_type: Optional[str] = None
    items: Optional[Dict[str, Any]] = None


class SchemaIndex(BaseModel):
    """Schema index definition for DynamoDB."""

    type: str = Field(..., description="Type of index (GSI or LSI)")
    partition: str = Field(..., description="Partition key for the index")
    sort: Optional[str] = Field(None, description="Sort key for the index")
    name: Optional[str] = Field(None, description="Name of the index")
    description: Optional[str] = Field(None, description="Description of the index")
    projection_type: str = Field("ALL", description="Projection type: ALL, KEYS_ONLY, or INCLUDE")
    projected_attributes: Optional[List[str]] = Field(
        None, description="List of attributes to project when projection_type is INCLUDE"
    )

    @field_validator("type")
    @classmethod
    def validate_index_type(cls, v: str) -> str:
        if v not in ["GSI", "LSI"]:
            raise ValueError("Index type must be either GSI or LSI")
        return v

    @field_validator("projection_type")
    @classmethod
    def validate_projection_type(cls, v: str) -> str:
        if v not in ["ALL", "KEYS_ONLY", "INCLUDE"]:
            raise ValueError("Projection type must be ALL, KEYS_ONLY, or INCLUDE")
        return v

    @field_validator("projected_attributes")
    @classmethod
    def validate_projected_attributes(
        cls, v: Optional[List[str]], info: Any
    ) -> Optional[List[str]]:
        if info.data.get("projection_type") == "INCLUDE" and not v:
            raise ValueError("projected_attributes is required when projection_type is INCLUDE")
        return v

    @field_validator("name")
    @classmethod
    def validate_index_name(cls, v: Optional[str]) -> Optional[str]:
        if v:
            # DynamoDB index name requirements
            if not (3 <= len(v) <= 255):
                raise ValueError("Index name must be between 3 and 255 characters")
            if not v[0].isalpha():
                raise ValueError("Index name must start with a letter")
            if not all(c.isalnum() for c in v):
                raise ValueError("Index name can only contain alphanumeric characters")
            if not v[0].isupper():
                raise ValueError("Index name must be in PascalCase format (e.g., RoleIndex)")
        return v


@dataclass
class Attribute:
    """Attribute definition for a schema."""

    name: str
    type: str
    description: str = ""
    required: bool = True
    enum_type: Optional[str] = None
    enum_values: Optional[List[str]] = None
    # Reference resolution fields (populated by loader)
    items_ref: Optional[str] = None  # Resolved $ref from array items
    object_ref: Optional[str] = None  # Resolved object_ref for nested models
    # Default value support (#43)
    default: Optional[Any] = None
    # Validation rules support (#44)
    validation: Optional[Dict[str, Any]] = None
    # Lambda Input/Output separation (Issue #70)
    input_only: bool = False  # Include only in GraphQL Input type
    output_only: bool = False  # Include only in GraphQL Output type


@dataclass
class CustomQuery:
    """Custom query definition for advanced operations."""

    name: str
    type: str  # 'aggregation' or 'custom'
    description: str
    input: Dict[str, Any]
    returns: str
    enrichments: Optional[List[Dict[str, Any]]] = None
    implementationPath: Optional[str] = None


@dataclass
class TableSchema:
    """DynamoDB table schema definition."""

    name: str
    attributes: List[Attribute]
    partition_key: str
    pitr_enabled: bool  # Required - Point-in-Time Recovery (Issue #65)
    sort_key: str = "None"
    secondary_indexes: Optional[List[Dict[str, Any]]] = None
    auth_config: Optional[Dict[str, Any]] = None
    type: str = "dynamodb"
    stream: Optional[Dict[str, Any]] = None
    custom_queries: Optional[List[CustomQuery]] = None
    operations: List["Operation"] = dataclass_field(default_factory=list)
    targets: List[str] = dataclass_field(
        default_factory=list
    )  # Required - maps to output config targets

    def __post_init__(self) -> None:
        """Post-initialization validation and defaults."""
        if self.sort_key is None:
            self.sort_key = "None"
        if self.secondary_indexes is None:
            self.secondary_indexes = []
        if self.auth_config is None:
            self.auth_config = {
                "defaultAuth": "user_pools",
                "apiKeyOperations": [],
                "cognitoOperations": [],
            }


@dataclass
class GraphQLType:
    """GraphQL type definition."""

    name: str
    attributes: List[Attribute]
    description: Optional[str] = None
    auth_config: Optional[Dict[str, Any]] = None
    targets: List[str] = dataclass_field(
        default_factory=list
    )  # Required - maps to output config targets


@dataclass
class RegistryType:
    """Registry type definition (for static registries like ErrorRegistry)."""

    name: str
    items: dict
    description: Optional[str] = None
    type: str = "registry"
    targets: List[str] = dataclass_field(
        default_factory=list
    )  # Required - maps to output config targets


@dataclass
class StandardType:
    """Standard model definition (plain object, not tied to a data source)."""

    name: str
    attributes: List[Attribute]
    description: Optional[str] = None
    type: str = "standard"
    targets: List[str] = dataclass_field(
        default_factory=list
    )  # Required - maps to output config targets


@dataclass
class LambdaType:
    """Lambda resolver model definition (for GraphQL Lambda-backed types)."""

    name: str
    attributes: List[Attribute]
    description: Optional[str] = None
    type: str = "lambda"
    auth_config: Optional[Dict[str, Any]] = None
    targets: List[str] = dataclass_field(
        default_factory=list
    )  # Required - maps to output config targets
    operation: str = "mutation"  # "mutation" or "query" - determines GraphQL location


@dataclass
class Operation:
    """Represents a generated operation (CRUD, Query, etc.)."""

    name: str
    type: str  # 'Mutation' or 'Query'
    field: str
    dynamodb_op: Optional[str] = None
    index_partition: Optional[str] = None
    index_sort: Optional[str] = None
    index_name: Optional[str] = None
    response_auth_directives: List[str] = dataclass_field(default_factory=list)
    custom_type: Optional[str] = None
    enrichments: Optional[List[Dict[str, Any]]] = None
    returns: Optional[str] = None
    description: Optional[str] = None
    input: Optional[Dict[str, Any]] = None

    @property
    def response_type_suffix(self) -> str:
        """
        Get the response type suffix for this operation.

        Returns:
            - '{Op}Response' for mutations (CreateResponse, UpdateResponse, DeleteResponse)
            - 'GetResponse' for Get operations
            - 'ListResponse' for List operations
        """
        if self.type == "Mutation":
            return f"{self.name}Response"
        elif self.name == "Get":
            return "GetResponse"
        else:
            return "ListResponse"

    @property
    def is_single_item_response(self) -> bool:
        """
        Check if this operation returns a single item (vs a list).

        Returns:
            True for mutations and Get operations, False for List operations
        """
        return self.type == "Mutation" or self.name == "Get"


# =============================================================================
# S3 SCHEMA TYPES (Issue #53)
# =============================================================================


@dataclass
class S3LifecycleRule:
    """S3 lifecycle rule configuration."""

    prefix: str
    expiration_days: Optional[int] = None
    transition_to_ia_days: Optional[int] = None
    transition_to_glacier_days: Optional[int] = None


@dataclass
class S3CorsConfig:
    """S3 CORS configuration."""

    allowed_origins: List[str] = dataclass_field(default_factory=lambda: ["*"])
    allowed_methods: List[str] = dataclass_field(default_factory=lambda: ["GET", "PUT", "HEAD"])
    allowed_headers: List[str] = dataclass_field(default_factory=lambda: ["*"])
    max_age_seconds: int = 3600


@dataclass
class S3BucketConfig:
    """S3 bucket configuration for an S3 schema."""

    name_suffix: str
    versioning: Optional[bool] = None  # Override target default
    encryption: Optional[str] = None  # "AES256" or "KMS"
    kms_key_id: Optional[str] = None
    lifecycle: Optional[List[S3LifecycleRule]] = None
    cors: Optional[S3CorsConfig] = None


@dataclass
class S3AccessConfig:
    """S3 access path configuration for an S3 schema."""

    path_suffix: str  # e.g., "pois/{resourceId}/*"


@dataclass
class S3Schema:
    """S3 storage schema definition.

    Defines an S3 bucket with associated Lambda for pre-signed URL operations.
    References an S3 target from configuration for access patterns.
    """

    name: str
    target: str  # References S3TargetConfig name in schema-generator.yml
    bucket: S3BucketConfig
    access: S3AccessConfig
    operations: List[str]  # ["GetUploadUrl", "GetDownloadUrl", "ListFiles", "DeleteFile"]
    description: Optional[str] = None
    type: str = "s3"

    # Resolved fields (populated during loading)
    resolved_path_pattern: Optional[str] = None  # Combined base_path_pattern + path_suffix

    # Supported operations
    SUPPORTED_OPERATIONS = frozenset({"GetUploadUrl", "GetDownloadUrl", "ListFiles", "DeleteFile"})

    # Valid path placeholders
    VALID_PLACEHOLDERS = frozenset({"{userId}", "{resourceType}", "{resourceId}"})
