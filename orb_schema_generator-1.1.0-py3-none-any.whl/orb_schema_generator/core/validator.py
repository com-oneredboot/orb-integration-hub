"""Configuration validation for schema-generator.yml.

Provides validation of configuration files against expected schema,
with support for auto-fixing common issues.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional, Any, Dict, List, Set
import yaml
import logging

from .config import Environment, GeneratorConfig

logger = logging.getLogger(__name__)


class IssueSeverity(str, Enum):
    """Validation issue severity levels."""

    ERROR = "error"  # Blocks generation
    WARNING = "warning"  # Does not block generation


@dataclass
class ValidationIssue:
    """A single validation issue."""

    severity: IssueSeverity
    field_path: str
    message: str
    suggestion: Optional[str] = None


@dataclass
class ValidationResult:
    """Result of configuration validation."""

    valid: bool
    issues: List[ValidationIssue] = field(default_factory=list)

    @property
    def errors(self) -> List[ValidationIssue]:
        """Return only error-level issues."""
        return [i for i in self.issues if i.severity == IssueSeverity.ERROR]

    @property
    def warnings(self) -> List[ValidationIssue]:
        """Return only warning-level issues."""
        return [i for i in self.issues if i.severity == IssueSeverity.WARNING]

    @property
    def has_errors(self) -> bool:
        """Check if there are any error-level issues."""
        return len(self.errors) > 0


@dataclass
class FixResult:
    """Result of auto-fix operation."""

    fixed: bool
    changes: List[str] = field(default_factory=list)
    remaining_issues: List[ValidationIssue] = field(default_factory=list)


class ConfigValidator:
    """Validates schema-generator.yml configuration files.

    Checks for:
    - Missing required fields
    - Unknown fields (potential typos)
    - Invalid field types
    - Invalid enum values
    - Non-standard environment values (warning)
    - Deprecated fields (warning)
    """

    # Known top-level keys in schema-generator.yml
    KNOWN_TOP_LEVEL_KEYS: Set[str] = {
        "version",  # Deprecated but recognized
        "project",
        "paths",
        "output",
        "generation",
        "logging",
    }

    # Deprecated fields with their deprecation messages (warnings)
    DEPRECATED_FIELDS: Dict[str, str] = {
        "version": (
            "The 'version' field is deprecated and will be ignored. "
            "Use 'orb-schema --version' to check generator version."
        ),
    }

    # Removed configuration sections that should error (not warn)
    REMOVED_CONFIG_SECTIONS: Dict[str, str] = {
        "output.infrastructure.appsync": (
            "The 'appsync' configuration section has been removed in v0.18.0. "
            "VTL resolvers are now generated automatically for DynamoDB schemas. "
            "AppSyncApi construct uses naming conventions and constructor parameters."
        ),
    }

    # Known keys within each section
    KNOWN_KEYS: Dict[str, Set[str]] = {
        "project": {"name", "customerId", "projectId", "environment"},
        "paths": {"schemas", "templates", "subdirectories"},
        "output": {
            "python",
            "typescript",
            "dart",
            "graphql",
            "infrastructure",
            "cdk",
        },
        "output.python": {
            "enabled",
            "base_dir",
            "output",
            "models",
            "enums",
            "enums_subdir",
            "models_subdir",
            "targets",
        },
        "output.typescript": {
            "enabled",
            "base_dir",
            "output",
            "models",
            "enums_subdir",
            "models_subdir",
            "targets",
        },
        "output.dart": {
            "enabled",
            "base_dir",
            "output",
            "enums_subdir",
            "models_subdir",
            "options",
            "targets",
        },
        "output.dart.options": {
            "hive",
            "equatable",
            "immutable",
            "null_safety",
            "hive_type_id_start",
        },
        "output.graphql": {"base_dir", "output", "enabled", "targets"},
        "output.cdk": {
            "enabled",
            "base_dir",
            "language",
            "targets",
        },
        "output.infrastructure": {
            "format",
            "cdk",
            "cloudformation",
            "appsync",
            "lambda",
        },
        "output.infrastructure.cdk": {
            "base_dir",
            "language",
            "generate_stack",
            "stack_output_dir",
            "stack_name",
        },
        "output.infrastructure.cloudformation": {"base_dir"},
        "output.infrastructure.lambda": {
            "resolverOutputDir",
            "lambdaArnPattern",
            "useSsmParameters",
        },
        "generation": {
            "validate_schemas",
            "validate_graphql",
            "cleanup_old_files",
        },
        "logging": {"level", "file"},
    }

    # Required fields (empty for now - all fields are optional)
    REQUIRED_FIELDS: Set[str] = set()

    def __init__(self, config_path: str = "schema-generator.yml"):
        """Initialize validator with config file path.

        Args:
            config_path: Path to configuration file
        """
        self.config_path = Path(config_path)
        self._data: Optional[Dict[str, Any]] = None

    def validate(self) -> ValidationResult:
        """Validate the configuration file.

        Returns:
            ValidationResult with valid flag and list of issues
        """
        issues: List[ValidationIssue] = []

        # Check file exists
        if not self.config_path.exists():
            return ValidationResult(
                valid=False,
                issues=[
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path="",
                        message=f"Configuration file not found: {self.config_path}",
                        suggestion="Run 'orb-schema init' to create a default configuration",
                    )
                ],
            )

        # Load and parse YAML
        try:
            with open(self.config_path) as f:
                self._data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            return ValidationResult(
                valid=False,
                issues=[
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path="",
                        message=f"Invalid YAML syntax: {e}",
                    )
                ],
            )

        if self._data is None:
            self._data = {}

        # Validate structure
        issues.extend(self._validate_required_fields())
        issues.extend(self._validate_unknown_fields())
        issues.extend(self._validate_field_types())
        issues.extend(self._validate_enum_values())
        issues.extend(self._validate_paths())
        issues.extend(self._validate_deprecated_fields())
        issues.extend(self._validate_removed_sections())

        return ValidationResult(
            valid=not any(i.severity == IssueSeverity.ERROR for i in issues),
            issues=issues,
        )

    def _validate_deprecated_fields(self) -> List[ValidationIssue]:
        """Check for deprecated fields and emit warnings.

        Returns:
            List of validation issues for deprecated fields
        """
        issues: List[ValidationIssue] = []

        if not self._data:
            return issues

        for field_name, deprecation_message in self.DEPRECATED_FIELDS.items():
            if field_name in self._data:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        field_path=field_name,
                        message=deprecation_message,
                        suggestion="Remove this field from your configuration file.",
                    )
                )

        return issues

    def _validate_removed_sections(self) -> List[ValidationIssue]:
        """Check for removed configuration sections and emit errors.

        Returns:
            List of validation issues for removed sections
        """
        issues: List[ValidationIssue] = []

        if not self._data:
            return issues

        for section_path, error_message in self.REMOVED_CONFIG_SECTIONS.items():
            parts = section_path.split(".")
            current = self._data
            found = True

            for part in parts:
                if not isinstance(current, dict) or part not in current:
                    found = False
                    break
                current = current[part]

            if found:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path=section_path,
                        message=error_message,
                        suggestion="Remove this section from your configuration file.",
                    )
                )

        return issues

    def _validate_required_fields(self) -> List[ValidationIssue]:
        """Check for missing required fields.

        Returns:
            List of validation issues for missing fields
        """
        issues: List[ValidationIssue] = []

        for field_path in self.REQUIRED_FIELDS:
            parts = field_path.split(".")
            current = self._data
            found = True

            for part in parts:
                if not isinstance(current, dict) or part not in current:
                    found = False
                    break
                current = current[part]

            if not found:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path=field_path,
                        message=f"Required field '{field_path}' is missing",
                    )
                )

        return issues

    def _validate_unknown_fields(self) -> List[ValidationIssue]:
        """Check for unknown fields that may indicate typos.

        Returns:
            List of validation issues for unknown fields
        """
        issues: List[ValidationIssue] = []

        def check_keys(data: Dict[str, Any], path: str, known_keys: Set[str]) -> None:
            """Recursively check for unknown keys."""
            if not isinstance(data, dict):
                return

            for key in data.keys():
                if key not in known_keys:
                    full_path = f"{path}.{key}" if path else key
                    # Find similar known keys for suggestion
                    similar = self._find_similar_key(key, known_keys)
                    suggestion = f"Did you mean '{similar}'?" if similar else None

                    issues.append(
                        ValidationIssue(
                            severity=IssueSeverity.WARNING,
                            field_path=full_path,
                            message=f"Unknown field '{key}'",
                            suggestion=suggestion,
                        )
                    )

        # Check top-level keys
        if self._data:
            check_keys(self._data, "", self.KNOWN_TOP_LEVEL_KEYS)

            # Check nested keys
            for section, keys in self.KNOWN_KEYS.items():
                parts = section.split(".")
                current = self._data

                for part in parts:
                    if not isinstance(current, dict) or part not in current:
                        break
                    current = current[part]
                else:
                    if isinstance(current, dict):
                        check_keys(current, section, keys)

        return issues

    def _find_similar_key(self, key: str, known_keys: Set[str]) -> Optional[str]:
        """Find a similar key from known keys (simple Levenshtein-like check).

        Args:
            key: The unknown key
            known_keys: Set of known valid keys

        Returns:
            Most similar key if found, None otherwise
        """
        key_lower = key.lower()
        for known in known_keys:
            known_lower = known.lower()
            # Check for common typos: case difference, missing/extra char
            if key_lower == known_lower:
                return known
            if abs(len(key) - len(known)) <= 1:
                # Simple check: most characters match
                matches = sum(1 for a, b in zip(key_lower, known_lower) if a == b)
                if matches >= len(key) - 1:
                    return known
        return None

    def _validate_field_types(self) -> List[ValidationIssue]:
        """Check field values against expected types.

        Returns:
            List of validation issues for type mismatches
        """
        issues: List[ValidationIssue] = []

        if not self._data:
            return issues

        # Define expected types for specific fields
        type_checks = {
            "project.name": str,
            "project.customerId": str,
            "project.projectId": str,
            "project.environment": str,
            "paths.schemas": str,
            "paths.templates": str,
            "generation.validate_schemas": bool,
            "generation.validate_graphql": bool,
            "generation.cleanup_old_files": bool,
            "logging.level": str,
            "logging.file": str,
            "output.python.enabled": bool,
            "output.typescript.enabled": bool,
            "output.dart.enabled": bool,
        }

        for field_path, expected_type in type_checks.items():
            value = self._get_nested_value(field_path)
            if value is not None and not isinstance(value, expected_type):
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path=field_path,
                        message=(
                            f"Expected {expected_type.__name__}, " f"got {type(value).__name__}"
                        ),
                    )
                )

        return issues

    def _validate_enum_values(self) -> List[ValidationIssue]:
        """Check enum fields against valid values.

        Returns:
            List of validation issues for invalid enum values
        """
        issues: List[ValidationIssue] = []

        if not self._data:
            return issues

        # Check environment value
        env_value = self._get_nested_value("project.environment")
        if env_value is not None and isinstance(env_value, str):
            if not Environment.is_standard(env_value):
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        field_path="project.environment",
                        message=(
                            f"Non-standard environment value '{env_value}'. "
                            f"Standard values are: {', '.join(Environment.values())}"
                        ),
                        suggestion="Consider using a standard environment value",
                    )
                )

        # Check logging level
        log_level = self._get_nested_value("logging.level")
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if log_level is not None and isinstance(log_level, str):
            if log_level.upper() not in valid_levels:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path="logging.level",
                        message=(
                            f"Invalid log level '{log_level}'. "
                            f"Valid values are: {', '.join(sorted(valid_levels))}"
                        ),
                    )
                )

        # Check infrastructure format
        infra_format = self._get_nested_value("output.infrastructure.format")
        valid_formats = {"cloudformation", "cdk", "both"}
        if infra_format is not None and isinstance(infra_format, str):
            if infra_format.lower() not in valid_formats:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path="output.infrastructure.format",
                        message=(
                            f"Invalid infrastructure format '{infra_format}'. "
                            f"Valid values are: {', '.join(sorted(valid_formats))}"
                        ),
                    )
                )

        # Check CDK language
        cdk_lang = self._get_nested_value("output.infrastructure.cdk.language")
        valid_langs = {"python", "typescript"}
        if cdk_lang is not None and isinstance(cdk_lang, str):
            if cdk_lang.lower() not in valid_langs:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        field_path="output.infrastructure.cdk.language",
                        message=(
                            f"Invalid CDK language '{cdk_lang}'. "
                            f"Valid values are: {', '.join(sorted(valid_langs))}"
                        ),
                    )
                )

        return issues

    def _validate_paths(self) -> List[ValidationIssue]:
        """Validate that specified paths exist where applicable.

        Returns:
            List of validation issues for invalid paths
        """
        issues: List[ValidationIssue] = []

        if not self._data:
            return issues

        # Check schema directory exists
        schema_dir = self._get_nested_value("paths.schemas")
        if schema_dir is not None and isinstance(schema_dir, str):
            schema_path = Path(schema_dir)
            if not schema_path.exists():
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        field_path="paths.schemas",
                        message=f"Schema directory does not exist: {schema_dir}",
                        suggestion="Create the directory or update the path",
                    )
                )

        return issues

    def _get_nested_value(self, field_path: str) -> Any:
        """Get a nested value from the config data.

        Args:
            field_path: Dot-separated path to the field

        Returns:
            The value at the path, or None if not found
        """
        if not self._data:
            return None

        parts = field_path.split(".")
        current: Any = self._data

        for part in parts:
            if not isinstance(current, dict) or part not in current:
                return None
            current = current[part]

        return current

    def fix(self) -> FixResult:
        """Auto-fix common configuration issues.

        Currently supports:
        - Creating missing schema directory

        Returns:
            FixResult with changes made and remaining issues
        """
        changes: List[str] = []
        remaining: List[ValidationIssue] = []

        # First validate to get issues
        result = self.validate()

        for issue in result.issues:
            fixed = False

            # Try to fix schema directory not existing
            if issue.field_path == "paths.schemas" and "does not exist" in issue.message:
                schema_dir = self._get_nested_value("paths.schemas")
                if schema_dir:
                    try:
                        Path(schema_dir).mkdir(parents=True, exist_ok=True)
                        changes.append(f"Created schema directory: {schema_dir}")
                        fixed = True
                    except Exception as e:
                        logger.warning(f"Could not create directory: {e}")

            if not fixed:
                remaining.append(issue)

        return FixResult(
            fixed=len(changes) > 0,
            changes=changes,
            remaining_issues=remaining,
        )

    def get_schema(self) -> Dict[str, Any]:
        """Return JSON schema for configuration.

        Returns:
            JSON schema dictionary
        """
        return {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "orb-schema-generator configuration",
            "type": "object",
            "properties": {
                "project": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "customerId": {"type": "string"},
                        "projectId": {"type": "string"},
                        "environment": {
                            "type": "string",
                            "enum": Environment.values(),
                            "description": "Standard values. Custom values allowed with warning.",
                        },
                    },
                },
                "paths": {
                    "type": "object",
                    "properties": {
                        "schemas": {"type": "string"},
                        "templates": {"type": "string"},
                        "subdirectories": {"type": "object"},
                    },
                },
                "output": {
                    "type": "object",
                    "properties": {
                        "python": {"$ref": "#/definitions/outputConfig"},
                        "typescript": {"$ref": "#/definitions/outputConfig"},
                        "dart": {"$ref": "#/definitions/dartOutputConfig"},
                        "graphql": {"$ref": "#/definitions/outputConfig"},
                        "infrastructure": {"$ref": "#/definitions/infrastructureConfig"},
                    },
                },
                "generation": {
                    "type": "object",
                    "properties": {
                        "validate_schemas": {"type": "boolean"},
                        "validate_graphql": {"type": "boolean"},
                        "cleanup_old_files": {"type": "boolean"},
                    },
                },
                "logging": {
                    "type": "object",
                    "properties": {
                        "level": {
                            "type": "string",
                            "enum": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                        },
                        "file": {"type": "string"},
                    },
                },
            },
            "definitions": {
                "outputConfig": {
                    "type": "object",
                    "properties": {
                        "enabled": {"type": "boolean"},
                        "base_dir": {"type": "string"},
                        "enums_subdir": {"type": "string"},
                        "models_subdir": {"type": "string"},
                    },
                },
                "dartOutputConfig": {
                    "type": "object",
                    "properties": {
                        "enabled": {"type": "boolean"},
                        "base_dir": {"type": "string"},
                        "options": {
                            "type": "object",
                            "properties": {
                                "hive": {"type": "boolean"},
                                "equatable": {"type": "boolean"},
                                "immutable": {"type": "boolean"},
                                "null_safety": {"type": "boolean"},
                                "hive_type_id_start": {"type": "integer"},
                            },
                        },
                    },
                },
                "infrastructureConfig": {
                    "type": "object",
                    "properties": {
                        "format": {
                            "type": "string",
                            "enum": ["cloudformation", "cdk", "both"],
                        },
                        "cdk": {
                            "type": "object",
                            "properties": {
                                "base_dir": {"type": "string"},
                                "language": {
                                    "type": "string",
                                    "enum": ["python", "typescript"],
                                },
                                "generate_stack": {"type": "boolean"},
                                "stack_name": {"type": "string"},
                            },
                        },
                    },
                },
            },
        }


class OutputDirectoryValidator:
    """Validates output directories for non-generated files.

    Scans output directories to detect custom files that may be
    overwritten during generation. Files without AUTO-GENERATED
    headers are flagged as warnings.
    """

    AUTO_GENERATED_PATTERNS = [
        "# AUTO-GENERATED",
        "// AUTO-GENERATED",
        "/* AUTO-GENERATED",
        "## AUTO-GENERATED",  # VTL comment style
    ]

    GENERATED_FILE_EXTENSIONS = {".py", ".ts", ".dart", ".graphql", ".vtl"}

    def __init__(self, config: GeneratorConfig):
        """Initialize validator with generator configuration.

        Args:
            config: Generator configuration with output paths
        """
        self.config = config

    def scan_output_directories(self) -> List[ValidationIssue]:
        """Scan all output directories for non-generated files.

        Returns:
            List of validation issues for files without AUTO-GENERATED header
        """
        issues: List[ValidationIssue] = []

        directories: List[Path] = []

        # Add output directories from config
        if hasattr(self.config, "python_output") and self.config.python_output:
            directories.append(self.config.python_output.base_dir)

        if hasattr(self.config, "typescript_output") and self.config.typescript_output:
            directories.append(self.config.typescript_output.base_dir)

        if hasattr(self.config, "dart_output") and self.config.dart_output:
            directories.append(self.config.dart_output.base_dir)

        if hasattr(self.config, "graphql_output") and self.config.graphql_output:
            directories.append(self.config.graphql_output.base_dir)

        if hasattr(self.config, "cdk_output_dir") and self.config.cdk_output_dir:
            directories.append(self.config.cdk_output_dir)

        for directory in directories:
            if directory and directory.exists():
                issues.extend(self._scan_directory(directory))

        return issues

    def _scan_directory(self, directory: Path) -> List[ValidationIssue]:
        """Scan a single directory for non-generated files.

        Args:
            directory: Directory path to scan

        Returns:
            List of validation issues for files without header
        """
        issues: List[ValidationIssue] = []

        for file_path in directory.rglob("*"):
            if file_path.is_file() and self._is_generated_file_type(file_path):
                if not self._has_auto_generated_header(file_path):
                    issues.append(
                        ValidationIssue(
                            severity=IssueSeverity.WARNING,
                            field_path=str(file_path),
                            message="Custom file detected in generated directory",
                            suggestion="Move to lib/ or another non-generated location",
                        )
                    )

        return issues

    def _has_auto_generated_header(self, file_path: Path) -> bool:
        """Check if file has AUTO-GENERATED header in first 5 lines.

        Args:
            file_path: Path to file to check

        Returns:
            True if file has AUTO-GENERATED header
        """
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for _ in range(5):
                    line = f.readline()
                    if not line:
                        break
                    if any(pattern in line for pattern in self.AUTO_GENERATED_PATTERNS):
                        return True
        except (OSError, IOError) as e:
            logger.debug(f"Could not read file {file_path}: {e}")
        return False

    def _is_generated_file_type(self, file_path: Path) -> bool:
        """Check if file type is one we generate.

        Args:
            file_path: Path to file to check

        Returns:
            True if file extension matches generated types
        """
        return file_path.suffix in self.GENERATED_FILE_EXTENSIONS
