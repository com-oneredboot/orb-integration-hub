"""Version cache for storing latest version check results.

This module provides caching functionality to avoid repeated network calls
when checking for updates. The cache expires after 24 hours by default.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class VersionCache:
    """Cache for version check results.

    Stores the latest version and timestamp of when it was checked.
    The cache is stored in ~/.kiro/version-cache.json.

    Attributes:
        latest_version: The latest version string from PyPI.
        checked_at: UTC timestamp when the version was checked.
    """

    latest_version: str
    checked_at: datetime

    DEFAULT_TTL_HOURS = 24
    DEFAULT_CACHE_PATH = Path.home() / ".kiro" / "version-cache.json"

    def is_valid(self, ttl_hours: int = DEFAULT_TTL_HOURS) -> bool:
        """Check if the cache is still valid.

        Args:
            ttl_hours: Time-to-live in hours. Default is 24 hours.

        Returns:
            True if the cache is still valid (not expired), False otherwise.
        """
        now = datetime.now(timezone.utc)
        # Ensure checked_at is timezone-aware
        checked_at = self.checked_at
        if checked_at.tzinfo is None:
            checked_at = checked_at.replace(tzinfo=timezone.utc)

        age_hours = (now - checked_at).total_seconds() / 3600
        return age_hours < ttl_hours

    @classmethod
    def load(cls, path: Optional[Path] = None) -> Optional["VersionCache"]:
        """Load cache from file.

        Args:
            path: Path to cache file. Defaults to ~/.kiro/version-cache.json.

        Returns:
            VersionCache instance if valid cache exists, None otherwise.
            Returns None for missing, corrupted, or invalid cache files.
        """
        cache_path = path or cls.DEFAULT_CACHE_PATH

        if not cache_path.exists():
            return None

        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Validate required fields
            if "latest_version" not in data or "checked_at" not in data:
                logger.debug("Cache file missing required fields, deleting")
                cls._delete_cache(cache_path)
                return None

            # Parse timestamp
            checked_at = datetime.fromisoformat(data["checked_at"])

            return cls(
                latest_version=data["latest_version"],
                checked_at=checked_at,
            )

        except (json.JSONDecodeError, ValueError, KeyError, TypeError) as e:
            # Corrupted cache - delete and return None
            logger.debug(f"Cache file corrupted ({e}), deleting")
            cls._delete_cache(cache_path)
            return None
        except PermissionError:
            logger.debug("Permission denied reading cache file")
            return None
        except Exception as e:
            logger.debug(f"Unexpected error reading cache: {e}")
            return None

    def save(self, path: Optional[Path] = None) -> bool:
        """Save cache to file.

        Args:
            path: Path to cache file. Defaults to ~/.kiro/version-cache.json.

        Returns:
            True if save was successful, False otherwise.
        """
        cache_path = path or self.DEFAULT_CACHE_PATH

        try:
            # Create parent directory if needed
            cache_path.parent.mkdir(parents=True, exist_ok=True)

            # Ensure checked_at is timezone-aware for consistent serialization
            checked_at = self.checked_at
            if checked_at.tzinfo is None:
                checked_at = checked_at.replace(tzinfo=timezone.utc)

            data = {
                "latest_version": self.latest_version,
                "checked_at": checked_at.isoformat(),
            }

            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            return True

        except PermissionError:
            logger.debug("Permission denied writing cache file")
            return False
        except Exception as e:
            logger.debug(f"Failed to save cache: {e}")
            return False

    @staticmethod
    def _delete_cache(path: Path) -> None:
        """Delete cache file if it exists.

        Args:
            path: Path to cache file to delete.
        """
        try:
            if path.exists():
                path.unlink()
        except Exception as e:
            logger.debug(f"Failed to delete cache file: {e}")
