"""Import resolution for cross-target type references.

This module provides functionality to determine whether a referenced type
should be imported from another target or generated locally.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional

from .config import GeneratorConfig


@dataclass
class ImportResolution:
    """Result of resolving whether to import or generate a type.

    Attributes:
        should_import: True if the type should be imported, False if generated locally
        import_path: The import path to use (e.g., "gps_perimeter_tracker.models")
        import_from_target: The target name the type is imported from
    """

    should_import: bool
    import_path: Optional[str] = None
    import_from_target: Optional[str] = None


class ImportResolver:
    """Resolves whether referenced types should be imported or generated.

    This class checks the `imports_from` configuration to determine if a
    referenced type exists in another target and should be imported rather
    than generated locally.

    Example:
        ```python
        resolver = ImportResolver(config, all_schemas)
        resolution = resolver.resolve("GPSPoint", "api", "python")
        if resolution.should_import:
            # Generate: from gps_perimeter_tracker.models import GPSPoint
        else:
            # Generate the type definition locally
        ```
    """

    def __init__(self, config: GeneratorConfig, all_schemas: Dict[str, Any]):
        """Initialize the import resolver.

        Args:
            config: Generator configuration with target definitions
            all_schemas: Dictionary mapping schema names to schema objects
        """
        self.config = config
        self.all_schemas = all_schemas

    def resolve(
        self,
        type_name: str,
        current_target: str,
        language: str,
    ) -> ImportResolution:
        """Determine if a type should be imported or generated.

        Args:
            type_name: Name of the referenced type
            current_target: Target being generated
            language: Language being generated (python, typescript, dart)

        Returns:
            ImportResolution indicating import vs generate decision
        """
        # Get current target's config
        target_config = self.config.get_target_config(language, current_target)
        if not target_config:
            return ImportResolution(should_import=False)

        # Check if imports_from is configured
        imports_from = getattr(target_config, "imports_from", None)
        if not imports_from:
            return ImportResolution(should_import=False)

        # Check if type exists in an imports_from source
        for source_target, import_path in imports_from.items():
            if self._type_in_target(type_name, source_target):
                return ImportResolution(
                    should_import=True,
                    import_path=import_path,
                    import_from_target=source_target,
                )

        return ImportResolution(should_import=False)

    def _type_in_target(self, type_name: str, target: str) -> bool:
        """Check if a type exists in a specific target.

        Args:
            type_name: Name of the type to check
            target: Target name to check for

        Returns:
            True if the type exists in the specified target
        """
        if type_name not in self.all_schemas:
            return False

        schema = self.all_schemas[type_name]
        schema_targets = getattr(schema, "targets", [])
        return target in schema_targets

    def get_import_statement(
        self,
        type_name: str,
        resolution: ImportResolution,
        language: str,
    ) -> Optional[str]:
        """Generate the import statement for a resolved type.

        Args:
            type_name: Name of the type to import
            resolution: The import resolution result
            language: Target language (python, typescript, dart)

        Returns:
            Import statement string, or None if not importing
        """
        if not resolution.should_import or not resolution.import_path:
            return None

        if language == "python":
            return f"from {resolution.import_path} import {type_name}"
        elif language == "typescript":
            return f"import {{ {type_name} }} from '{resolution.import_path}';"
        elif language == "dart":
            return f"import '{resolution.import_path}/{type_name.lower()}.dart';"
        else:
            return None
