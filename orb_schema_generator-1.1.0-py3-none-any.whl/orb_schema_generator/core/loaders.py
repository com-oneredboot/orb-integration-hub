"""Schema loading functionality."""

import glob
import logging
from pathlib import Path
from typing import Dict, Any, Set, List, Optional
import yaml

from .models import (
    Attribute,
    CustomQuery,
    TableSchema,
    GraphQLType,
    RegistryType,
    StandardType,
    LambdaType,
    SchemaValidationError,
    MissingTargetsError,
    InvalidTargetsError,
    S3Schema,
    S3BucketConfig,
    S3AccessConfig,
    S3LifecycleRule,
    S3CorsConfig,
)

logger = logging.getLogger(__name__)


class SchemaLoader:
    """Loads and parses schema files."""

    def __init__(self, config):
        """
        Initialize schema loader.

        Args:
            config: GeneratorConfig instance with schema directory and subdirectory configuration
        """

        # Support both config object and legacy schema_dir path
        if isinstance(config, (str, Path)):
            # Legacy: just a path
            self.schema_dir = Path(config)
            self.subdirectories = None
            logger.warning(
                "SchemaLoader initialized with path only. Consider passing GeneratorConfig for subdirectory support."
            )
        else:
            # New: config object
            self.schema_dir = Path(config.schema_dir)
            self.subdirectories = config.schema_subdirectories

    def load_all_schemas(self) -> Dict[str, Any]:
        """
        Load all schema YAML files from the schema directory.
        Supports both flat structure and subdirectory organization.

        Returns:
            Dictionary of schema objects keyed by name

        Raises:
            FileNotFoundError: If schema directory does not exist
        """
        # Validate schema directory exists
        if not self.schema_dir.exists():
            raise FileNotFoundError(f"Schema directory does not exist: {self.schema_dir}")

        if not self.schema_dir.is_dir():
            raise NotADirectoryError(f"Schema path is not a directory: {self.schema_dir}")

        schemas = {}
        schema_files = []

        if self.subdirectories:
            # Load from subdirectories - scan ALL configured directories
            # Schema type is determined by the 'type' field in the schema, not directory location
            logger.info(f"Loading schemas from subdirectories: {list(self.subdirectories.keys())}")

            for subdir_type, subdir_name in self.subdirectories.items():
                subdir_path = self.schema_dir / subdir_name
                if subdir_path.exists() and subdir_path.is_dir():
                    files = glob.glob(str(subdir_path / "*.yml"))
                    logger.info(f"Found {len(files)} schemas in {subdir_name}/")

                    # Store files - type will be determined from schema content, not directory
                    for file in files:
                        schema_files.append((file, self._type_from_subdir(subdir_type)))
                else:
                    logger.debug(f"Subdirectory not found: {subdir_path}")
        else:
            # Flat structure: load from root
            logger.info(f"Loading schemas from flat structure: {self.schema_dir}")
            files = glob.glob(str(self.schema_dir / "*.yml"))
            logger.info(f"Found {len(files)} schemas")
            schema_files = [(f, None) for f in files]

        # First pass: collect all model names for reference tracking
        model_names = set()
        for schema_file, _ in schema_files:
            schema_dict = self._load_schema_file(schema_file)
            # Skip non-schema files (e.g., type definitions without 'name')
            if schema_dict is None:
                continue
            schema_name = schema_dict.get("name")
            if schema_name:
                model_names.add(schema_name)

        # Second pass: parse schemas with model reference tracking
        for schema_file, inferred_type in schema_files:
            schema_dict = self._load_schema_file(schema_file)

            # Skip non-schema files (e.g., type definitions without 'name')
            if schema_dict is None:
                continue

            # Auto-detect type if not specified
            if "type" not in schema_dict:
                detected_type = self._detect_schema_type(schema_dict, inferred_type)
                schema_dict["type"] = detected_type
                logger.info(f"Auto-detected type '{detected_type}' for {schema_dict.get('name')}")
            elif inferred_type and schema_dict["type"] != inferred_type:
                # Info: explicit type takes precedence over directory convention
                schema_path = Path(schema_file)
                logger.warning(
                    f"Schema '{schema_dict.get('name')}' has type '{schema_dict['type']}' "
                    f"but is in directory '{schema_path.parent.name}' which suggests '{inferred_type}'. "
                    f"The explicit type takes precedence - this is informational only."
                )

            schema_obj = self._parse_schema(schema_dict, model_names)
            schemas[schema_obj.name] = schema_obj

        logger.info(f"Loaded {len(schemas)} schemas total")
        return schemas

    def _type_from_subdir(self, subdir_name: str) -> Optional[str]:
        """
        Infer schema type from subdirectory name.

        Args:
            subdir_name: Name of the subdirectory (e.g., 'tables', 'models')

        Returns:
            Inferred schema type string or None
        """
        type_mapping = {
            "tables": "lambda-dynamodb",  # Default for tables
            "models": "standard",
            "registries": "registry",
            "graphql": "graphql",
            "lambdas": "lambda",
        }

        inferred = type_mapping.get(subdir_name)
        if inferred:
            logger.debug(f"Mapped subdirectory '{subdir_name}' to type '{inferred}'")
        return inferred

    def _detect_schema_type(
        self, schema_dict: Dict[str, Any], inferred_type: Optional[str] = None
    ) -> str:
        """
        Detect schema type from structure when not explicitly specified.

        Priority:
        1. Inferred type from directory location (if provided)
        2. Structure-based detection (keys, items, etc.)
        3. Default to 'standard'

        Args:
            schema_dict: Schema dictionary
            inferred_type: Type inferred from directory location

        Returns:
            Detected schema type string
        """
        # Priority 1: Use inferred type from directory
        if inferred_type:
            logger.debug(f"Using directory-inferred type: {inferred_type}")
            return inferred_type

        # Priority 2: Structure-based detection

        # Check for registry type (has 'items' field)
        if "items" in schema_dict:
            logger.debug("Detected registry type from 'items' field")
            return "registry"

        # Check for table type (has model.keys)
        if "model" in schema_dict and "keys" in schema_dict["model"]:
            keys = schema_dict["model"]["keys"]
            if "primary" in keys:
                logger.debug("Detected table type from 'model.keys.primary' field")
                return "lambda-dynamodb"

        # Check for lambda type (has model but no keys, and has auth_config)
        if "model" in schema_dict:
            model = schema_dict["model"]
            if "authConfig" in model and "keys" not in model:
                logger.debug("Detected lambda type from 'authConfig' without keys")
                return "lambda"

        # Priority 3: Default to standard type
        logger.debug("Defaulting to standard type")
        return "standard"

    def _load_schema_file(self, schema_path: str) -> Optional[Dict[str, Any]]:
        """
        Load a single schema file.

        Args:
            schema_path: Path to schema YAML file

        Returns:
            Parsed schema dictionary, or None if file is not a valid schema
            (e.g., type definition files without 'name' field)

        Raises:
            SchemaValidationError: If schema has structural errors
            MissingTargetsError: If schema is missing required 'targets' field
            InvalidTargetsError: If schema has invalid 'targets' field
        """
        try:
            with open(schema_path, "r") as f:
                schema = yaml.safe_load(f)

            # Skip files without 'name' field - these are type/validator definition files
            # not actual schemas (e.g., core/types.yml, core/validators.yml)
            if "name" not in schema:
                logger.debug(f"Skipping non-schema file (no 'name' field): {schema_path}")
                return None

            # S3 schemas use 'target' (singular) instead of 'targets' (plural)
            # and don't need model/items validation
            if schema.get("type") == "s3":
                # S3 schemas are validated in _parse_s3_schema
                return schema

            # Validate and parse 'targets' field
            schema["targets"] = self._parse_targets(schema, schema_path)

            # Type field is optional - can be inferred
            if "type" not in schema:
                logger.debug(f"Schema '{schema['name']}' has no type field - will be inferred")

            # Registry schemas don't need model section
            if schema.get("type") == "registry":
                if "items" not in schema:
                    raise SchemaValidationError(
                        f"Registry schema '{schema['name']}' must have an 'items' block: {schema_path}"
                    )
                return schema

            # For non-registry schemas, validate model structure
            if "model" in schema:
                if "attributes" not in schema["model"]:
                    raise SchemaValidationError(
                        f"Schema 'model' must have an 'attributes' field: {schema_path}"
                    )

                # Process auth config if present
                if "authConfig" in schema["model"]:
                    schema["auth_config"] = schema["model"]["authConfig"]
            elif "items" not in schema:
                # If no model and no items, it's invalid
                raise SchemaValidationError(
                    f"Schema must have either 'model' or 'items' field: {schema_path}"
                )

            return schema

        except yaml.YAMLError as e:
            raise SchemaValidationError(f"Error parsing schema file {schema_path}: {str(e)}")
        except (MissingTargetsError, InvalidTargetsError):
            raise  # Re-raise target errors without wrapping
        except SchemaValidationError:
            raise  # Re-raise SchemaValidationError without wrapping
        except Exception as e:
            raise SchemaValidationError(f"Error loading schema file {schema_path}: {str(e)}")

    def _parse_targets(self, schema: Dict[str, Any], schema_path: str) -> List[str]:
        """
        Parse and validate the 'targets' field from a schema.

        Args:
            schema: Schema dictionary
            schema_path: Path to schema file (for error messages)

        Returns:
            List of target names

        Raises:
            MissingTargetsError: If 'targets' field is missing
            InvalidTargetsError: If 'targets' field is invalid
        """
        schema_name = schema.get("name", "unknown")

        if "targets" not in schema:
            # Check if user has deprecated 'target' (singular) field - common migration issue
            if "target" in schema:
                old_target = schema["target"]
                raise InvalidTargetsError(
                    schema_name,
                    f"Found deprecated 'target: {old_target}' field. "
                    f"Since v0.12.0, use 'targets' array instead:\n"
                    f"  targets:\n"
                    f"    - {old_target}",
                )
            raise MissingTargetsError(schema_name, schema_path)

        targets = schema["targets"]

        # Validate targets is a list
        if not isinstance(targets, list):
            raise InvalidTargetsError(schema_name, "'targets' must be an array")

        # Validate targets is not empty
        if len(targets) == 0:
            raise InvalidTargetsError(schema_name, "'targets' cannot be empty")

        # Validate no duplicates
        if len(targets) != len(set(targets)):
            raise InvalidTargetsError(schema_name, "'targets' contains duplicates")

        # Validate each target is a non-empty string
        for i, target in enumerate(targets):
            if not isinstance(target, str):
                raise InvalidTargetsError(
                    schema_name,
                    f"target at index {i} must be a string, got {type(target).__name__}",
                )
            if not target.strip():
                raise InvalidTargetsError(schema_name, f"target at index {i} cannot be empty")

        return targets

    def _parse_schema(self, schema_dict: Dict[str, Any], model_names: Set[str]) -> Any:
        """
        Parse schema dictionary into appropriate schema object.

        Args:
            schema_dict: Raw schema dictionary
            model_names: Set of all model names for reference tracking

        Returns:
            Parsed schema object
        """
        schema_type = schema_dict.get("type")

        if schema_type == "registry":
            return self._parse_registry_schema(schema_dict)
        elif schema_type == "standard":
            return self._parse_standard_schema(schema_dict, model_names)
        elif schema_type == "lambda":
            return self._parse_lambda_schema(schema_dict, model_names)
        elif schema_type == "s3":
            return self._parse_s3_schema(schema_dict)
        elif schema_type in ["dynamodb", "lambda-dynamodb"]:
            return self._parse_table_schema(schema_dict, schema_type, model_names)
        else:
            # Fallback to GraphQL type
            return self._parse_graphql_schema(schema_dict, model_names)

    def _parse_attributes(
        self, attributes_dict: Dict[str, Any], model_names: Set[str]
    ) -> tuple[List[Attribute], Set[str]]:
        """
        Parse attributes from schema dictionary.

        Resolves references:
        - items.$ref for array types -> items_ref field
        - object_ref for object types -> object_ref field
        - Direct type references -> model_reference attribute

        Returns:
            Tuple of (attributes list, set of referenced models)
        """
        attributes = []
        referenced_models = set()

        for attr_name, attr_info in attributes_dict.items():
            # Handle enum_ref - map to enum_type for consistency
            enum_type = attr_info.get("enum_type") or attr_info.get("enum_ref")

            # Parse items.$ref for array types
            items_ref = None
            if attr_info.get("type") == "array" and "items" in attr_info:
                items = attr_info["items"]
                if isinstance(items, dict) and "$ref" in items:
                    items_ref = items["$ref"]
                    if items_ref in model_names:
                        referenced_models.add(items_ref)

            # Parse object_ref for object types
            object_ref = attr_info.get("object_ref")
            if object_ref and object_ref in model_names:
                referenced_models.add(object_ref)

            # Handle map type with value_type attribute
            # Supports both syntaxes:
            # 1. type: map<string> - inline syntax (handled by type_mapping)
            # 2. type: map with value_type: string - attribute syntax (handled here)
            attr_type = attr_info["type"]
            value_type = attr_info.get("value_type")
            if attr_type == "map" and value_type:
                attr_type = f"map<{value_type}>"

            attr = Attribute(
                name=attr_name,
                type=attr_type,
                description=attr_info.get("description", ""),
                required=attr_info.get("required", True),
                enum_type=enum_type,
                enum_values=attr_info.get("enum_values"),
                items_ref=items_ref,
                object_ref=object_ref,
                default=attr_info.get("default"),  # Issue #43: default value support
                validation=attr_info.get("validation"),  # Issue #44: validation rules support
                input_only=attr_info.get("input_only", False),  # Issue #70: Lambda Input/Output
                output_only=attr_info.get("output_only", False),  # Issue #70: Lambda Input/Output
            )

            # Track direct model references (type is a model name)
            if attr.type in model_names:
                setattr(attr, "model_reference", attr.type)
                referenced_models.add(attr.type)

            attributes.append(attr)

        return attributes, referenced_models

    def _parse_table_schema(
        self, schema_dict: Dict[str, Any], schema_type: str, model_names: Set[str]
    ) -> TableSchema:
        """Parse DynamoDB table schema."""
        name = schema_dict["name"]
        model = schema_dict["model"]
        attributes, _ = self._parse_attributes(model["attributes"], model_names)

        keys = model["keys"]
        partition_key = keys["primary"]["partition"]
        sort_key = keys["primary"].get("sort", "None")
        secondary_indexes = keys.get("secondary", [])
        auth_config = model.get("authConfig")
        stream_config = model.get("stream")

        # Validate required pitr_enabled field (Issue #65)
        if "pitr_enabled" not in schema_dict:
            raise SchemaValidationError(
                f"Schema '{name}' is missing required 'pitr_enabled' field. "
                f"Add 'pitr_enabled: true' or 'pitr_enabled: false' to the schema."
            )

        pitr_enabled = schema_dict["pitr_enabled"]
        if not isinstance(pitr_enabled, bool):
            raise SchemaValidationError(
                f"Schema '{name}' has invalid 'pitr_enabled' value: {pitr_enabled}. "
                f"Must be true or false."
            )

        # Parse custom queries if present
        custom_queries = []
        if "customQueries" in schema_dict:
            for query_def in schema_dict["customQueries"]:
                custom_query = CustomQuery(
                    name=query_def["name"],
                    type=query_def["type"],
                    description=query_def.get("description", ""),
                    input=query_def.get("input", {}),
                    returns=query_def.get("returns", "String"),
                    enrichments=query_def.get("enrichments", []),
                    implementationPath=query_def.get("implementationPath"),
                )
                custom_queries.append(custom_query)

        return TableSchema(
            name=schema_dict["name"],
            attributes=attributes,
            partition_key=partition_key,
            pitr_enabled=pitr_enabled,
            sort_key=sort_key,
            secondary_indexes=secondary_indexes,
            auth_config=auth_config,
            type=schema_type,
            stream=stream_config,
            custom_queries=custom_queries if custom_queries else None,
            targets=schema_dict.get("targets", []),
        )

    def _parse_graphql_schema(
        self, schema_dict: Dict[str, Any], model_names: Set[str]
    ) -> GraphQLType:
        """Parse GraphQL type schema."""
        model = schema_dict["model"]
        attributes, _ = self._parse_attributes(model["attributes"], model_names)
        auth_config = model.get("authConfig")

        return GraphQLType(
            name=schema_dict["name"],
            attributes=attributes,
            description=schema_dict.get("description"),
            auth_config=auth_config,
            targets=schema_dict.get("targets", []),
        )

    def _parse_registry_schema(self, schema_dict: Dict[str, Any]) -> RegistryType:
        """Parse registry schema."""
        return RegistryType(
            name=schema_dict["name"],
            items=schema_dict["items"],
            description=schema_dict.get("description"),
            type="registry",
            targets=schema_dict.get("targets", []),
        )

    def _parse_standard_schema(
        self, schema_dict: Dict[str, Any], model_names: Set[str]
    ) -> StandardType:
        """Parse standard model schema."""
        model = schema_dict["model"]
        attributes, referenced_models = self._parse_attributes(model["attributes"], model_names)

        schema_obj = StandardType(
            name=schema_dict["name"],
            attributes=attributes,
            description=schema_dict.get("description"),
            type="standard",
            targets=schema_dict.get("targets", []),
        )

        # Attach referenced models for template rendering
        setattr(schema_obj, "model_imports", sorted(referenced_models))
        return schema_obj

    def _parse_lambda_schema(
        self, schema_dict: Dict[str, Any], model_names: Set[str]
    ) -> LambdaType:
        """Parse Lambda type schema."""
        model = schema_dict["model"]
        attributes, referenced_models = self._parse_attributes(model["attributes"], model_names)
        auth_config = model.get("authConfig")

        # Validate operation field
        operation = model.get("operation", "mutation")
        valid_operations = {"query", "mutation"}
        if operation not in valid_operations:
            raise ValueError(
                f"Invalid operation '{operation}' for Lambda type '{schema_dict['name']}'. "
                f"Valid values are: {', '.join(sorted(valid_operations))}"
            )

        schema_obj = LambdaType(
            name=schema_dict["name"],
            attributes=attributes,
            description=schema_dict.get("description"),
            type="lambda",
            auth_config=auth_config,
            targets=schema_dict.get("targets", []),
            operation=operation,
        )

        # Validate Lambda attribute flags (Issue #70)
        from .validators import SchemaValidator

        SchemaValidator.validate_lambda_attributes(schema_obj)

        # Attach referenced models for template rendering
        setattr(schema_obj, "model_imports", sorted(referenced_models))
        return schema_obj

    def _parse_s3_schema(self, schema_dict: Dict[str, Any]) -> S3Schema:
        """Parse S3 storage schema.

        S3 schemas define storage buckets with user isolation and operations.
        They reference an S3 target from the configuration for access patterns.

        Args:
            schema_dict: Raw schema dictionary

        Returns:
            Parsed S3Schema object

        Raises:
            SchemaValidationError: If schema is invalid
        """
        name = schema_dict["name"]

        # Validate required fields
        if "target" not in schema_dict:
            raise SchemaValidationError(f"S3 schema '{name}' is missing required 'target' field")

        storage = schema_dict.get("storage", {})

        # Parse bucket configuration
        bucket_data = storage.get("bucket", {})
        if "name_suffix" not in bucket_data:
            raise SchemaValidationError(
                f"S3 schema '{name}' is missing required 'storage.bucket.name_suffix' field"
            )

        # Parse lifecycle rules
        lifecycle_rules = None
        if "lifecycle" in bucket_data:
            lifecycle_rules = [
                S3LifecycleRule(
                    prefix=rule.get("prefix", ""),
                    expiration_days=rule.get("expiration_days"),
                    transition_to_ia_days=rule.get("transition_to_ia_days"),
                    transition_to_glacier_days=rule.get("transition_to_glacier_days"),
                )
                for rule in bucket_data["lifecycle"]
            ]

        # Parse CORS configuration
        cors_config = None
        if "cors" in bucket_data:
            cors_data = bucket_data["cors"]
            cors_config = S3CorsConfig(
                allowed_origins=cors_data.get("allowed_origins", ["*"]),
                allowed_methods=cors_data.get("allowed_methods", ["GET", "PUT", "HEAD"]),
                allowed_headers=cors_data.get("allowed_headers", ["*"]),
                max_age_seconds=cors_data.get("max_age_seconds", 3600),
            )

        bucket_config = S3BucketConfig(
            name_suffix=bucket_data["name_suffix"],
            versioning=bucket_data.get("versioning"),
            encryption=bucket_data.get("encryption"),
            lifecycle=lifecycle_rules,
            cors=cors_config,
        )

        # Parse access configuration
        access_data = storage.get("access", {})
        if "path_suffix" not in access_data:
            raise SchemaValidationError(
                f"S3 schema '{name}' is missing required 'storage.access.path_suffix' field"
            )

        access_config = S3AccessConfig(
            path_suffix=access_data["path_suffix"],
        )

        # Parse operations
        operations = storage.get("operations", [])
        if not operations:
            raise SchemaValidationError(
                f"S3 schema '{name}' is missing required 'storage.operations' field"
            )

        # Validate operations
        for op in operations:
            if op not in S3Schema.SUPPORTED_OPERATIONS:
                raise SchemaValidationError(
                    f"S3 schema '{name}' has invalid operation '{op}'. "
                    f"Supported: {', '.join(S3Schema.SUPPORTED_OPERATIONS)}"
                )

        # Validate path_suffix placeholders
        path_suffix = access_data["path_suffix"]
        import re

        placeholders = re.findall(r"\{(\w+)\}", path_suffix)
        for ph in placeholders:
            placeholder_with_braces = "{" + ph + "}"
            if placeholder_with_braces not in S3Schema.VALID_PLACEHOLDERS:
                raise SchemaValidationError(
                    f"S3 schema '{name}' has invalid placeholder '{{{ph}}}' in path_suffix. "
                    f"Valid: {', '.join(S3Schema.VALID_PLACEHOLDERS)}"
                )

        return S3Schema(
            name=name,
            target=schema_dict["target"],
            bucket=bucket_config,
            access=access_config,
            operations=operations,
            description=schema_dict.get("description"),
        )
