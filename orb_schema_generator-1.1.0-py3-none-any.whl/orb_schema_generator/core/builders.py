"""Operation building functionality."""

import logging
from typing import List, Dict

from .models import TableSchema, Operation, SchemaValidationError, get_auth_directives_from_config
from ..utils.case_conversion import to_pascal_case

logger = logging.getLogger(__name__)


class OperationBuilder:
    """Builds CRUD and query operations for schemas with deduplication."""

    def __init__(self, schema: TableSchema):
        """
        Initialize operation builder.

        Args:
            schema: Table schema to build operations for
        """
        self.schema = schema
        self._operations: Dict[str, Operation] = {}

    def build_all_operations(self) -> List[Operation]:
        """
        Build all operations with automatic deduplication.

        Returns:
            List of unique operations
        """
        self._add_crud_operations()
        self._add_get_operation()
        self._add_list_operations()
        self._add_custom_queries()
        self._validate_operations()

        return list(self._operations.values())

    def _add_operation(self, operation: Operation) -> None:
        """
        Add operation with duplicate detection.

        Args:
            operation: Operation to add
        """
        if operation.field in self._operations:
            logger.debug(f"Skipping duplicate operation: {operation.field}")
            return

        self._operations[operation.field] = operation

    def _get_auth_directives(self, op_name: str) -> List[str]:
        """
        Get auth directives for an operation.

        Args:
            op_name: Operation name

        Returns:
            List of auth directive strings
        """
        return get_auth_directives_from_config(self.schema.auth_config, op_name)

    def _add_crud_operations(self) -> None:
        """Add CRUD operations (Create, Update, Delete, Disable)."""
        crud_ops = [
            ("Create", "Mutation", "PutItem"),
            ("Update", "Mutation", "UpdateItem"),
            ("Delete", "Mutation", "DeleteItem"),
            ("Disable", "Mutation", "UpdateItem"),
        ]

        for name, op_type, dynamodb_op in crud_ops:
            field = f"{self.schema.name}{name}"
            operation = Operation(
                name=name,
                type=op_type,
                field=field,
                dynamodb_op=dynamodb_op,
                response_auth_directives=self._get_auth_directives(field),
            )
            self._add_operation(operation)

    def _add_get_operation(self) -> None:
        """Add Get operation for single-item retrieval by primary key."""
        field = f"{self.schema.name}Get"
        operation = Operation(
            name="Get",
            type="Query",
            field=field,
            dynamodb_op="GetItem",
            index_partition=self.schema.partition_key,
            index_sort=self.schema.sort_key if self.schema.sort_key != "None" else None,
            index_name=None,
            response_auth_directives=self._get_auth_directives(field),
        )
        self._add_operation(operation)

    def _add_list_operations(self) -> None:
        """Add list operations for primary key and secondary indexes.

        Note: Renamed from _add_query_operations to use ListBy* naming convention
        for clarity (Issue #78).
        """
        # List by primary partition key
        pk_pascal = to_pascal_case(self.schema.partition_key)
        field = f"{self.schema.name}ListBy{pk_pascal}"
        operation = Operation(
            name=f"ListBy{pk_pascal}",
            type="Query",
            field=field,
            dynamodb_op="Query",
            index_partition=self.schema.partition_key,
            index_sort=None,
            index_name=None,
            response_auth_directives=self._get_auth_directives(field),
        )
        self._add_operation(operation)

        # List by sort key if present
        if self.schema.sort_key and self.schema.sort_key != "None":
            sk_pascal = to_pascal_case(self.schema.sort_key)

            # List by sort key only
            field = f"{self.schema.name}ListBy{sk_pascal}"
            operation = Operation(
                name=f"ListBy{sk_pascal}",
                type="Query",
                field=field,
                dynamodb_op="Query",
                index_partition=self.schema.sort_key,
                index_sort=None,
                index_name=None,
                response_auth_directives=self._get_auth_directives(field),
            )
            self._add_operation(operation)

            # List by partition AND sort key
            field = f"{self.schema.name}ListBy{pk_pascal}And{sk_pascal}"
            operation = Operation(
                name=f"ListBy{pk_pascal}And{sk_pascal}",
                type="Query",
                field=field,
                dynamodb_op="Query",
                index_partition=self.schema.partition_key,
                index_sort=self.schema.sort_key,
                index_name=None,
                response_auth_directives=self._get_auth_directives(field),
            )
            self._add_operation(operation)

        # List by secondary indexes
        if self.schema.secondary_indexes:
            for index in self.schema.secondary_indexes:
                idx_pascal = to_pascal_case(index["partition"])

                # List by partition key only
                field = f"{self.schema.name}ListBy{idx_pascal}"
                operation = Operation(
                    name=f"ListBy{idx_pascal}",
                    type="Query",
                    field=field,
                    dynamodb_op="Query",
                    index_partition=index["partition"],
                    index_sort=None,
                    index_name=index["name"],
                    response_auth_directives=self._get_auth_directives(field),
                )
                self._add_operation(operation)

                # List by partition AND sort key if present
                if index.get("sort") and index["sort"] != "None":
                    sk_pascal = to_pascal_case(index["sort"])
                    field = f"{self.schema.name}ListBy{idx_pascal}And{sk_pascal}"
                    operation = Operation(
                        name=f"ListBy{idx_pascal}And{sk_pascal}",
                        type="Query",
                        field=field,
                        dynamodb_op="Query",
                        index_partition=index["partition"],
                        index_sort=index.get("sort"),
                        index_name=index["name"],
                        response_auth_directives=self._get_auth_directives(field),
                    )
                    self._add_operation(operation)

    def _add_custom_queries(self) -> None:
        """Add custom query operations."""
        if not self.schema.custom_queries:
            return

        for custom_query in self.schema.custom_queries:
            operation = Operation(
                name=custom_query.name,
                type="Query",
                field=custom_query.name,
                custom_type=custom_query.type,
                enrichments=custom_query.enrichments,
                returns=custom_query.returns,
                description=custom_query.description,
                input=custom_query.input,
                response_auth_directives=self._get_auth_directives(custom_query.name),
            )
            self._add_operation(operation)

    def _validate_operations(self) -> None:
        """Validate that all operations have proper auth directives."""
        for op in self._operations.values():
            if not op.response_auth_directives:
                raise SchemaValidationError(
                    f"Operation '{op.field}' in schema '{self.schema.name}' is missing auth "
                    f"directives. Please ensure authConfig is set correctly in the schema YAML."
                )
