"""Target validation for schema-to-config consistency.

This module provides validation to ensure:
1. All schema targets exist in configuration
2. All configured targets are referenced by at least one schema
3. Target languages are enabled
"""

from dataclasses import dataclass, field
from typing import Dict, List, Set, Union

from .config import GeneratorConfig, OutputConfig
from .models import (
    StandardType,
    TableSchema,
    GraphQLType,
    RegistryType,
    LambdaType,
)

# Union type for all schema types
SchemaType = Union[StandardType, TableSchema, GraphQLType, RegistryType, LambdaType]


@dataclass
class TargetValidationError:
    """Represents a target validation error."""

    message: str
    schema_file: str = ""
    target: str = ""
    language: str = ""
    valid_targets: List[str] = field(default_factory=list)


@dataclass
class TargetValidationResult:
    """Result of target validation."""

    errors: List[TargetValidationError] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        """Check if validation passed."""
        return len(self.errors) == 0


class TargetValidator:
    """Validates target consistency between schemas and configuration."""

    def validate(
        self,
        schemas: Dict[str, SchemaType],
        config: GeneratorConfig,
    ) -> TargetValidationResult:
        """Validate targets between schemas and configuration.

        Args:
            schemas: Dictionary mapping schema names to schema objects
            config: Generator configuration with target definitions

        Returns:
            TargetValidationResult with any errors found
        """
        errors: List[TargetValidationError] = []

        # Collect targets from schemas
        schema_targets = self._collect_schema_targets(schemas)

        # Validate for each language
        for language in ["python", "typescript", "dart", "graphql"]:
            config_targets = config.get_all_targets(language)
            is_enabled = self._is_language_enabled(config, language)

            # Check if language is disabled but has schema targets
            if not is_enabled and schema_targets:
                # Check if any schema targets would need this language
                for target, schema_names in schema_targets.items():
                    if config_targets and target in config_targets:
                        errors.append(
                            TargetValidationError(
                                message=(
                                    f"Target '{target}' references disabled language "
                                    f"'{language}'. Enable {language} in configuration "
                                    f"or remove the target."
                                ),
                                target=target,
                                language=language,
                            )
                        )

            if not is_enabled:
                continue

            # Check schema targets exist in config
            for target, schema_names in schema_targets.items():
                if target not in config_targets:
                    schema_list = ", ".join(sorted(schema_names))
                    valid_list = sorted(config_targets.keys())
                    errors.append(
                        TargetValidationError(
                            message=(
                                f"Target '{target}' referenced in schemas "
                                f"({schema_list}) not found in "
                                f"{language} configuration. "
                                f"Valid targets: {valid_list}"
                            ),
                            schema_file=schema_list,
                            target=target,
                            language=language,
                            valid_targets=valid_list,
                        )
                    )

            # Check config targets are referenced by schemas
            for target in config_targets:
                if target not in schema_targets:
                    errors.append(
                        TargetValidationError(
                            message=(
                                f"Target '{target}' defined in {language} "
                                f"configuration but not referenced by any schema"
                            ),
                            target=target,
                            language=language,
                        )
                    )

            # Check for duplicate output directories (Issue #56)
            duplicate_errors = self._check_duplicate_output_dirs(config_targets, language)
            errors.extend(duplicate_errors)

        return TargetValidationResult(errors=errors)

    def _collect_schema_targets(
        self,
        schemas: Dict[str, SchemaType],
    ) -> Dict[str, Set[str]]:
        """Collect all targets referenced by schemas.

        Args:
            schemas: Dictionary mapping schema names to schema objects

        Returns:
            Dictionary mapping target names to sets of schema names
        """
        targets: Dict[str, Set[str]] = {}

        for schema_name, schema in schemas.items():
            schema_targets = getattr(schema, "targets", [])
            for target in schema_targets:
                if target not in targets:
                    targets[target] = set()
                targets[target].add(schema_name)

        return targets

    def _is_language_enabled(self, config: GeneratorConfig, language: str) -> bool:
        """Check if a language is enabled in configuration.

        A language is considered enabled if:
        1. It has an explicit enabled flag set to True, AND
        2. It has at least one target configured

        Args:
            config: Generator configuration
            language: Language name (python, typescript, dart, graphql)

        Returns:
            True if language is enabled and has targets, False otherwise
        """
        # Check if targets are configured - no targets means not enabled
        targets = config.get_all_targets(language)
        if not targets:
            return False

        if language == "graphql":
            # GraphQL doesn't have explicit enabled flag
            # It's enabled if there are targets configured
            return True

        enabled_attr = f"{language}_enabled"
        return getattr(config, enabled_attr, False)

    def _check_duplicate_output_dirs(
        self,
        config_targets: Dict[str, OutputConfig],
        language: str,
    ) -> List[TargetValidationError]:
        """Check for multiple targets sharing the same output directory.

        When multiple targets write to the same directory, the last one
        overwrites previous outputs, causing data loss (Issue #56).

        Args:
            config_targets: Dictionary mapping target names to OutputConfig
            language: Language name for error messages

        Returns:
            List of validation errors for duplicate directories
        """
        errors: List[TargetValidationError] = []

        # Group targets by their base_dir
        dir_to_targets: Dict[str, List[str]] = {}
        for target_name, output_config in config_targets.items():
            if isinstance(output_config, OutputConfig):
                # Resolve to absolute path for accurate comparison
                base_dir = str(output_config.base_dir.resolve())
                if base_dir not in dir_to_targets:
                    dir_to_targets[base_dir] = []
                dir_to_targets[base_dir].append(target_name)

        # Report errors for directories with multiple targets
        for base_dir, target_names in dir_to_targets.items():
            if len(target_names) > 1:
                targets_str = ", ".join(sorted(target_names))
                errors.append(
                    TargetValidationError(
                        message=(
                            f"Multiple {language} targets share the same output directory "
                            f"'{base_dir}': [{targets_str}]. "
                            f"Each target will overwrite the previous output. "
                            f"Use different base_dir paths for each target."
                        ),
                        language=language,
                    )
                )

        return errors
