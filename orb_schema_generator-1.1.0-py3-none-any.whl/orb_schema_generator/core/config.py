"""Configuration management for schema generator."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional, Dict, List
import yaml
import os
import logging

from .models import MissingLanguageTargetsError

logger = logging.getLogger(__name__)


class Environment(str, Enum):
    """Standard deployment environments.

    Standard values are validated without warning.
    Custom values are allowed but trigger a validation warning.
    """

    DEV = "dev"
    STG = "stg"
    UAT = "uat"
    QA = "qa"
    PRD = "prd"

    @classmethod
    def is_standard(cls, value: str) -> bool:
        """Check if value is a standard environment.

        Args:
            value: Environment value to check

        Returns:
            True if value is a standard environment, False otherwise
        """
        return value.lower() in [e.value for e in cls]

    @classmethod
    def values(cls) -> List[str]:
        """Return list of standard environment values.

        Returns:
            List of standard environment value strings
        """
        return [e.value for e in cls]


@dataclass
class OutputConfig:
    """Configuration for output paths with sensible defaults.

    This is the SINGLE SOURCE OF TRUTH for output paths.
    All generators use OutputConfig to determine where files are written.

    Provides a unified way to configure where generated files are placed,
    with separate subdirectories for enums and models.
    """

    base_dir: Path = field(default_factory=lambda: Path("./generated"))
    enums_subdir: str = "enums"
    models_subdir: str = "models"
    generate_init: bool = True  # Python: generate __init__.py barrel files
    barrel_file: bool = True  # Dart: generate barrel files (models.dart, enums.dart)
    imports_from: Dict[str, str] = field(default_factory=dict)  # Maps target name to import path
    graphql_queries_subdir: Optional[str] = None  # TypeScript: generate GraphQL query files

    def enum_path(self, name: str, extension: str) -> Path:
        """Get the full path for an enum file.

        Args:
            name: The enum name (will be used as filename)
            extension: File extension (e.g., 'py', 'ts', 'dart')

        Returns:
            Full path to the enum file
        """
        if self.enums_subdir:
            return self.base_dir / self.enums_subdir / f"{name}.{extension}"
        return self.base_dir / f"{name}.{extension}"

    def model_path(self, name: str, extension: str) -> Path:
        """Get the full path for a model file.

        Args:
            name: The model name (will be used as filename)
            extension: File extension (e.g., 'py', 'ts', 'dart')

        Returns:
            Full path to the model file
        """
        if self.models_subdir:
            return self.base_dir / self.models_subdir / f"{name}.{extension}"
        return self.base_dir / f"{name}.{extension}"

    def relative_import_path(self, from_type: str, to_type: str) -> str:
        """Calculate relative import path between subdirectories.

        This is the SINGLE SOURCE OF TRUTH for import path calculation.
        All generators (Python, TypeScript, Dart) use this method to
        determine the correct relative path for imports.

        Args:
            from_type: Source type ("model" or "enum")
            to_type: Target type ("model" or "enum")

        Returns:
            Relative path prefix for imports (e.g., "../enums/", "./", "enums/")
            Always ends with "/" for consistency, except "./" for same directory.

        Examples:
            - models -> enums: "../enums/"
            - models -> models: "./"
            - "" -> enums: "enums/"
            - models -> "": "../"
            - types/models -> types/enums: "../enums/"
        """
        from_subdir = self.models_subdir if from_type == "model" else self.enums_subdir
        to_subdir = self.models_subdir if to_type == "model" else self.enums_subdir

        # Same directory - use current directory reference
        if from_subdir == to_subdir:
            return "./"

        # Split into path parts, filtering out empty strings
        from_parts = [p for p in from_subdir.split("/") if p] if from_subdir else []
        to_parts = [p for p in to_subdir.split("/") if p] if to_subdir else []

        # Go up from source directory (one "../" per directory level)
        up_count = len(from_parts)
        up_path = "../" * up_count if up_count > 0 else ""

        # Go down to target directory
        down_path = "/".join(to_parts) + "/" if to_parts else ""

        result = up_path + down_path
        return result if result else "./"

    def init_path(self, subdir_type: str) -> Path:
        """Get the path for __init__.py in a subdirectory.

        Args:
            subdir_type: "model" or "enum"

        Returns:
            Full path to the __init__.py file
        """
        subdir = self.models_subdir if subdir_type == "model" else self.enums_subdir
        if subdir:
            return self.base_dir / subdir / "__init__.py"
        return self.base_dir / "__init__.py"

    def barrel_path(self, subdir_type: str, name: str) -> Path:
        """Get the path for a Dart barrel file.

        Args:
            subdir_type: "model" or "enum"
            name: Barrel file name (without extension)

        Returns:
            Full path to the barrel file
        """
        subdir = self.models_subdir if subdir_type == "model" else self.enums_subdir
        if subdir:
            return self.base_dir / subdir / f"{name}.dart"
        return self.base_dir / f"{name}.dart"

    def graphql_queries_path(self, filename: str) -> Optional[Path]:
        """Get the path for a GraphQL query definition file.

        Args:
            filename: The filename (e.g., "Organizations.graphql.ts" or "index.ts")

        Returns:
            Full path to the GraphQL query file, or None if not configured
        """
        if not self.graphql_queries_subdir:
            return None
        return self.base_dir / self.graphql_queries_subdir / filename


@dataclass
class AppSyncAuthConfig:
    """AppSync authorization configuration.

    USER_POOL is the default authorization type.
    API_KEY is added as additional auth when public_endpoints is True.
    """

    user_pool_id: str  # SSM parameter name (required)
    public_endpoints: bool = True  # adds API_KEY as additional auth


@dataclass
class AppSyncLoggingConfig:
    """CloudWatch logging configuration for AppSync."""

    enabled: bool = False
    level: str = "ALL"  # ALL | ERROR | NONE


@dataclass
class AppSyncApiKeyConfig:
    """API Key configuration for AppSync."""

    expiration_days: int = 365


@dataclass
class AppSyncSsmConfig:
    """SSM parameter output configuration for AppSync."""

    enabled: bool = True


@dataclass
class AppSyncConfig:
    """AppSync-specific configuration for resolver generation.

    DEPRECATED: This class is for legacy single-API configuration.
    Use ApiDefinition for multi-API support (v0.20.0+).
    """

    resolver_output_dir: Optional[str] = None
    auth: Optional[AppSyncAuthConfig] = None
    logging: Optional[AppSyncLoggingConfig] = None
    api_key: Optional[AppSyncApiKeyConfig] = None
    ssm: Optional[AppSyncSsmConfig] = None


# =============================================================================
# MULTI-APPSYNC API CONFIGURATION (Issue #83)
# =============================================================================


@dataclass
class LambdaAuthorizerConfig:
    """Lambda authorizer configuration for AppSync API.

    Either function_name or function_arn_ssm_param must be provided.
    """

    function_name: Optional[str] = None
    function_arn_ssm_param: Optional[str] = None
    result_ttl_seconds: int = 300
    identity_validation_expression: Optional[str] = None


@dataclass
class OidcConfig:
    """OpenID Connect configuration for AppSync API."""

    issuer: str
    client_id: Optional[str] = None
    auth_ttl: Optional[int] = None
    iat_ttl: Optional[int] = None


@dataclass
class CognitoConfig:
    """Cognito User Pool configuration for AppSync API."""

    user_pool_ssm_param: str


@dataclass
class MultiApiAuthConfig:
    """Authorization configuration for a multi-API AppSync definition.

    Supports all AppSync authorization modes:
    - AMAZON_COGNITO_USER_POOLS
    - AWS_LAMBDA
    - AWS_IAM
    - OPENID_CONNECT
    - API_KEY
    """

    default: str  # Primary auth mode
    additional: List[str] = field(default_factory=list)
    cognito: Optional[CognitoConfig] = None
    lambda_authorizer: Optional[LambdaAuthorizerConfig] = None
    oidc: Optional[OidcConfig] = None

    # Valid authorization modes
    VALID_AUTH_MODES = frozenset(
        {
            "AMAZON_COGNITO_USER_POOLS",
            "AWS_LAMBDA",
            "AWS_IAM",
            "OPENID_CONNECT",
            "API_KEY",
        }
    )


@dataclass
class ApiDefinition:
    """Definition for a single AppSync API in multi-API configuration.

    Each API has independent:
    - Authorization configuration
    - Table subset (which schemas to include)
    - Operation filters (which operations to expose)
    - Output paths for generated files
    """

    name: str
    auth: MultiApiAuthConfig
    tables: List[str]
    include_operations: List[str]
    schema_output: Path
    resolvers_output: Path
    cdk_output: Path


@dataclass
class LambdaConfig:
    """Configuration for Lambda resolver generation."""

    resolver_output_dir: Optional[str] = None
    lambda_arn_pattern: Optional[str] = None
    use_ssm_parameters: bool = True


@dataclass
class DartConfig:
    """Configuration for Dart/Flutter code generation."""

    enabled: bool = False
    hive: bool = False
    equatable: bool = False
    immutable: bool = True
    null_safety: bool = True
    hive_type_id_start: int = 0  # Starting typeId for Hive annotations


# =============================================================================
# S3 CONFIGURATION (Issue #53)
# =============================================================================


@dataclass
class S3RolePermissions:
    """Permission configuration for a role in S3 target.

    Defines what operations a role can perform and the scope of access.
    """

    permissions: List[str]  # ["read", "write", "delete"]
    scope: str  # "own" (user's files only) or "all" (all files)

    # Valid permission values
    VALID_PERMISSIONS = frozenset({"read", "write", "delete"})
    # Valid scope values
    VALID_SCOPES = frozenset({"own", "all"})


@dataclass
class S3BucketDefaults:
    """Default bucket settings for an S3 target.

    These defaults are applied to all S3 schemas using this target
    unless overridden in the schema.
    """

    versioning: bool = False
    encryption: str = "AES256"  # "AES256" or "KMS"
    kms_key_id: Optional[str] = None


@dataclass
class S3TargetConfig:
    """Configuration for an S3 access target.

    Defines the access pattern and security rules for S3 storage.
    S3 schemas reference a target by name to inherit these settings.
    """

    user_id_source: str  # e.g., "identity.sub" - path to extract user ID
    default_auth: str  # "USER_POOL" or "API_KEY"
    base_path_pattern: str  # e.g., "users/{userId}" - base path for user isolation
    roles: Dict[str, S3RolePermissions]  # Role name -> permissions
    defaults: Optional[S3BucketDefaults] = None

    # Valid auth types
    VALID_AUTH_TYPES = frozenset({"USER_POOL", "API_KEY"})


@dataclass
class GeneratorConfig:
    """Configuration for schema generation.

    Output paths are managed through OutputConfig objects (python_output,
    typescript_output, dart_output, graphql_output). These are the SINGLE
    SOURCE OF TRUTH for where generated files are written.
    """

    # Project info
    customer_id: str = field(default_factory=lambda: os.environ.get("CUSTOMER_ID", "orb"))
    project_id: str = field(
        default_factory=lambda: os.environ.get("PROJECT_ID", "schema-generator")
    )
    environment: str = field(default_factory=lambda: os.environ.get("ENVIRONMENT", "development"))

    _project_name: Optional[str] = None

    @property
    def project_name(self) -> str:
        """Get the dynamic project name."""
        if self._project_name:
            return self._project_name
        return f"{self.customer_id}-{self.project_id}-{self.environment}"

    @project_name.setter
    def project_name(self, value: str) -> None:
        """Set the project name (overrides dynamic naming)."""
        self._project_name = value

    # Input paths
    schema_dir: Path = Path("./schemas")
    template_dir: Optional[Path] = None

    # Schema subdirectories (None = flat structure)
    schema_subdirectories: Optional[Dict[str, str]] = field(
        default_factory=lambda: {
            "core": "core",
            "tables": "tables",
            "models": "models",
            "registries": "registries",
            "graphql": "graphql",
            "lambdas": "lambdas",
        }
    )

    # Output paths - Infrastructure (kept separate as they're not language-specific)
    infrastructure_format: str = "cloudformation"
    cloudformation_dir: Path = Path("./infrastructure/cloudformation")
    cdk_output_dir: Path = Path("./infrastructure/cdk")
    cdk_language: str = "python"
    cdk_generate_stack: bool = True  # Generate complete stack definition
    cdk_stack_output_dir: Optional[Path] = None  # Defaults to parent of cdk_output_dir
    cdk_stack_name: str = "backend_stack"  # Stack file name (without extension)

    # Generation options
    validate_schemas: bool = True
    validate_graphql: bool = True
    cleanup_old_files: bool = True

    # Logging
    log_level: str = "INFO"
    log_file: Optional[Path] = Path("./schema_generator.log")

    # AppSync configuration (legacy single-API - deprecated)
    appsync: Optional[AppSyncConfig] = None

    # Multi-API AppSync configuration (Issue #83)
    api_definitions: List[ApiDefinition] = field(default_factory=list)

    # Lambda resolver configuration
    lambda_config: Optional[LambdaConfig] = None

    # Generator enable/disable flags
    python_enabled: bool = True
    typescript_enabled: bool = True
    dart_enabled: bool = False

    # Dart-specific options (non-path related)
    dart_config: Optional[DartConfig] = None

    # ==========================================================================
    # OUTPUT CONFIGURATION - SINGLE SOURCE OF TRUTH
    # All generators use these OutputConfig objects for output paths.
    # Uses Nx/Turborepo-style apps/ directory structure.
    # ==========================================================================
    python_output: OutputConfig = field(
        default_factory=lambda: OutputConfig(
            base_dir=Path("./apps/api"),
            enums_subdir="enums",
            models_subdir="models",
        )
    )
    typescript_output: OutputConfig = field(
        default_factory=lambda: OutputConfig(
            base_dir=Path("./apps/web"),
            enums_subdir="enums",
            models_subdir="models",
        )
    )
    dart_output: OutputConfig = field(
        default_factory=lambda: OutputConfig(
            base_dir=Path("./apps/mobile/lib"),
            enums_subdir="enums",
            models_subdir="models",
        )
    )
    graphql_output: OutputConfig = field(
        default_factory=lambda: OutputConfig(
            base_dir=Path("./apps/api/graphql"),
            enums_subdir="",
            models_subdir="",
        )
    )

    # ==========================================================================
    # TARGET-BASED OUTPUT CONFIGURATION
    # Maps target names to OutputConfig objects for multi-destination output.
    # When targets are configured, they take precedence over single output configs.
    # ==========================================================================
    python_targets: Dict[str, OutputConfig] = field(default_factory=dict)
    typescript_targets: Dict[str, OutputConfig] = field(default_factory=dict)
    dart_targets: Dict[str, OutputConfig] = field(default_factory=dict)
    graphql_targets: Dict[str, OutputConfig] = field(default_factory=dict)

    # ==========================================================================
    # S3 TARGET CONFIGURATION (Issue #53)
    # Maps target names to S3TargetConfig objects for S3 storage schemas.
    # ==========================================================================
    s3_targets: Dict[str, S3TargetConfig] = field(default_factory=dict)

    def get_target_config(self, language: str, target: str) -> Optional[OutputConfig]:
        """Get OutputConfig for a specific language and target.

        Args:
            language: Language name (python, typescript, dart, graphql)
            target: Target name from schema

        Returns:
            OutputConfig for the target, or None if not found
        """
        targets = getattr(self, f"{language}_targets", {})
        return targets.get(target)

    def get_all_targets(self, language: str) -> Dict[str, OutputConfig]:
        """Get all targets for a language.

        Args:
            language: Language name (python, typescript, dart, graphql)

        Returns:
            Dictionary mapping target names to OutputConfig objects
        """
        return getattr(self, f"{language}_targets", {})

    def get_s3_target(self, target_name: str) -> Optional[S3TargetConfig]:
        """Get S3 target configuration by name.

        Args:
            target_name: Name of the S3 target

        Returns:
            S3TargetConfig for the target, or None if not found
        """
        return self.s3_targets.get(target_name)

    def get_all_s3_targets(self) -> Dict[str, S3TargetConfig]:
        """Get all S3 targets.

        Returns:
            Dictionary mapping target names to S3TargetConfig objects
        """
        return self.s3_targets

    @property
    def enums_file(self) -> Path:
        """Get path to enums file based on subdirectory configuration."""
        if self.schema_subdirectories is None:
            return self.schema_dir / "enums.yml"
        elif "core" in self.schema_subdirectories:
            return self.schema_dir / self.schema_subdirectories["core"] / "enums.yml"
        else:
            return self.schema_dir / "core" / "enums.yml"

    @classmethod
    def from_file(cls, config_path: str) -> "GeneratorConfig":
        """Load configuration from YAML file.

        All output paths are normalized to OutputConfig objects.
        Uses Nx-style apps/ directory structure by default.
        """
        with open(config_path, "r") as f:
            data = yaml.safe_load(f)

        config = cls()

        # Project info
        if "project" in data:
            # Only set project_name if explicitly provided (preserves dynamic naming)
            if "name" in data["project"]:
                config.project_name = data["project"]["name"]
            config.customer_id = data["project"].get("customerId", config.customer_id)
            config.project_id = data["project"].get("projectId", config.project_id)
            config.environment = data["project"].get("environment", config.environment)

        # Input paths
        if "paths" in data:
            if "schemas" in data["paths"]:
                config.schema_dir = Path(data["paths"]["schemas"])
            if "templates" in data["paths"] and data["paths"]["templates"]:
                config.template_dir = Path(data["paths"]["templates"])
            if "subdirectories" in data["paths"]:
                subdirs = data["paths"]["subdirectories"]
                config.schema_subdirectories = subdirs if subdirs else None

        # Generation options
        if "generation" in data:
            gen = data["generation"]
            config.validate_schemas = gen.get("validate_schemas", config.validate_schemas)
            config.validate_graphql = gen.get("validate_graphql", config.validate_graphql)
            config.cleanup_old_files = gen.get("cleanup_old_files", config.cleanup_old_files)

        # Logging
        if "logging" in data:
            log = data["logging"]
            config.log_level = log.get("level", config.log_level)
            if "file" in log:
                config.log_file = Path(log["file"])

        # Parse output configuration
        if "output" in data:
            config._parse_output_config(data["output"])

        return config

    def _parse_output_config(self, output_data: dict) -> None:
        """Parse output configuration from YAML data.

        Handles targets-based configuration (required for v0.10.0+).
        Each enabled language must have a 'targets' map.
        """
        # =================================================================
        # PYTHON OUTPUT
        # =================================================================
        if "python" in output_data:
            python_data = output_data["python"]
            self.python_enabled = python_data.get("enabled", True)

            # Parse targets map (required for enabled languages)
            if "targets" in python_data:
                self.python_targets = self._parse_targets_map(python_data["targets"])
            elif self.python_enabled:
                # Targets are required for enabled languages in v0.10.0+
                raise MissingLanguageTargetsError("python")

        # =================================================================
        # TYPESCRIPT OUTPUT
        # =================================================================
        if "typescript" in output_data:
            ts_data = output_data["typescript"]
            self.typescript_enabled = ts_data.get("enabled", True)

            # Parse targets map (required for enabled languages)
            if "targets" in ts_data:
                self.typescript_targets = self._parse_targets_map(ts_data["targets"])
            elif self.typescript_enabled:
                # Targets are required for enabled languages in v0.10.0+
                raise MissingLanguageTargetsError("typescript")

        # =================================================================
        # DART OUTPUT
        # =================================================================
        if "dart" in output_data:
            dart_data = output_data["dart"]
            self.dart_enabled = dart_data.get("enabled", False)

            # Parse targets map (required for enabled languages)
            if "targets" in dart_data:
                self.dart_targets = self._parse_targets_map(dart_data["targets"])
            elif self.dart_enabled:
                # Targets are required for enabled languages in v0.10.0+
                raise MissingLanguageTargetsError("dart")

            # Parse Dart-specific options
            dart_options = dart_data.get("options", {})
            self.dart_config = DartConfig(
                enabled=self.dart_enabled,
                hive=dart_options.get("hive", False),
                equatable=dart_options.get("equatable", False),
                immutable=dart_options.get("immutable", True),
                null_safety=dart_options.get("null_safety", True),
                hive_type_id_start=dart_options.get("hive_type_id_start", 0),
            )

        # =================================================================
        # GRAPHQL OUTPUT
        # =================================================================
        if "graphql" in output_data:
            gql_data = output_data["graphql"]
            # GraphQL doesn't have an explicit enabled flag - presence implies enabled
            graphql_enabled = gql_data.get("enabled", True)

            # Parse targets map (required for enabled languages)
            if "targets" in gql_data:
                self.graphql_targets = self._parse_targets_map(gql_data["targets"])
            elif graphql_enabled:
                # Targets are required for enabled languages in v0.10.0+
                raise MissingLanguageTargetsError("graphql")

        # =================================================================
        # INFRASTRUCTURE
        # =================================================================
        if "infrastructure" in output_data:
            infra = output_data["infrastructure"]
            self.infrastructure_format = infra.get("format", self.infrastructure_format)

            if "cdk" in infra:
                cdk = infra["cdk"]
                if "base_dir" in cdk:
                    self.cdk_output_dir = Path(cdk["base_dir"])
                if "language" in cdk:
                    self.cdk_language = cdk["language"]
                if "generate_stack" in cdk:
                    self.cdk_generate_stack = cdk["generate_stack"]
                if "stack_output_dir" in cdk:
                    self.cdk_stack_output_dir = Path(cdk["stack_output_dir"])
                if "stack_name" in cdk:
                    self.cdk_stack_name = cdk["stack_name"]

            if "cloudformation" in infra:
                cf = infra["cloudformation"]
                if "base_dir" in cf:
                    self.cloudformation_dir = Path(cf["base_dir"])

            if "appsync" in infra:
                appsync_data = infra["appsync"]
                self._parse_appsync_config(appsync_data)

            if "lambda" in infra:
                lambda_data = infra["lambda"]
                self.lambda_config = LambdaConfig(
                    resolver_output_dir=lambda_data.get("resolverOutputDir"),
                    lambda_arn_pattern=lambda_data.get("lambdaArnPattern"),
                    use_ssm_parameters=lambda_data.get("useSsmParameters", True),
                )

            # =============================================================
            # S3 TARGETS (Issue #53)
            # =============================================================
            if "s3" in infra:
                s3_data = infra["s3"]
                if "targets" in s3_data:
                    self.s3_targets = self._parse_s3_targets(s3_data["targets"])

    def _parse_targets_map(self, targets_data: dict) -> Dict[str, OutputConfig]:
        """Parse a targets map from configuration.

        Args:
            targets_data: Dictionary mapping target names to output configurations

        Returns:
            Dictionary mapping target names to OutputConfig objects
        """
        targets = {}
        for target_name, target_config in targets_data.items():
            base_dir = Path(target_config.get("base_dir", "./generated"))
            enums_subdir = target_config.get("enums_subdir", "enums")
            models_subdir = target_config.get("models_subdir", "models")
            generate_init = target_config.get("generate_init", True)
            barrel_file = target_config.get("barrel_file", True)
            imports_from = target_config.get("imports_from", {})
            graphql_queries_subdir = target_config.get("graphql_queries_subdir")

            targets[target_name] = OutputConfig(
                base_dir=base_dir,
                enums_subdir=enums_subdir,
                models_subdir=models_subdir,
                generate_init=generate_init,
                barrel_file=barrel_file,
                imports_from=imports_from,
                graphql_queries_subdir=graphql_queries_subdir,
            )
        return targets

    def _parse_s3_targets(self, targets_data: dict) -> Dict[str, S3TargetConfig]:
        """Parse S3 targets from configuration.

        Args:
            targets_data: Dictionary mapping target names to S3 configurations

        Returns:
            Dictionary mapping target names to S3TargetConfig objects

        Raises:
            ConfigurationError: If required fields are missing or invalid
        """
        from .models import ConfigurationError

        targets = {}
        for target_name, target_config in targets_data.items():
            # Validate required fields
            required_fields = ["user_id_source", "base_path_pattern", "roles"]
            for required_field in required_fields:
                if required_field not in target_config:
                    raise ConfigurationError(
                        f"S3 target '{target_name}' is missing required field: {required_field}"
                    )

            # Parse roles
            roles_data = target_config["roles"]
            roles = {}
            for role_name, role_config in roles_data.items():
                # Validate permissions
                permissions = role_config.get("permissions", [])
                for perm in permissions:
                    if perm not in S3RolePermissions.VALID_PERMISSIONS:
                        raise ConfigurationError(
                            f"S3 target '{target_name}' role '{role_name}' has invalid "
                            f"permission: {perm}. Valid: {', '.join(sorted(S3RolePermissions.VALID_PERMISSIONS))}"
                        )

                # Validate scope
                scope = role_config.get("scope", "own")
                if scope not in S3RolePermissions.VALID_SCOPES:
                    raise ConfigurationError(
                        f"S3 target '{target_name}' role '{role_name}' has invalid "
                        f"scope: {scope}. Valid: {', '.join(sorted(S3RolePermissions.VALID_SCOPES))}"
                    )

                roles[role_name] = S3RolePermissions(
                    permissions=permissions,
                    scope=scope,
                )

            # Validate default_auth
            default_auth = target_config.get("default_auth", "USER_POOL")
            if default_auth not in S3TargetConfig.VALID_AUTH_TYPES:
                raise ConfigurationError(
                    f"S3 target '{target_name}' has invalid default_auth: {default_auth}. "
                    f"Valid: {', '.join(sorted(S3TargetConfig.VALID_AUTH_TYPES))}"
                )

            # Parse defaults (optional)
            defaults = None
            if "defaults" in target_config:
                defaults_data = target_config["defaults"]
                defaults = S3BucketDefaults(
                    versioning=defaults_data.get("versioning", False),
                    encryption=defaults_data.get("encryption", "AES256"),
                    kms_key_id=defaults_data.get("kms_key_id"),
                )

            targets[target_name] = S3TargetConfig(
                user_id_source=target_config["user_id_source"],
                default_auth=default_auth,
                base_path_pattern=target_config["base_path_pattern"],
                roles=roles,
                defaults=defaults,
            )

        return targets

    def _parse_appsync_config(self, appsync_data: dict) -> None:
        """Parse AppSync configuration from YAML data.

        Supports multi-API format (v0.20.0+). Legacy single-API format
        is rejected with a migration error.

        Args:
            appsync_data: Dictionary from appsync section of config

        Raises:
            ConfigurationError: If legacy format detected or validation fails
        """
        from .models import ConfigurationError

        # Detect legacy format: has 'auth', 'logging', 'apiKey', 'ssm' at top level
        # but no named API definitions
        legacy_keys = {"auth", "logging", "apiKey", "ssm", "resolverOutputDir", "generateResolvers"}
        has_legacy_keys = any(key in appsync_data for key in legacy_keys)

        # Check if any key looks like an API definition (has 'name' or 'tables' or 'auth.default')
        has_api_definitions = any(
            isinstance(v, dict) and ("tables" in v or "include_operations" in v)
            for v in appsync_data.values()
        )

        if has_legacy_keys and not has_api_definitions:
            raise ConfigurationError(
                "Legacy single-API appsync configuration is no longer supported. "
                "Migrate to multi-API format. See: https://docs.orb.dev/migration/multi-api"
            )

        # Parse each named API definition
        for api_name, api_config in appsync_data.items():
            if not isinstance(api_config, dict):
                continue

            api_def = self._parse_api_definition(api_name, api_config)
            self.api_definitions.append(api_def)

    def _parse_api_definition(self, api_name: str, api_config: dict) -> ApiDefinition:
        """Parse a single API definition from configuration.

        Args:
            api_name: Name of the API (key in appsync section)
            api_config: Configuration dictionary for this API

        Returns:
            ApiDefinition object

        Raises:
            ConfigurationError: If required fields are missing or invalid
        """
        from .models import ConfigurationError

        # Parse auth configuration
        if "auth" not in api_config:
            raise ConfigurationError(f"API '{api_name}' is missing required 'auth' configuration")
        auth = self._parse_multi_api_auth(api_name, api_config["auth"])

        # Parse tables list (required, non-empty)
        if "tables" not in api_config:
            raise ConfigurationError(
                f"API '{api_name}' requires 'tables' list specifying which schemas to include"
            )
        tables = api_config["tables"]
        if not tables or not isinstance(tables, list):
            raise ConfigurationError(
                f"API '{api_name}' requires at least one table in 'tables' list"
            )

        # Parse include_operations (required, non-empty)
        if "include_operations" not in api_config:
            raise ConfigurationError(
                f"API '{api_name}' requires 'include_operations' list specifying which operations to expose"
            )
        include_operations = api_config["include_operations"]
        if not include_operations or not isinstance(include_operations, list):
            raise ConfigurationError(
                f"API '{api_name}' requires at least one pattern in 'include_operations'"
            )

        # Parse output paths
        name_from_config = api_config.get("name", f"${{project}}-${{env}}-appsync-{api_name}")
        schema_output = Path(
            api_config.get("schema_output", f"apps/api/graphql/{api_name}-schema.graphql")
        )
        resolvers_output = Path(
            api_config.get("resolvers_output", f"apps/api/graphql/{api_name}-resolvers/")
        )
        cdk_output = Path(
            api_config.get("cdk_output", f"infrastructure/cdk/generated/appsync/{api_name}/")
        )

        return ApiDefinition(
            name=name_from_config,
            auth=auth,
            tables=tables,
            include_operations=include_operations,
            schema_output=schema_output,
            resolvers_output=resolvers_output,
            cdk_output=cdk_output,
        )

    def _parse_multi_api_auth(self, api_name: str, auth_data: dict) -> MultiApiAuthConfig:
        """Parse authorization configuration for a multi-API definition.

        Args:
            api_name: Name of the API (for error messages)
            auth_data: Auth configuration dictionary

        Returns:
            MultiApiAuthConfig object

        Raises:
            ConfigurationError: If auth configuration is invalid
        """
        from .models import ConfigurationError

        # Validate default auth mode
        default_mode = auth_data.get("default")
        if not default_mode:
            raise ConfigurationError(
                f"API '{api_name}' auth configuration requires 'default' authorization mode"
            )
        if default_mode not in MultiApiAuthConfig.VALID_AUTH_MODES:
            raise ConfigurationError(
                f"API '{api_name}' has invalid auth mode '{default_mode}'. "
                f"Valid: {', '.join(sorted(MultiApiAuthConfig.VALID_AUTH_MODES))}"
            )

        # Validate additional auth modes
        additional = auth_data.get("additional", [])
        for mode in additional:
            if mode not in MultiApiAuthConfig.VALID_AUTH_MODES:
                raise ConfigurationError(
                    f"API '{api_name}' has invalid additional auth mode '{mode}'. "
                    f"Valid: {', '.join(sorted(MultiApiAuthConfig.VALID_AUTH_MODES))}"
                )

        # Parse Cognito config
        cognito_config = None
        if "cognito" in auth_data:
            cognito_data = auth_data["cognito"]
            if "user_pool_ssm_param" not in cognito_data:
                raise ConfigurationError(
                    f"API '{api_name}' uses Cognito auth but missing 'cognito.user_pool_ssm_param'"
                )
            cognito_config = CognitoConfig(user_pool_ssm_param=cognito_data["user_pool_ssm_param"])

        # Validate Cognito is configured when using USER_POOL auth
        if default_mode == "AMAZON_COGNITO_USER_POOLS" and not cognito_config:
            raise ConfigurationError(
                f"API '{api_name}' uses AMAZON_COGNITO_USER_POOLS auth but missing 'cognito' configuration"
            )

        # Parse Lambda authorizer config
        lambda_config = None
        if "lambda_authorizer" in auth_data:
            lambda_data = auth_data["lambda_authorizer"]
            if not lambda_data.get("function_name") and not lambda_data.get(
                "function_arn_ssm_param"
            ):
                raise ConfigurationError(
                    f"API '{api_name}' uses Lambda auth but missing 'function_name' or 'function_arn_ssm_param'"
                )
            lambda_config = LambdaAuthorizerConfig(
                function_name=lambda_data.get("function_name"),
                function_arn_ssm_param=lambda_data.get("function_arn_ssm_param"),
                result_ttl_seconds=lambda_data.get("result_ttl_seconds", 300),
                identity_validation_expression=lambda_data.get("identity_validation_expression"),
            )

        # Validate Lambda is configured when using AWS_LAMBDA auth
        if default_mode == "AWS_LAMBDA" and not lambda_config:
            raise ConfigurationError(
                f"API '{api_name}' uses AWS_LAMBDA auth but missing 'lambda_authorizer' configuration"
            )

        # Parse OIDC config
        oidc_config = None
        if "oidc" in auth_data:
            oidc_data = auth_data["oidc"]
            if "issuer" not in oidc_data:
                raise ConfigurationError(
                    f"API '{api_name}' uses OIDC auth but missing 'oidc.issuer'"
                )
            oidc_config = OidcConfig(
                issuer=oidc_data["issuer"],
                client_id=oidc_data.get("client_id"),
                auth_ttl=oidc_data.get("auth_ttl"),
                iat_ttl=oidc_data.get("iat_ttl"),
            )

        # Validate OIDC is configured when using OPENID_CONNECT auth
        if default_mode == "OPENID_CONNECT" and not oidc_config:
            raise ConfigurationError(
                f"API '{api_name}' uses OPENID_CONNECT auth but missing 'oidc' configuration"
            )

        return MultiApiAuthConfig(
            default=default_mode,
            additional=additional,
            cognito=cognito_config,
            lambda_authorizer=lambda_config,
            oidc=oidc_config,
        )

    def _output_config_to_dict(self, language: str) -> dict:
        """Convert output configuration for a language to dictionary.

        Args:
            language: Language name (python, typescript, dart, graphql)

        Returns:
            Dictionary representation of the output configuration
        """
        targets = getattr(self, f"{language}_targets", {})
        output = getattr(self, f"{language}_output", None)
        enabled = getattr(self, f"{language}_enabled", True) if language != "graphql" else True

        result: dict = {"enabled": enabled} if language != "graphql" else {}

        if targets:
            # Use targets format
            result["targets"] = {
                name: {
                    "base_dir": str(config.base_dir),
                    "enums_subdir": config.enums_subdir,
                    "models_subdir": config.models_subdir,
                    "generate_init": config.generate_init,
                    "barrel_file": config.barrel_file,
                    "imports_from": config.imports_from,
                    "graphql_queries_subdir": config.graphql_queries_subdir,
                }
                for name, config in targets.items()
            }
        elif output:
            # Use legacy single-output format
            result["base_dir"] = str(output.base_dir)
            result["enums_subdir"] = output.enums_subdir
            result["models_subdir"] = output.models_subdir

        # Add dart-specific options
        if language == "dart" and self.dart_config:
            result["options"] = {
                "hive": self.dart_config.hive,
                "equatable": self.dart_config.equatable,
                "immutable": self.dart_config.immutable,
                "null_safety": self.dart_config.null_safety,
            }

        return result

    def to_dict(self) -> dict:
        """Convert configuration to dictionary."""
        return {
            "project": {
                "name": self.project_name,
                "customerId": self.customer_id,
                "projectId": self.project_id,
            },
            "paths": {
                "schemas": str(self.schema_dir),
                "templates": str(self.template_dir) if self.template_dir else None,
                "subdirectories": self.schema_subdirectories,
            },
            "output": {
                "python": self._output_config_to_dict("python"),
                "typescript": self._output_config_to_dict("typescript"),
                "dart": self._output_config_to_dict("dart"),
                "graphql": self._output_config_to_dict("graphql"),
                "infrastructure": {
                    "format": self.infrastructure_format,
                    "cdk": {
                        "base_dir": str(self.cdk_output_dir),
                        "language": self.cdk_language,
                        "generate_stack": self.cdk_generate_stack,
                        "stack_name": self.cdk_stack_name,
                    },
                    "cloudformation": {
                        "base_dir": str(self.cloudformation_dir),
                    },
                    "appsync": {
                        "resolverOutputDir": (
                            self.appsync.resolver_output_dir if self.appsync else None
                        ),
                        "auth": (
                            {
                                "userPoolId": self.appsync.auth.user_pool_id,
                                "publicEndpoints": self.appsync.auth.public_endpoints,
                            }
                            if self.appsync and self.appsync.auth
                            else None
                        ),
                        "logging": (
                            {
                                "enabled": self.appsync.logging.enabled,
                                "level": self.appsync.logging.level,
                            }
                            if self.appsync and self.appsync.logging
                            else None
                        ),
                        "apiKey": (
                            {
                                "expirationDays": self.appsync.api_key.expiration_days,
                            }
                            if self.appsync and self.appsync.api_key
                            else None
                        ),
                        "ssm": (
                            {
                                "enabled": self.appsync.ssm.enabled,
                            }
                            if self.appsync and self.appsync.ssm
                            else None
                        ),
                    },
                    "lambda": {
                        "resolverOutputDir": (
                            self.lambda_config.resolver_output_dir if self.lambda_config else None
                        ),
                        "lambdaArnPattern": (
                            self.lambda_config.lambda_arn_pattern if self.lambda_config else None
                        ),
                        "useSsmParameters": (
                            self.lambda_config.use_ssm_parameters if self.lambda_config else True
                        ),
                    },
                },
            },
            "generation": {
                "validate_schemas": self.validate_schemas,
                "validate_graphql": self.validate_graphql,
                "cleanup_old_files": self.cleanup_old_files,
            },
            "logging": {
                "level": self.log_level,
                "file": str(self.log_file) if self.log_file else None,
            },
        }

    def save(self, config_path: str) -> None:
        """Save configuration to YAML file."""
        with open(config_path, "w") as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, sort_keys=False)
