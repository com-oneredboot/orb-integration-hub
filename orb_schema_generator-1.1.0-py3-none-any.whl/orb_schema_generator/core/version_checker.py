"""Version checker for orb-schema-generator.

This module provides functionality to check for newer versions of the package
by querying PyPI. Results are cached for 24 hours to minimize network overhead.
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import logging
import urllib.request
import urllib.error
import json

from packaging.version import Version, InvalidVersion

from .version_cache import VersionCache

logger = logging.getLogger(__name__)


class VersionChecker:
    """Checks for newer versions of orb-schema-generator.

    Uses PyPI as the version source with 24-hour caching to minimize
    network overhead. All network operations have a 2-second timeout
    to avoid slowing down the generation workflow.

    Attributes:
        CACHE_TTL_HOURS: Time-to-live for cached version info (24 hours).
        REQUEST_TIMEOUT_SECONDS: Network request timeout (2 seconds).
        PYPI_URL: URL for PyPI JSON API.
    """

    CACHE_TTL_HOURS = 24
    REQUEST_TIMEOUT_SECONDS = 2
    PYPI_URL = "https://pypi.org/pypi/orb-schema-generator/json"
    PACKAGE_NAME = "orb-schema-generator"

    def __init__(self, cache_file: Optional[Path] = None):
        """Initialize the version checker.

        Args:
            cache_file: Optional custom path for the cache file.
                       Defaults to ~/.kiro/version-cache.json.
        """
        self._cache_file = cache_file or VersionCache.DEFAULT_CACHE_PATH

    def check_for_update(self, silent: bool = True) -> Optional[str]:
        """Check if a newer version is available.

        Args:
            silent: If True, suppress errors and return None on failure.
                   If False, raise exceptions on network errors.

        Returns:
            Warning message if update available, None otherwise.
            Returns None on any error when silent=True.
        """
        try:
            current = self.get_current_version()
            latest = self.get_latest_version(use_cache=True)

            if latest is None:
                return None

            if self._is_newer(latest, current):
                return (
                    f"A newer version of {self.PACKAGE_NAME} is available: "
                    f"{latest} (current: {current}). "
                    f"Run 'pip install --upgrade {self.PACKAGE_NAME}' to update."
                )

            return None

        except Exception as e:
            if silent:
                logger.debug(f"Version check failed (silent): {e}")
                return None
            raise

    def get_current_version(self) -> str:
        """Get the currently installed version.

        Returns:
            Version string of the installed package.

        Raises:
            PackageNotFoundError: If the package is not installed.
        """
        try:
            from importlib.metadata import version

            return version(self.PACKAGE_NAME)
        except Exception:
            # Fallback for development mode
            return "0.0.0"

    def get_latest_version(self, use_cache: bool = True) -> Optional[str]:
        """Get the latest available version from PyPI.

        Args:
            use_cache: If True, use cached version if valid.

        Returns:
            Latest version string, or None if unavailable.
        """
        # Try cache first
        if use_cache:
            cache = VersionCache.load(self._cache_file)
            if cache is not None and cache.is_valid(self.CACHE_TTL_HOURS):
                logger.debug(f"Using cached version: {cache.latest_version}")
                return cache.latest_version

        # Fetch from PyPI
        try:
            latest = self._fetch_latest_from_pypi()
            if latest:
                # Update cache
                cache = VersionCache(
                    latest_version=latest,
                    checked_at=datetime.now(timezone.utc),
                )
                cache.save(self._cache_file)
            return latest

        except Exception as e:
            logger.debug(f"Failed to fetch latest version: {e}")
            return None

    def is_update_available(self) -> Optional[bool]:
        """Check if an update is available.

        Returns:
            True if update available, False if current, None if unknown.
        """
        try:
            current = self.get_current_version()
            latest = self.get_latest_version(use_cache=True)

            if latest is None:
                return None

            return self._is_newer(latest, current)

        except Exception as e:
            logger.debug(f"Update check failed: {e}")
            return None

    def _fetch_latest_from_pypi(self) -> Optional[str]:
        """Fetch the latest version from PyPI.

        Returns:
            Latest version string, or None on error.
        """
        try:
            request = urllib.request.Request(
                self.PYPI_URL,
                headers={"Accept": "application/json"},
            )

            with urllib.request.urlopen(  # nosec B310 - URL is hardcoded HTTPS to pypi.org
                request, timeout=self.REQUEST_TIMEOUT_SECONDS
            ) as response:
                data = json.loads(response.read().decode("utf-8"))
                return data.get("info", {}).get("version")

        except urllib.error.URLError as e:
            logger.debug(f"Network error fetching PyPI: {e}")
            return None
        except json.JSONDecodeError as e:
            logger.debug(f"Invalid JSON from PyPI: {e}")
            return None
        except TimeoutError:
            logger.debug("PyPI request timed out")
            return None
        except Exception as e:
            logger.debug(f"Unexpected error fetching PyPI: {e}")
            return None

    def _is_newer(self, latest: str, current: str) -> bool:
        """Compare two version strings.

        Args:
            latest: The latest version string.
            current: The current version string.

        Returns:
            True if latest is newer than current.
        """
        try:
            return Version(latest) > Version(current)
        except InvalidVersion as e:
            logger.debug(f"Invalid version format: {e}")
            return False
