"""Schema validation functionality."""

import re
import logging
from typing import Dict, Any, List, TYPE_CHECKING

from .models import SchemaValidationError, ConfigurationError
from ..utils.console import success

if TYPE_CHECKING:
    from .config import ApiDefinition

logger = logging.getLogger(__name__)


def validate_api_definition_tables(
    api_def: "ApiDefinition",
    available_schemas: Dict[str, Any],
) -> None:
    """Validate that all tables in an API definition exist in loaded schemas.

    This validation runs at generation time when schemas are available.

    Args:
        api_def: The API definition to validate
        available_schemas: Dictionary of loaded schema names to schema objects

    Raises:
        ConfigurationError: If any table name doesn't exist in available schemas
    """
    available_names = set(available_schemas.keys())
    missing_tables = []

    for table in api_def.tables:
        if table not in available_names:
            missing_tables.append(table)

    if missing_tables:
        available_list = ", ".join(sorted(available_names)) if available_names else "(none)"
        missing_list = ", ".join(sorted(missing_tables))
        raise ConfigurationError(
            f"API '{api_def.name}' references unknown table(s): {missing_list}. "
            f"Available schemas: {available_list}"
        )


def validate_all_api_definitions(
    api_definitions: List["ApiDefinition"],
    available_schemas: Dict[str, Any],
) -> None:
    """Validate all API definitions against loaded schemas.

    Args:
        api_definitions: List of API definitions to validate
        available_schemas: Dictionary of loaded schema names to schema objects

    Raises:
        ConfigurationError: If any validation fails
    """
    for api_def in api_definitions:
        validate_api_definition_tables(api_def, available_schemas)


class SchemaValidator:
    """Validates schema files for correctness and conventions."""

    @staticmethod
    def validate_lambda_attributes(schema: Any) -> List[str]:
        """
        Validate Lambda schema attributes for input_only/output_only flags.

        Rules:
        - An attribute cannot have both input_only and output_only set to true
        - At least one attribute must be available for Input type (not output_only)
        - At least one attribute must be available for Output type (not input_only)

        Args:
            schema: LambdaType schema object

        Returns:
            List of validation error messages (empty if valid)

        Raises:
            SchemaValidationError: If validation fails
        """
        errors: List[str] = []
        input_attrs: List[str] = []
        output_attrs: List[str] = []

        for attr in schema.attributes:
            # Check for conflicting flags
            if attr.input_only and attr.output_only:
                errors.append(
                    f"Attribute '{attr.name}' in schema '{schema.name}' cannot have both "
                    f"input_only and output_only set to true"
                )

            # Track which attributes go where
            if not attr.output_only:
                input_attrs.append(attr.name)
            if not attr.input_only:
                output_attrs.append(attr.name)

        # Ensure at least one input attribute
        if not input_attrs:
            errors.append(
                f"Lambda schema '{schema.name}' has no input attributes. "
                f"At least one attribute must not be marked output_only."
            )

        # Ensure at least one output attribute
        if not output_attrs:
            errors.append(
                f"Lambda schema '{schema.name}' has no output attributes. "
                f"At least one attribute must not be marked input_only."
            )

        if errors:
            raise SchemaValidationError("\n".join(errors))

        return errors

    @staticmethod
    def validate_case_conventions(schema: Dict[str, Any], file_path: str) -> None:
        """
        Validate case conventions in schema files.

        Rules:
        - Schema names must be PascalCase
        - File names must match schema names
        - Attribute names must be camelCase
        - Index names must be PascalCase

        Args:
            schema: Schema dictionary
            file_path: Path to schema file

        Raises:
            SchemaValidationError: If conventions are violated
        """
        import os

        if "name" not in schema:
            raise SchemaValidationError(f"Schema must have a 'name' field: {file_path}")

        schema_name = schema["name"]

        # Validate schema name is in PascalCase
        if not re.match(r"^[A-Z][a-zA-Z0-9]*$", schema_name):
            raise SchemaValidationError(
                f"Schema name '{schema_name}' must be in PascalCase format (e.g., ApplicationRole)"
            )

        file_name = os.path.basename(file_path)
        expected_file_name = f"{schema_name}.yml"

        if file_name.lower() != expected_file_name.lower():
            raise SchemaValidationError(
                f"Schema file name '{file_name}' must match the schema name '{schema_name}' "
                f"defined in the 'name' field."
            )

        # Validate attribute names are camelCase
        if "model" in schema and "attributes" in schema["model"]:
            if not isinstance(schema["model"]["attributes"], dict):
                raise SchemaValidationError(
                    f"Schema '{schema_name}' has a non-dict 'attributes' section: "
                    f"{type(schema['model']['attributes'])}"
                )

            for attr_name in schema["model"]["attributes"]:
                if not re.match(r"^[a-z][a-zA-Z0-9]*$", attr_name):
                    raise SchemaValidationError(
                        f"Attribute name '{attr_name}' must be in camelCase"
                    )

        # Validate index names are PascalCase
        if "model" in schema and "keys" in schema["model"]:
            if "secondary" in schema["model"]["keys"]:
                for index in schema["model"]["keys"]["secondary"]:
                    if "name" in index:
                        if not re.match(r"^[A-Z][a-zA-Z0-9]*$", index["name"]):
                            raise SchemaValidationError(
                                f"Index name '{index['name']}' must be in PascalCase format "
                                f"(e.g., RoleIndex)"
                            )

        # Validate registry items
        if "type" in schema and schema["type"] == "registry":
            if "items" not in schema:
                raise SchemaValidationError(
                    f"Registry schema '{schema['name']}' must have an 'items' block: {file_path}"
                )

            items = schema["items"]
            if not isinstance(items, dict):
                raise SchemaValidationError(
                    f"Registry 'items' must be a dict in '{schema['name']}'"
                )

            for code, entry in items.items():
                # Validate item key format - warn about hyphens (they'll be converted)
                if "-" in code:
                    logger.warning(
                        f"Registry item key '{code}' in '{schema['name']}' contains hyphens. "
                        f"These will be converted to valid identifiers in generated code: "
                        f"GraphQL → underscores, Python → underscores, "
                        f"TypeScript → PascalCase, Dart → camelCase"
                    )

                if not isinstance(entry, dict):
                    raise SchemaValidationError(
                        f"Registry item '{code}' must be a dict in '{schema['name']}'"
                    )

                for field in ["message", "description", "solution"]:
                    if field not in entry:
                        raise SchemaValidationError(
                            f"Registry item '{code}' missing required field '{field}' "
                            f"in '{schema['name']}'"
                        )

    @staticmethod
    def validate_auth_config(schema: Any) -> None:
        """
        Validate authentication configuration.

        Args:
            schema: Schema object with auth_config

        Raises:
            SchemaValidationError: If auth config is invalid
        """
        if not hasattr(schema, "auth_config") or not schema.auth_config:
            raise SchemaValidationError(
                f"No auth_config found for schema '{schema.name}'. "
                f"Please add authConfig section with cognitoAuthentication or apiKeyAuthentication."
            )

        # Validate cognitoAuthentication structure
        cognito_auth = schema.auth_config.get("cognitoAuthentication", {})
        if cognito_auth and not isinstance(cognito_auth, dict):
            raise SchemaValidationError(
                f"cognitoAuthentication must be a dict in schema '{schema.name}'"
            )

        if cognito_auth:
            groups = cognito_auth.get("groups", {})
            if not isinstance(groups, dict):
                raise SchemaValidationError(
                    f"cognitoAuthentication.groups must be a dict in schema '{schema.name}'"
                )

            for group, ops in groups.items():
                if not isinstance(ops, list):
                    raise SchemaValidationError(
                        f"Group '{group}' operations must be a list in schema '{schema.name}'"
                    )

    @staticmethod
    def validate_graphql_sdl(sdl_path: str, strict: bool = True) -> List[str]:
        """
        Validate GraphQL SDL syntax and structure.

        Performs comprehensive validation including:
        - GraphQL syntax validation
        - Duplicate type detection
        - Unknown type reference detection
        - AppSync-specific checks

        Args:
            sdl_path: Path to GraphQL SDL file
            strict: If True, raise exception on errors. If False, return error list.

        Returns:
            List of error messages (empty if valid)

        Raises:
            SchemaValidationError: If strict=True and validation fails
        """
        try:
            from graphql import parse, build_ast_schema, GraphQLError
            from graphql.language.ast import (
                TypeDefinitionNode,
                NamedTypeNode,
                ListTypeNode,
                NonNullTypeNode,
            )
        except ImportError:
            logger.warning(
                "GraphQL-core not installed. Skipping SDL validation. "
                "Install with: pip install graphql-core"
            )
            return []

        with open(sdl_path, "r", encoding="utf-8") as f:
            sdl = f.read()

        errors: List[str] = []

        # Strip AppSync-specific directive USAGES for standard GraphQL validation
        # Keep directive DEFINITIONS (lines starting with "directive @aws_")
        sdl_for_validation = sdl
        # Only strip directive usages (on field definitions), not directive definitions
        # Pattern matches @aws_* when NOT at the start of a line (i.e., usages, not definitions)
        pattern = r"(?<!directive )@aws_\w+(\([^)]*\))?"
        sdl_for_validation = re.sub(pattern, "", sdl_for_validation)
        # Also strip the directive definitions themselves since graphql-core doesn't need them
        sdl_for_validation = re.sub(
            r"directive @aws_\w+\([^)]*\) on FIELD_DEFINITION\n?", "", sdl_for_validation
        )
        sdl_for_validation = re.sub(r"\s+", " ", sdl_for_validation)
        sdl_for_validation = re.sub(r"\s*\n\s*", "\n", sdl_for_validation)

        # Parse and build schema with GraphQL-core
        document = None
        try:
            document = parse(sdl_for_validation)
            build_ast_schema(document)
            logger.info(success(f"GraphQL SDL syntax validation passed for {sdl_path}"))
        except GraphQLError as e:
            error_msg = f"GraphQL syntax error: {e.message}"
            if hasattr(e, "locations") and e.locations:
                for loc in e.locations:
                    error_msg += f" (line {loc.line}, column {loc.column})"
            errors.append(error_msg)
        except Exception as e:
            errors.append(f"GraphQL schema parsing failed: {str(e)}")

        # Check for duplicate types
        if document:
            type_definitions: Dict[str, List[int]] = {}
            for definition in document.definitions:
                if isinstance(definition, TypeDefinitionNode):
                    type_name = definition.name.value
                    line_num = definition.loc.start_token.line if definition.loc else 0
                    if type_name not in type_definitions:
                        type_definitions[type_name] = []
                    type_definitions[type_name].append(line_num)

            for type_name, line_nums in type_definitions.items():
                if len(line_nums) > 1:
                    lines_str = ", ".join(str(ln) for ln in line_nums)
                    errors.append(f"Duplicate type: {type_name} (lines {lines_str})")

        # Check for unknown type references
        if document:
            defined_types = set()
            referenced_types = set()
            builtin_types = {"String", "Int", "Float", "Boolean", "ID", "DateTime"}

            # Collect defined types
            for definition in document.definitions:
                if isinstance(definition, TypeDefinitionNode):
                    defined_types.add(definition.name.value)

            # Helper to extract type name from nested type nodes
            def get_type_name(type_node: Any) -> str | None:
                if isinstance(type_node, NamedTypeNode):
                    return type_node.name.value
                elif isinstance(type_node, (ListTypeNode, NonNullTypeNode)):
                    return get_type_name(type_node.type)
                return None

            # Collect referenced types from fields
            for definition in document.definitions:
                if hasattr(definition, "fields") and definition.fields:
                    for field in definition.fields:
                        field_type_name = get_type_name(field.type)
                        if field_type_name:
                            referenced_types.add(field_type_name)
                        # Check arguments too
                        if hasattr(field, "arguments") and field.arguments:
                            for arg in field.arguments:
                                arg_type_name = get_type_name(arg.type)
                                if arg_type_name:
                                    referenced_types.add(arg_type_name)

            # Find unknown types
            all_known_types = defined_types | builtin_types
            unknown_types = referenced_types - all_known_types
            for unknown_type in sorted(unknown_types):
                errors.append(f"Unknown type: {unknown_type}")

        # AppSync-specific checks
        if '"""' in sdl:
            errors.append("Triple-quoted docstrings are not supported by AppSync")

        if sdl.strip().startswith("```") or sdl.strip().endswith("```"):
            errors.append("Leading or trailing backticks are not allowed")

        lines = sdl.split("\n")
        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()
            if line_stripped.startswith("#"):
                # Skip directive definitions and section comments
                if "directive" not in line_stripped.lower() and not any(
                    section in line_stripped
                    for section in [
                        "Generated",
                        "AppSync",
                        "Custom",
                        "Types",
                        "Response",
                        "Input",
                        "Queries",
                        "Mutations",
                        "Enums",
                    ]
                ):
                    errors.append(
                        f"Line {line_num}: Top-level # comments are not supported by AppSync"
                    )

            if len(line) > 500:
                errors.append(
                    f"Line {line_num}: Very long line ({len(line)} chars) may cause parsing issues"
                )

        if errors:
            if strict:
                error_msg = f"GraphQL validation failed for {sdl_path}:\n"
                error_msg += "\n".join(f"  • {error}" for error in errors)
                raise SchemaValidationError(error_msg)
        else:
            logger.info(success(f"AppSync SDL validation passed for {sdl_path}"))

        return errors
