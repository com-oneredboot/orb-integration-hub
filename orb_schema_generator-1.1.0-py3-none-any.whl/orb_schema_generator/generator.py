"""Main schema generator class."""

import logging
from typing import Dict, Any, List, Optional

from .core.config import GeneratorConfig
from .core.loaders import SchemaLoader
from .core.validators import SchemaValidator
from .core.builders import OperationBuilder
from .core.models import TableSchema
from .core.target_validator import TargetValidator
from .generators.python_generator import PythonGenerator
from .generators.typescript_generator import TypeScriptGenerator
from .generators.graphql_generator import GraphQLGenerator
from .generators.cdk_generator import CDKGenerator
from .generators.vtl_generator import VTLGenerator
from .generators.lambda_resolver_generator import LambdaResolverGenerator
from .generators.dart_generator import DartGenerator
from .generators.s3_generator import S3Generator
from .events import EventEmitter, Event, EventType
from .progress import ProgressTracker, Stage
from .result import GenerationResult
from .utils.console import success, error

logger = logging.getLogger(__name__)


class SchemaGenerator:
    """Main schema generator orchestrator."""

    def __init__(self, config: GeneratorConfig, event_emitter: Optional[EventEmitter] = None):
        """
        Initialize schema generator.

        Args:
            config: Generator configuration
            event_emitter: Optional event emitter for progress tracking
        """
        self.config = config
        self.loader = SchemaLoader(config)
        self.validator = SchemaValidator()
        self.events = event_emitter or EventEmitter()
        self.progress = ProgressTracker()

        # Initialize generators
        self.python_gen = PythonGenerator(config)
        self.typescript_gen = TypeScriptGenerator(config)
        self.graphql_gen = GraphQLGenerator(config)
        self.cdk_gen = CDKGenerator(config)
        self.vtl_gen = VTLGenerator(config)
        self.lambda_resolver_gen = LambdaResolverGenerator(config)
        self.s3_gen = S3Generator(config)

        # Initialize Dart generator if enabled
        self.dart_gen = None
        if config.dart_enabled and config.dart_config:
            self.dart_gen = DartGenerator(config, config.dart_config)

        # Set up logging
        log_level = getattr(logging, config.log_level.upper())
        logging.basicConfig(
            level=log_level,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(config.log_file) if config.log_file else logging.NullHandler(),
            ],
        )

    def generate_all(
        self, only_schemas=None, exclude_schemas=None, only_formats=None
    ) -> GenerationResult:
        """
        Generate all code from schemas.

        Args:
            only_schemas: List of schema names to generate (None = all)
            exclude_schemas: List of schema names to exclude (None = none)
            only_formats: List of formats to generate (None = all) - ['python', 'typescript', 'graphql', 'cdk']

        Returns:
            GenerationResult with statistics and metadata
        """
        result = GenerationResult()

        # Start progress tracking
        self.progress.start(total_steps=7)  # 7 major stages
        self.events.emit(Event(EventType.START, {"config": self.config.to_dict()}))

        logger.info("Starting schema generation...")

        try:
            # Load schemas
            self.progress.set_stage(Stage.LOADING)
            all_schemas = self.loader.load_all_schemas()

            # Apply schema filters
            schemas = self._filter_schemas(all_schemas, only_schemas, exclude_schemas)

            result.schemas_processed = len(schemas)
            logger.info(f"Loaded {len(schemas)} schemas")
            self.events.emit(
                Event(EventType.PROGRESS, {"stage": "loading", "schemas_count": len(schemas)})
            )
            self.progress.step()

            # Validate targets
            target_validator = TargetValidator()
            target_result = target_validator.validate(schemas, self.config)
            if not target_result.is_valid:
                error_messages = [e.message for e in target_result.errors]
                raise ValueError("Target validation failed:\n  - " + "\n  - ".join(error_messages))
            logger.info("Target validation passed")

            # Validate if enabled
            if self.config.validate_schemas:
                self.progress.set_stage(Stage.VALIDATING)
                self.validate_schemas()
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "validation"}))
                self.progress.step()

            # Build operations for table schemas
            self.progress.set_stage(Stage.BUILDING_OPERATIONS)
            for schema in schemas.values():
                if isinstance(schema, TableSchema):
                    builder = OperationBuilder(schema)
                    schema.operations = builder.build_all_operations()
                    logger.info(f"Built {len(schema.operations)} operations for {schema.name}")
            self.progress.step()

            # Determine what to generate
            should_generate = self._should_generate_formats(only_formats)

            # Generate Python models
            if should_generate["python"]:
                self.progress.set_stage(Stage.GENERATING_PYTHON)
                logger.info("Generating Python models...")
                self.python_gen.generate(schemas)
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "python"}))
            self.progress.step()

            # Generate TypeScript models
            if should_generate["typescript"]:
                self.progress.set_stage(Stage.GENERATING_TYPESCRIPT)
                logger.info("Generating TypeScript models...")
                self.typescript_gen.generate(schemas)
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "typescript"}))
            self.progress.step()

            # Generate Dart models
            if should_generate.get("dart") and self.dart_gen:
                logger.info("Generating Dart models...")
                self.dart_gen.generate(schemas)  # Handles both models and RegistryType enums
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "dart"}))

            # Generate GraphQL schema
            if should_generate["graphql"]:
                self.progress.set_stage(Stage.GENERATING_GRAPHQL)
                logger.info("Generating GraphQL schema...")
                self.graphql_gen.generate(schemas)
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "graphql"}))
            self.progress.step()

            # Generate CDK constructs
            if should_generate["cdk"]:
                self.progress.set_stage(Stage.GENERATING_CDK)
                logger.info("Generating CDK constructs...")
                self.cdk_gen.generate(schemas)
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "cdk"}))

                # Generate S3 storage constructs
                logger.info("Generating S3 storage constructs...")
                self.s3_gen.generate(schemas)
                self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "s3"}))

                # Generate VTL resolvers for table schemas
                if self._should_generate_vtl(schemas):
                    logger.info("Generating VTL resolver templates...")
                    self.vtl_gen.generate(schemas)
                    self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "vtl"}))

                # Generate Lambda resolvers if enabled
                if self._should_generate_lambda_resolvers():
                    logger.info("Generating Lambda resolver templates...")
                    self.lambda_resolver_gen.generate(schemas)
                    self.events.emit(Event(EventType.STAGE_COMPLETE, {"stage": "lambda_resolvers"}))
            self.progress.step()

            # Complete
            self.progress.complete()
            result.elapsed_time = self.progress.elapsed_time
            result.stage_times = {
                stage.value: duration for stage, duration in self.progress.stage_times.items()
            }

            logger.info(success("Schema generation completed successfully"))
            self.events.emit(Event(EventType.COMPLETE, result.get_summary()))

            return result

        except Exception as e:
            logger.error(error(f"Generation failed: {str(e)}"))
            result.add_error(str(e))
            self.events.emit(Event(EventType.ERROR, {"error": str(e)}))
            raise

    def validate_schemas(self) -> None:
        """Validate all schemas."""
        import glob

        logger.info("Validating schemas...")

        schemas = self.loader.load_all_schemas()

        # Validate case conventions for all schema files
        schema_files = glob.glob(str(self.config.schema_dir / "**/*.yml"), recursive=True)
        for schema_file in schema_files:
            try:
                import yaml

                with open(schema_file, "r") as f:
                    schema_dict = yaml.safe_load(f)
                if schema_dict and "name" in schema_dict:
                    self.validator.validate_case_conventions(schema_dict, schema_file)
            except Exception as e:
                logger.debug(f"Skipping validation for {schema_file}: {e}")

        for schema in schemas.values():
            # Validate auth config for table schemas
            if isinstance(schema, TableSchema):
                self.validator.validate_auth_config(schema)

        logger.info(success("All schemas validated successfully"))

    def _filter_schemas(
        self,
        schemas: Dict[str, Any],
        only: Optional[List[Any]] = None,
        exclude: Optional[List[Any]] = None,
    ) -> Dict[str, Any]:
        """
        Filter schemas based on only/exclude lists.

        Args:
            schemas: Dictionary of all schemas
            only: List of schema names to include (None = all)
            exclude: List of schema names to exclude (None = none)

        Returns:
            Filtered dictionary of schemas
        """
        filtered = schemas.copy()

        # Apply only filter
        if only:
            filtered = {name: schema for name, schema in filtered.items() if name in only}
            logger.info(f"Filtered to only schemas: {', '.join(only)}")

        # Apply exclude filter
        if exclude:
            filtered = {name: schema for name, schema in filtered.items() if name not in exclude}
            logger.info(f"Excluded schemas: {', '.join(exclude)}")

        return filtered

    def _should_generate_formats(self, only_formats: Optional[List[Any]] = None) -> Dict[str, bool]:
        """
        Determine which formats should be generated.

        Args:
            only_formats: List of formats to generate (None = all enabled)

        Returns:
            Dictionary of format name to boolean
        """
        # Start with config-based enable flags
        result = {
            "python": self.config.python_enabled,
            "typescript": self.config.typescript_enabled,
            "dart": self.config.dart_enabled,
            "graphql": True,  # GraphQL doesn't have an enable flag yet
            "cdk": True,  # CDK doesn't have an enable flag yet
        }

        # If only_formats is specified, further filter
        if only_formats is not None:
            result = {
                "python": result["python"] and "python" in only_formats,
                "typescript": result["typescript"] and "typescript" in only_formats,
                "dart": result["dart"] and "dart" in only_formats,
                "graphql": "graphql" in only_formats,
                "cdk": "cdk" in only_formats,
            }

        return result

    def _should_generate_vtl(self, schemas: Any) -> bool:
        """
        Check if VTL resolver generation should occur.

        VTL resolvers are generated automatically for DynamoDB table schemas.
        No configuration flag needed.

        Args:
            schemas: Dict or list of schemas to check.

        Returns:
            True if there are DynamoDB schemas that need VTL resolvers
        """
        # Handle both dict and list of schemas
        if isinstance(schemas, dict):
            schemas_to_check = list(schemas.values())
        elif schemas is not None:
            schemas_to_check = list(schemas)
        else:
            schemas_to_check = []
        return any(getattr(s, "type", None) == "dynamodb" for s in schemas_to_check)

    def _should_generate_lambda_resolvers(self) -> bool:
        """
        Check if Lambda resolver VTL templates should be generated.

        Returns:
            True if there are lambda-dynamodb schemas that need VTL templates.
            Pure 'type: lambda' schemas use direct Lambda invocation (no VTL needed).
        """
        # Lambda resolver VTL templates are only needed for lambda-dynamodb schemas
        # Pure lambda schemas use direct Lambda invocation without VTL
        return False  # Disabled for now - lambda-dynamodb uses same pattern as pure lambda
