"""File watcher for schema changes."""

import time
import logging
from pathlib import Path
from typing import Callable, Optional, Set
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

logger = logging.getLogger(__name__)


class SchemaWatcher(FileSystemEventHandler):
    """
    Watches schema files for changes and triggers regeneration.

    Includes debouncing to avoid multiple rapid regenerations.
    """

    def __init__(
        self,
        callback: Callable[[], None],
        debounce_seconds: float = 2.0,
        file_patterns: Optional[Set[str]] = None,
    ):
        """
        Initialize schema watcher.

        Args:
            callback: Function to call when changes detected
            debounce_seconds: Seconds to wait before triggering callback
            file_patterns: File patterns to watch (e.g., {'.yml', '.yaml'})
        """
        super().__init__()
        self.callback = callback
        self.debounce_seconds = debounce_seconds
        self.file_patterns = file_patterns or {".yml", ".yaml"}
        self._last_trigger_time: float = 0.0
        self._pending_changes: Set[str] = set()

    def on_any_event(self, event: FileSystemEvent) -> None:
        """
        Handle any file system event.

        Args:
            event: File system event
        """
        # Ignore directory events
        if event.is_directory:
            return

        # Check if file matches patterns
        file_path = Path(event.src_path)
        if file_path.suffix not in self.file_patterns:
            return

        # Ignore temporary files
        if file_path.name.startswith(".") or file_path.name.endswith("~"):
            return

        # Add to pending changes
        self._pending_changes.add(str(file_path))

        # Check if we should trigger
        current_time = time.time()
        time_since_last = current_time - self._last_trigger_time

        if time_since_last >= self.debounce_seconds:
            self._trigger_callback()

    def _trigger_callback(self) -> None:
        """Trigger the callback with debouncing."""
        if not self._pending_changes:
            return

        logger.info(f"Detected changes in {len(self._pending_changes)} file(s)")
        for file_path in self._pending_changes:
            logger.debug(f"  Changed: {file_path}")

        self._pending_changes.clear()
        self._last_trigger_time = time.time()

        try:
            self.callback()
        except Exception as e:
            logger.error(f"Error in watch callback: {e}")


class FileWatcher:
    """
    File watcher manager for schema files.

    Provides start/stop control and error handling.
    """

    def __init__(
        self,
        watch_path: Path,
        callback: Callable[[], None],
        debounce_seconds: float = 2.0,
        recursive: bool = True,
    ):
        """
        Initialize file watcher.

        Args:
            watch_path: Path to watch for changes
            callback: Function to call when changes detected
            debounce_seconds: Seconds to wait before triggering
            recursive: Watch subdirectories recursively
        """
        self.watch_path = Path(watch_path)
        self.callback = callback
        self.debounce_seconds = debounce_seconds
        self.recursive = recursive

        self.observer: Optional[Observer] = None
        self.handler: Optional[SchemaWatcher] = None
        self._is_running = False

    def start(self) -> None:
        """Start watching for file changes."""
        if self._is_running:
            logger.warning("Watcher is already running")
            return

        if not self.watch_path.exists():
            raise FileNotFoundError(f"Watch path does not exist: {self.watch_path}")

        logger.info(f"Starting file watcher on: {self.watch_path}")

        # Create handler and observer
        self.handler = SchemaWatcher(callback=self.callback, debounce_seconds=self.debounce_seconds)

        self.observer = Observer()
        self.observer.schedule(self.handler, str(self.watch_path), recursive=self.recursive)

        self.observer.start()
        self._is_running = True

        logger.info("File watcher started successfully")

    def stop(self) -> None:
        """Stop watching for file changes."""
        if not self._is_running:
            return

        logger.info("Stopping file watcher...")

        if self.observer:
            self.observer.stop()
            self.observer.join(timeout=5.0)
            self.observer = None

        self.handler = None
        self._is_running = False

        logger.info("File watcher stopped")

    def is_running(self) -> bool:
        """Check if watcher is currently running."""
        return self._is_running

    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()
